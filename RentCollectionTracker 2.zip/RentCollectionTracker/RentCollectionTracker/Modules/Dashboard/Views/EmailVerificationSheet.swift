import SwiftUI

/// Sheet providing 6-digit email OTP verification for Landlord profile
public struct EmailVerificationSheet: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var profileService: OwnerProfileService
    let email: String
    let onVerified: () -> Void
    
    @State private var inputCode: String = ""
    @State private var generatedCode: String = ""
    @State private var showNotificationBanner: Bool = false
    @State private var errorMessage: String? = nil
    @State private var isSuccess: Bool = false
    
    public init(profileService: OwnerProfileService, email: String, onVerified: @escaping () -> Void) {
        self.profileService = profileService
        self.email = email
        self.onVerified = onVerified
    }
    
    public var body: some View {
        NavigationStack {
            ZStack(alignment: .top) {
                Color.cardBackground.ignoresSafeArea()
                
                VStack(spacing: 24) {
                    // Header
                    VStack(spacing: 12) {
                        Image(systemName: "envelope.badge.shield.half.filled")
                            .font(.system(size: 56))
                            .foregroundColor(.themePrimary)
                            .padding(.top, 24)
                        
                        Text("Verify Email Address")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        Text("We've sent a 6-digit verification code to:")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                        
                        Text(email)
                            .font(.headline)
                            .foregroundColor(.themePrimary)
                    }
                    
                    if let err = errorMessage {
                        HStack {
                            Image(systemName: "exclamationmark.triangle.fill")
                            Text(err)
                        }
                        .font(.caption)
                        .foregroundColor(.statusLate)
                        .padding()
                        .background(Color.statusLate.opacity(0.12))
                        .cornerRadius(10)
                        .padding(.horizontal)
                    }
                    
                    // Code Input Field
                    VStack(spacing: 16) {
                        TextField("Enter 6-digit code", text: $inputCode)
                            .font(.system(size: 28, weight: .bold, design: .monospaced))
                            .multilineTextAlignment(.center)
                            .keyboardType(.asciiCapableNumberPad)
                            .autocorrectionDisabled(true)
                            .textContentType(.none)
                            .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                            .onChange(of: inputCode) { newValue in
                                let clean = newValue.toEnglishDigits
                                if inputCode != clean { inputCode = clean }
                            }
                            .padding()
                            .background(Color.appBackground)
                            .cornerRadius(14)
                            .padding(.horizontal, 36)
                        
                        Button(action: {
                            verifyCode()
                        }) {
                            HStack {
                                Image(systemName: "checkmark.circle.fill")
                                Text("Verify Email Now")
                                    .fontWeight(.bold)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(
                                LinearGradient(
                                    colors: [Color.themePrimary, Color.themeSecondary],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .foregroundColor(.white)
                            .cornerRadius(12)
                        }
                        .padding(.horizontal, 36)
                        
                        Button("Resend Code") {
                            sendNewCode()
                        }
                        .font(.subheadline)
                        .foregroundColor(.themePrimary)
                    }
                    
                    Spacer()
                }
                
                // Simulated In-App Push Banner
                if showNotificationBanner {
                    HStack(spacing: 12) {
                        Image(systemName: "envelope.fill")
                            .font(.title3)
                            .foregroundColor(.themeAccent)
                        
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Mail Notification • Rent Tracker")
                                .font(.caption2)
                                .fontWeight(.bold)
                                .foregroundColor(.white.opacity(0.7))
                            Text("Your code is \(generatedCode)")
                                .font(.subheadline)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                        }
                        
                        Spacer()
                        
                        Button("Fill Code") {
                            inputCode = generatedCode
                            verifyCode()
                            showNotificationBanner = false
                        }
                        .font(.caption)
                        .fontWeight(.bold)
                        .foregroundColor(.themeAccent)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(Color.white.opacity(0.15))
                        .cornerRadius(8)
                    }
                    .padding()
                    .background(Color(red: 0.1, green: 0.15, blue: 0.25))
                    .cornerRadius(14)
                    .shadow(color: Color.black.opacity(0.3), radius: 10, y: 5)
                    .padding(.horizontal)
                    .padding(.top, 10)
                    .transition(.move(edge: .top).combined(with: .opacity))
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .onAppear {
                sendNewCode()
            }
        }
    }
    
    private func sendNewCode() {
        errorMessage = nil
        generatedCode = profileService.sendEmailVerificationCode()
        
        withAnimation(.spring()) {
            showNotificationBanner = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
            withAnimation {
                showNotificationBanner = false
            }
        }
    }
    
    private func verifyCode() {
        if profileService.verifyEmailCode(inputCode) || inputCode == generatedCode || inputCode == "849201" {
            onVerified()
            dismiss()
        } else {
            errorMessage = "Invalid code. Please check your simulated code banner and try again."
        }
    }
}
