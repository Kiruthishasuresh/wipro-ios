import SwiftUI

/// Sheet providing Landlord password and 4-digit security PIN update with verification
public struct ChangePasswordSheet: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var profileService: OwnerProfileService
    
    @State private var currentCredential: String = ""
    @State private var newPassword: String = ""
    @State private var confirmPassword: String = ""
    @State private var newPin: String = ""
    
    @State private var errorMessage: String? = nil
    @State private var showSuccessAlert: Bool = false
    
    public init(profileService: OwnerProfileService) {
        self.profileService = profileService
        _newPin = State(initialValue: profileService.currentProfile.securityPin)
    }
    
    public var body: some View {
        NavigationStack {
            Form {
                // Info header
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        HStack(spacing: 10) {
                            Image(systemName: "key.horizontal.fill")
                                .font(.title2)
                                .foregroundColor(.themePrimary)
                            Text("Change Security Credentials")
                                .font(.headline)
                        }
                        Text("Ensure your new password contains at least 6 characters. Your 4-digit PIN can also be updated here.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                }
                
                // Error message
                if let error = errorMessage {
                    Section {
                        HStack(spacing: 8) {
                            Image(systemName: "exclamationmark.triangle.fill")
                                .foregroundColor(.statusLate)
                            Text(error)
                                .font(.subheadline)
                                .foregroundColor(.statusLate)
                        }
                    }
                }
                
                // Current verification
                Section("Verification") {
                    SecureField("Current Password or PIN", text: $currentCredential)
                        .keyboardType(.asciiCapable)
                        .autocorrectionDisabled(true)
                        .textContentType(.none)
                        .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                }
                
                // New Password
                Section("New Password") {
                    SecureField("New Password (min 6 characters)", text: $newPassword)
                        .keyboardType(.asciiCapable)
                        .autocorrectionDisabled(true)
                        .textContentType(.none)
                        .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                    SecureField("Confirm New Password", text: $confirmPassword)
                        .keyboardType(.asciiCapable)
                        .autocorrectionDisabled(true)
                        .textContentType(.none)
                        .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                }
                
                // New PIN
                Section("Master 4-Digit Security PIN") {
                    HStack {
                        Image(systemName: "key.fill")
                            .foregroundColor(.secondary)
                        TextField("e.g. 1234", text: $newPin)
                            .keyboardType(.asciiCapableNumberPad)
                            .autocorrectionDisabled(true)
                            .textContentType(.none)
                            .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                            .onChange(of: newPin) { newValue in
                                let clean = newValue.toEnglishPin
                                if newPin != clean { newPin = clean }
                            }
                    }
                }
                
                // Action
                Section {
                    Button(action: {
                        submitPasswordChange()
                    }) {
                        HStack {
                            Spacer()
                            Image(systemName: "checkmark.shield.fill")
                            Text("Update Password & PIN")
                                .fontWeight(.bold)
                            Spacer()
                        }
                        .foregroundColor(.themePrimary)
                    }
                }
            }
            .navigationTitle("Change Password")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .alert("Credentials Updated", isPresented: $showSuccessAlert) {
                Button("OK") {
                    dismiss()
                }
            } message: {
                Text("Your landlord password and 4-digit security PIN have been updated successfully.")
            }
        }
    }
    
    private func submitPasswordChange() {
        errorMessage = nil
        let trimmedCurrent = currentCredential.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedNew = newPassword.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedConfirm = confirmPassword.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPin = newPin.trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard !trimmedCurrent.isEmpty else {
            errorMessage = "Please enter your current password or PIN."
            return
        }
        guard trimmedNew.count >= 6 else {
            errorMessage = "New password must be at least 6 characters."
            return
        }
        guard trimmedNew == trimmedConfirm else {
            errorMessage = "New passwords do not match."
            return
        }
        guard trimmedPin.count == 4, trimmedPin.allSatisfy({ $0.isNumber }) else {
            errorMessage = "Security PIN must be exactly 4 digits."
            return
        }
        
        let result = profileService.changePassword(
            current: trimmedCurrent,
            newPass: trimmedNew,
            newPin: trimmedPin
        )
        
        switch result {
        case .success:
            showSuccessAlert = true
        case .failure(let err):
            errorMessage = err.localizedDescription
        }
    }
}
