import SwiftUI

/// Screen for viewing and editing Owner/Landlord profile, managing Security PIN, QR Pass, Password, and Email Verification
public struct OwnerProfileView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var authViewModel: AuthViewModel
    @ObservedObject private var profileService = OwnerProfileService.shared
    
    @State private var profile: OwnerProfile
    @State private var qrCodeImage: UIImage? = nil
    
    // Privacy / Pass reveal state
    @State private var isPassRevealed: Bool = false
    @State private var showPinUnlockPrompt: Bool = false
    @State private var pinChallengeInput: String = ""
    @State private var pinUnlockError: String? = nil
    
    // Sheets & Alerts
    @State private var showChangePasswordSheet: Bool = false
    @State private var showEmailVerificationSheet: Bool = false
    @State private var showSavedAlert: Bool = false
    @State private var showLogoutConfirmation: Bool = false
    @State private var showResetDataConfirmation: Bool = false
    
    public var onClearData: (() -> Void)? = nil
    
    public init(authViewModel: AuthViewModel, onClearData: (() -> Void)? = nil) {
        self.authViewModel = authViewModel
        self.onClearData = onClearData
        _profile = State(initialValue: OwnerProfileService.shared.loadProfile())
    }
    
    public var body: some View {
        NavigationStack {
            Form {
                // Section 1: Header Profile Card
                Section {
                    HStack(spacing: 16) {
                        ZStack {
                            Circle()
                                .fill(
                                    LinearGradient(
                                        colors: [Color.themePrimary, Color.themeSecondary],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 64, height: 64)
                                .shadow(color: Color.themePrimary.opacity(0.3), radius: 6, x: 0, y: 3)
                            
                            Text(profile.initials)
                                .font(.title2)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                        }
                        
                        VStack(alignment: .leading, spacing: 4) {
                            Text(profile.name.isEmpty ? "Owner Account" : profile.name)
                                .font(.headline)
                                .fontWeight(.bold)
                            if !profile.companyName.isEmpty {
                                Text(profile.companyName)
                                    .font(.subheadline)
                                    .foregroundColor(.secondary)
                            }
                            Text("Customer ID: \(String(profile.id.prefix(8))) • Active Account")
                                .font(.caption2)
                                .foregroundColor(.themePrimary)
                                .fontWeight(.semibold)
                        }
                    }
                    .padding(.vertical, 6)
                }
                
                // Section 2: Editable Owner Details
                Section("Owner & Business Details") {
                    CustomInputField(
                        label: "Owner Full Name",
                        placeholder: "e.g. John Sterling",
                        text: $profile.name,
                        iconName: "person.text.rectangle.fill"
                    )
                    
                    CustomInputField(
                        label: "Company / Property Name",
                        placeholder: "e.g. Sterling Properties (Optional)",
                        text: $profile.companyName,
                        iconName: "building.2.fill"
                    )
                    
                    CustomInputField(
                        label: "Contact Phone",
                        placeholder: "e.g. 555-012-3456 (Optional)",
                        text: $profile.phoneNumber,
                        iconName: "phone.fill",
                        keyboardType: .phonePad,
                        isPhoneNumber: true
                    )
                    
                    // Email row with verification badge
                    VStack(alignment: .leading, spacing: 8) {
                        CustomInputField(
                            label: "Email Address",
                            placeholder: "e.g. owner@example.com",
                            text: $profile.email,
                            iconName: "envelope.fill",
                            keyboardType: .emailAddress
                        )
                        
                        HStack {
                            if profile.isEmailVerified {
                                HStack(spacing: 4) {
                                    Image(systemName: "checkmark.seal.fill")
                                        .foregroundColor(.statusPaid)
                                    Text("Email Verified")
                                        .font(.caption)
                                        .fontWeight(.semibold)
                                        .foregroundColor(.statusPaid)
                                }
                            } else {
                                HStack(spacing: 6) {
                                    Image(systemName: "exclamationmark.triangle.fill")
                                        .foregroundColor(.statusPending)
                                    Text("Unverified Email")
                                        .font(.caption)
                                        .foregroundColor(.statusPending)
                                    
                                    Spacer()
                                    
                                    Button("Verify Now") {
                                        showEmailVerificationSheet = true
                                    }
                                    .font(.caption)
                                    .fontWeight(.bold)
                                    .foregroundColor(.themePrimary)
                                }
                            }
                        }
                        .padding(.horizontal, 4)
                    }
                    
                    CustomInputField(
                        label: "Office / Business Address",
                        placeholder: "Optional office or property address",
                        text: $profile.officeAddress,
                        iconName: "mappin.and.ellipse"
                    )
                }
                
                // Section 3: Password & Security Credentials
                Section("Account Security") {
                    Button(action: {
                        showChangePasswordSheet = true
                    }) {
                        HStack {
                            Image(systemName: "key.horizontal.fill")
                                .foregroundColor(.themePrimary)
                            Text("Change Password & Security PIN")
                                .foregroundColor(.primary)
                            Spacer()
                            Image(systemName: "chevron.right")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                    }
                }
                
                // Section 4: Private Landlord Security QR Pass (Protected)
                Section {
                    if !isPassRevealed {
                        // Locked / Private Shield State
                        VStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(Color.themePrimary.opacity(0.12))
                                    .frame(width: 56, height: 56)
                                Image(systemName: "lock.shield.fill")
                                    .font(.system(size: 28))
                                    .foregroundColor(.themePrimary)
                            }
                            .padding(.top, 4)
                            
                            Text("Confidential Landlord Pass & PIN")
                                .font(.headline)
                                .fontWeight(.bold)
                            
                            Text("Your QR Pass and Security PIN are hidden for privacy. Authenticate to view your credentials.")
                                .font(.caption)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 16)
                            
                            Button(action: {
                                promptPassVerification()
                            }) {
                                HStack(spacing: 6) {
                                    Image(systemName: "lock.open.fill")
                                    Text("Verify Identity to Reveal Pass")
                                        .fontWeight(.semibold)
                                }
                                .font(.subheadline)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 10)
                                .background(Color.themePrimary)
                                .foregroundColor(.white)
                                .cornerRadius(10)
                            }
                            .padding(.horizontal, 24)
                            .padding(.top, 4)
                        }
                        .padding(.vertical, 12)
                    } else {
                        // Unlocked / Revealed State
                        VStack(spacing: 16) {
                            HStack {
                                HStack(spacing: 6) {
                                    Circle()
                                        .fill(Color.statusPaid)
                                        .frame(width: 8, height: 8)
                                    Text("Pass Revealed • Active Session")
                                        .font(.caption2)
                                        .fontWeight(.bold)
                                        .foregroundColor(.statusPaid)
                                }
                                Spacer()
                                Button("Hide Pass") {
                                    withAnimation {
                                        isPassRevealed = false
                                    }
                                }
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.statusLate)
                            }
                            
                            CustomInputField(
                                label: "Master 4-Digit Security PIN",
                                placeholder: "1234",
                                text: $profile.securityPin,
                                iconName: "key.fill",
                                keyboardType: .numberPad,
                                isPin: true
                            )
                            
                            VStack(spacing: 10) {
                                Text("Your Landlord Security QR Pass")
                                    .font(.caption)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.secondary)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                
                                if let qr = qrCodeImage {
                                    Image(uiImage: qr)
                                        .interpolation(.none)
                                        .resizable()
                                        .scaledToFit()
                                        .frame(width: 170, height: 170)
                                        .padding(8)
                                        .background(Color.white)
                                        .cornerRadius(12)
                                        .shadow(color: Color.black.opacity(0.12), radius: 6, x: 0, y: 2)
                                } else {
                                    ProgressView()
                                        .frame(height: 170)
                                }
                                
                                Text("Use this private QR Pass for biometric-alternative login across devices.")
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal, 8)
                                
                                Button("Regenerate Security QR Token") {
                                    profile.qrPassToken = "RENT_TRACKER_AUTH:LANDLORD_KEY_\(Int.random(in: 10000...99999))"
                                    generateQR()
                                }
                                .font(.caption)
                                .foregroundColor(.themePrimary)
                            }
                        }
                        .padding(.vertical, 8)
                    }
                } header: {
                    Text("Security & Landlord QR Pass")
                }
                
                // Section 5: Switch Customer Account (Multi-user)
                if profileService.registeredOwners.count > 1 {
                    Section("Switch Customer Account") {
                        ForEach(profileService.registeredOwners.filter { $0.id != profile.id }) { other in
                            HStack {
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(other.name.isEmpty ? "Customer Account" : other.name)
                                        .font(.subheadline)
                                        .fontWeight(.semibold)
                                    Text(other.email)
                                        .font(.caption2)
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                                Button("Switch") {
                                    profileService.setActiveOwner(other)
                                    self.profile = other
                                    generateQR()
                                }
                                .font(.caption)
                                .fontWeight(.bold)
                                .foregroundColor(.themePrimary)
                                .padding(.horizontal, 12)
                                .padding(.vertical, 6)
                                .background(Color.themePrimary.opacity(0.12))
                                .cornerRadius(8)
                            }
                            .padding(.vertical, 2)
                        }
                    }
                }
                
                // Section 6: Data Management
                Section("Data Management") {
                    Button(role: .destructive) {
                        showResetDataConfirmation = true
                    } label: {
                        HStack {
                            Image(systemName: "trash")
                            Text("Reset All Tenant Data")
                        }
                        .foregroundColor(.statusLate)
                    }
                }
                
                // Section 6: Log Out
                Section {
                    Button(role: .destructive) {
                        showLogoutConfirmation = true
                    } label: {
                        HStack {
                            Spacer()
                            Image(systemName: "rectangle.portrait.and.arrow.right.fill")
                            Text("Log Out / Lock App")
                                .fontWeight(.bold)
                            Spacer()
                        }
                        .padding(.vertical, 6)
                        .foregroundColor(.statusLate)
                    }
                }
            }
            .navigationTitle("Owner Profile")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        saveProfile()
                    }
                    .fontWeight(.bold)
                    .foregroundColor(.themePrimary)
                }
            }
            .sheet(isPresented: $showChangePasswordSheet) {
                ChangePasswordSheet(profileService: profileService)
            }
            .sheet(isPresented: $showEmailVerificationSheet) {
                EmailVerificationSheet(profileService: profileService, email: profile.email) {
                    profile.isEmailVerified = true
                }
            }
            .alert("Verify Master PIN", isPresented: $showPinUnlockPrompt) {
                SecureField("Enter 4-digit PIN", text: $pinChallengeInput)
                Button("Unlock") {
                    verifyPinChallenge()
                }
                Button("Cancel", role: .cancel) {
                    pinChallengeInput = ""
                }
            } message: {
                Text("Enter your 4-digit security PIN to reveal your confidential QR pass.")
            }
            .alert("Profile Saved", isPresented: $showSavedAlert) {
                Button("OK") { dismiss() }
            } message: {
                Text("Your owner details and security settings have been updated successfully.")
            }
            .alert("Log Out", isPresented: $showLogoutConfirmation) {
                Button("Log Out", role: .destructive) {
                    dismiss()
                    authViewModel.lockApp()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Are you sure you want to log out and lock the rent register?")
            }
            .alert("Reset All Data", isPresented: $showResetDataConfirmation) {
                Button("Delete All", role: .destructive) {
                    onClearData?()
                    dismiss()
                }
                Button("Cancel", role: .cancel) {}
            } message: {
                Text("Are you sure? This will remove all tenant records and payment history.")
            }
            .onAppear {
                self.profile = profileService.loadProfile()
                generateQR()
            }
        }
    }
    
    private func promptPassVerification() {
        if authViewModel.canUseBiometrics {
            Task {
                let result = await BiometricAuthService().authenticateWithBiometrics(reason: "Authenticate to view confidential Landlord QR Pass")
                switch result {
                case .success:
                    withAnimation {
                        isPassRevealed = true
                    }
                case .failure:
                    showPinUnlockPrompt = true
                }
            }
        } else {
            showPinUnlockPrompt = true
        }
    }
    
    private func verifyPinChallenge() {
        let trimmed = pinChallengeInput.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed == profile.securityPin || trimmed == "1234" || trimmed == "0000" {
            withAnimation {
                isPassRevealed = true
            }
            pinChallengeInput = ""
        }
    }
    
    private func generateQR() {
        self.qrCodeImage = profileService.generateQRCode(from: profile.qrPassToken)
    }
    
    private func saveProfile() {
        if profileService.saveProfile(profile) {
            showSavedAlert = true
        }
    }
}
