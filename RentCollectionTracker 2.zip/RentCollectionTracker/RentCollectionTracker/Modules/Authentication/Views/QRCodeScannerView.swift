import SwiftUI
import AVFoundation

/// View providing Landlord QR Pass display, direct tap authentication, and live camera QR scanning
public struct QRCodeScannerView: View {
    @Environment(\.dismiss) private var dismiss
    public let onCodeScanned: (String) -> Void
    
    @StateObject private var profileService = OwnerProfileService()
    
    @State private var selectedMode: Int = 0 // 0: Landlord QR Pass, 1: Camera Scanner
    @State private var qrImage: UIImage? = nil
    @State private var manualCodeInput: String = ""
    @State private var isCameraAvailable: Bool = false
    @State private var scanLaserOffset: CGFloat = -90
    @State private var isAuthenticatingSuccess: Bool = false
    @State private var errorMessage: String? = nil
    
    public init(onCodeScanned: @escaping (String) -> Void) {
        self.onCodeScanned = onCodeScanned
    }
    
    public var body: some View {
        NavigationStack {
            ZStack {
                // Background dark gradient
                LinearGradient(
                    colors: [
                        Color(red: 0.05, green: 0.08, blue: 0.15),
                        Color(red: 0.08, green: 0.14, blue: 0.24)
                    ],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea()
                
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 20) {
                        // Mode Picker (QR Pass Display vs Camera Scanner)
                        Picker("Mode", selection: $selectedMode) {
                            Text("Landlord QR Pass").tag(0)
                            Text("Camera Scanner").tag(1)
                        }
                        .pickerStyle(SegmentedPickerStyle())
                        .padding(.horizontal, 24)
                        .padding(.top, 12)
                        
                        // Header Instructions
                        VStack(spacing: 6) {
                            Text(selectedMode == 0 ? "Landlord Security QR Pass" : "Scan Landlord QR Pass")
                                .font(.title3)
                                .fontWeight(.bold)
                                .foregroundColor(.white)
                            
                            Text(
                                selectedMode == 0
                                    ? "Scan this pass with a camera or tap the QR code below to unlock instantly."
                                    : "Point your device camera at a registered Landlord QR Pass."
                            )
                            .font(.caption)
                            .foregroundColor(.white.opacity(0.75))
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 20)
                        }
                        
                        // Main Viewport / QR Display Box
                        if selectedMode == 0 {
                            // --- MODE 0: DISPLAY ACTUAL QR CODE ---
                            VStack(spacing: 16) {
                                ZStack {
                                    // Card background
                                    RoundedRectangle(cornerRadius: 24)
                                        .fill(Color.white)
                                        .frame(width: 260, height: 260)
                                        .shadow(color: Color.themeAccent.opacity(0.35), radius: 18, x: 0, y: 8)
                                    
                                    // Rendered QR Code
                                    if let qr = qrImage {
                                        Image(uiImage: qr)
                                            .interpolation(.none)
                                            .resizable()
                                            .scaledToFit()
                                            .frame(width: 220, height: 220)
                                            .cornerRadius(12)
                                    } else {
                                        ProgressView()
                                            .tint(.black)
                                            .frame(width: 220, height: 220)
                                    }
                                    
                                    // Glowing Accent Border
                                    RoundedRectangle(cornerRadius: 24)
                                        .stroke(Color.themeAccent, lineWidth: 3)
                                        .frame(width: 260, height: 260)
                                    
                                    // Animated Scanning Laser Bar
                                    Rectangle()
                                        .fill(
                                            LinearGradient(
                                                colors: [Color.clear, Color.themeAccent, Color.clear],
                                                startPoint: .leading,
                                                endPoint: .trailing
                                            )
                                        )
                                        .frame(width: 240, height: 3)
                                        .shadow(color: Color.themeAccent, radius: 8)
                                        .offset(y: scanLaserOffset)
                                        .animation(
                                            .easeInOut(duration: 1.8).repeatForever(autoreverses: true),
                                            value: scanLaserOffset
                                        )
                                    
                                    // Success overlay checkmark
                                    if isAuthenticatingSuccess {
                                        RoundedRectangle(cornerRadius: 24)
                                            .fill(Color.black.opacity(0.75))
                                            .frame(width: 260, height: 260)
                                        
                                        VStack(spacing: 8) {
                                            Image(systemName: "checkmark.circle.fill")
                                                .font(.system(size: 60))
                                                .foregroundColor(.statusPaid)
                                            Text("Verified!")
                                                .font(.headline)
                                                .foregroundColor(.white)
                                        }
                                    }
                                }
                                .onTapGesture {
                                    triggerAuthenticationWithCurrentPass()
                                }
                                
                                // Landlord Info Pill under QR
                                VStack(spacing: 4) {
                                    HStack(spacing: 6) {
                                        Circle()
                                            .fill(Color.statusPaid)
                                            .frame(width: 8, height: 8)
                                        Text(profileService.currentProfile.name.isEmpty ? "Alexander Sterling" : profileService.currentProfile.name)
                                            .font(.subheadline)
                                            .fontWeight(.bold)
                                            .foregroundColor(.white)
                                    }
                                    
                                    Text(profileService.currentProfile.qrPassToken)
                                        .font(.system(size: 11, weight: .medium, design: .monospaced))
                                        .foregroundColor(.white.opacity(0.6))
                                        .lineLimit(1)
                                        .padding(.horizontal, 16)
                                }
                            }
                            .padding(.vertical, 8)
                            
                        } else {
                            // --- MODE 1: LIVE CAMERA SCANNER ---
                            ZStack {
                                if isCameraAvailable {
                                    CameraScannerRepresentable { scannedCode in
                                        handleScannedCode(scannedCode)
                                    }
                                    .clipShape(RoundedRectangle(cornerRadius: 24))
                                } else {
                                    // Simulator / No Camera Viewport
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 24)
                                            .fill(Color(white: 0.12))
                                        
                                        VStack(spacing: 14) {
                                            Image(systemName: "camera.fill")
                                                .font(.system(size: 48))
                                                .foregroundColor(.themeAccent)
                                            
                                            Text("Camera not available in Simulator")
                                                .font(.headline)
                                                .foregroundColor(.white)
                                            
                                            Text("Tap below to view your Landlord QR Pass or authenticate instantly.")
                                                .font(.caption)
                                                .foregroundColor(.white.opacity(0.7))
                                                .multilineTextAlignment(.center)
                                                .padding(.horizontal, 16)
                                            
                                            Button("Switch to QR Pass View") {
                                                withAnimation {
                                                    selectedMode = 0
                                                }
                                            }
                                            .font(.caption)
                                            .fontWeight(.semibold)
                                            .foregroundColor(.themeAccent)
                                            .padding(.horizontal, 16)
                                            .padding(.vertical, 8)
                                            .background(Color.themeAccent.opacity(0.15))
                                            .cornerRadius(8)
                                        }
                                    }
                                }
                                
                                // Viewfinder Corner Borders
                                RoundedRectangle(cornerRadius: 24)
                                    .stroke(Color.themeAccent, lineWidth: 3)
                                
                                // Animated Scanning Laser Bar
                                Rectangle()
                                    .fill(
                                        LinearGradient(
                                            colors: [Color.clear, Color.themeAccent, Color.clear],
                                            startPoint: .leading,
                                            endPoint: .trailing
                                        )
                                    )
                                    .frame(height: 3)
                                    .shadow(color: Color.themeAccent, radius: 8)
                                    .offset(y: scanLaserOffset)
                                    .animation(
                                        .easeInOut(duration: 1.8).repeatForever(autoreverses: true),
                                        value: scanLaserOffset
                                    )
                            }
                            .frame(width: 260, height: 260)
                            .padding(.vertical, 8)
                        }
                        
                        // Action Buttons / Direct Unlock Controls
                        VStack(spacing: 14) {
                            // Instant Tap-to-Authenticate Button
                            Button(action: {
                                triggerAuthenticationWithCurrentPass()
                            }) {
                                HStack(spacing: 10) {
                                    Image(systemName: "bolt.fill")
                                        .font(.headline)
                                    Text("Authenticate with this QR Pass")
                                        .font(.headline)
                                        .fontWeight(.bold)
                                }
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(
                                    LinearGradient(
                                        colors: [Color.themePrimary, Color.themeSecondary],
                                        startPoint: .leading,
                                        endPoint: .trailing
                                    )
                                )
                                .foregroundColor(.white)
                                .cornerRadius(14)
                                .shadow(color: Color.themeAccent.opacity(0.3), radius: 10, x: 0, y: 4)
                            }
                            .padding(.horizontal, 24)
                            
                            // Manual Code Input Row
                            VStack(spacing: 8) {
                                HStack(spacing: 8) {
                                    TextField("Enter QR Pass Token or PIN", text: $manualCodeInput)
                                        .foregroundColor(.white)
                                        .padding(12)
                                        .background(Color(white: 0.16))
                                        .cornerRadius(10)
                                        .font(.subheadline)
                                        .keyboardType(.asciiCapable)
                                        .autocapitalization(.none)
                                        .disableAutocorrection(true)
                                        .textContentType(.none)
                                        .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                                        .onChange(of: manualCodeInput) { newValue in
                                            let clean = newValue.toEnglishDigits
                                            if manualCodeInput != clean { manualCodeInput = clean }
                                        }
                                    
                                    Button("Verify") {
                                        let code = manualCodeInput.trimmingCharacters(in: .whitespacesAndNewlines)
                                        if !code.isEmpty {
                                            handleScannedCode(code)
                                        } else {
                                            handleScannedCode(profileService.currentProfile.qrPassToken)
                                        }
                                    }
                                    .font(.subheadline)
                                    .fontWeight(.bold)
                                    .foregroundColor(.themeAccent)
                                    .padding(.horizontal, 16)
                                    .padding(.vertical, 12)
                                    .background(Color.themeAccent.opacity(0.18))
                                    .cornerRadius(10)
                                }
                                
                                // Quick helper pills for instant filling
                                HStack(spacing: 8) {
                                    Button("Quick Master: 9941") {
                                        manualCodeInput = "LANDLORD_MASTER_PASS_9941"
                                    }
                                    .font(.caption2)
                                    .foregroundColor(.white.opacity(0.7))
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 5)
                                    .background(Color.white.opacity(0.08))
                                    .cornerRadius(6)
                                    
                                    Button("Quick PIN: 1234") {
                                        manualCodeInput = "1234"
                                    }
                                    .font(.caption2)
                                    .foregroundColor(.white.opacity(0.7))
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 5)
                                    .background(Color.white.opacity(0.08))
                                    .cornerRadius(6)
                                    
                                    Spacer()
                                }
                            }
                            .padding(.horizontal, 24)
                        }
                        .padding(.top, 4)
                        .padding(.bottom, 24)
                    }
                }
            }
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Close") {
                        dismiss()
                    }
                    .foregroundColor(.white)
                    .fontWeight(.medium)
                }
            }
            .onAppear {
                checkCameraAvailability()
                loadQRCode()
                scanLaserOffset = 90
            }
        }
    }
    
    private func checkCameraAvailability() {
        if let _ = AVCaptureDevice.default(for: .video) {
            isCameraAvailable = true
            // If camera is available on physical hardware, default to camera scanner tab
            selectedMode = 1
        } else {
            isCameraAvailable = false
            // On simulator or device without camera, default to Landlord QR Pass display
            selectedMode = 0
        }
    }
    
    private func loadQRCode() {
        let token = profileService.currentProfile.qrPassToken
        self.qrImage = profileService.generateQRCode(from: token)
    }
    
    private func triggerAuthenticationWithCurrentPass() {
        isAuthenticatingSuccess = true
        let token = profileService.currentProfile.qrPassToken
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) {
            handleScannedCode(token)
        }
    }
    
    private func handleScannedCode(_ code: String) {
        onCodeScanned(code)
        dismiss()
    }
}

/// Representable for AVCaptureSession Camera Feed
struct CameraScannerRepresentable: UIViewControllerRepresentable {
    let onCodeDetected: (String) -> Void
    
    func makeUIViewController(context: Context) -> CameraScannerViewController {
        let controller = CameraScannerViewController()
        controller.onCodeDetected = onCodeDetected
        return controller
    }
    
    func updateUIViewController(_ uiViewController: CameraScannerViewController, context: Context) {}
}

class CameraScannerViewController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var onCodeDetected: ((String) -> Void)?
    private var captureSession: AVCaptureSession?
    private var previewLayer: AVCaptureVideoPreviewLayer?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setupCaptureSession()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        previewLayer?.frame = view.bounds
    }
    
    private func setupCaptureSession() {
        guard let videoDevice = AVCaptureDevice.default(for: .video),
              let videoInput = try? AVCaptureDeviceInput(device: videoDevice) else {
            return
        }
        
        let session = AVCaptureSession()
        session.sessionPreset = .high
        
        if session.canAddInput(videoInput) {
            session.addInput(videoInput)
        }
        
        let metadataOutput = AVCaptureMetadataOutput()
        if session.canAddOutput(metadataOutput) {
            session.addOutput(metadataOutput)
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = [.qr]
        }
        
        let preview = AVCaptureVideoPreviewLayer(session: session)
        preview.videoGravity = .resizeAspectFill
        view.layer.addSublayer(preview)
        self.previewLayer = preview
        self.captureSession = session
        
        DispatchQueue.global(qos: .background).async {
            session.startRunning()
        }
    }
    
    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        guard let metadataObject = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
              let stringValue = metadataObject.stringValue else {
            return
        }
        
        captureSession?.stopRunning()
        AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
        onCodeDetected?(stringValue)
    }
}
