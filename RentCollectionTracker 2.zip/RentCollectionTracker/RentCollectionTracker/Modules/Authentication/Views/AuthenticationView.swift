import SwiftUI

/// Main Launch Screen Authentication & Login Page supporting multi-customer registration and login
public struct AuthenticationView: View {
    @ObservedObject var viewModel: AuthViewModel
    @ObservedObject private var profileService = OwnerProfileService.shared
    
    @State private var pulseAnimation = false
    @State private var activeAuthTab: Int = 0 // 0: Sign In, 1: Register Customer
    
    // Inline Registration fields (Strictly English ASCII)
    @State private var regName: String = ""
    @State private var regCompany: String = ""
    @State private var regEmail: String = ""
    @State private var regPhone: String = ""
    @State private var regPassword: String = ""
    @State private var regPin: String = ""
    @State private var regErrorMessage: String? = nil
    
    public init(viewModel: AuthViewModel) {
        self.viewModel = viewModel
    }
    
    public var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(
                colors: [
                    Color(red: 0.06, green: 0.12, blue: 0.22),
                    Color(red: 0.08, green: 0.22, blue: 0.38)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {
                    Spacer(minLength: 16)
                    
                    // App Logo & Brand Header
                    VStack(spacing: 10) {
                        ZStack {
                            Circle()
                                .stroke(Color.themeAccent.opacity(0.3), lineWidth: 2)
                                .frame(width: 88, height: 88)
                                .scaleEffect(pulseAnimation ? 1.12 : 1.0)
                                .opacity(pulseAnimation ? 0.3 : 0.8)
                                .animation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true), value: pulseAnimation)
                            
                            Circle()
                                .fill(
                                    LinearGradient(
                                        colors: [Color.themePrimary, Color.themeSecondary],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 70, height: 70)
                                .shadow(color: Color.themeAccent.opacity(0.4), radius: 12, x: 0, y: 6)
                            
                            Image(systemName: "building.2.crop.circle.fill")
                                .font(.system(size: 34))
                                .foregroundColor(.white)
                        }
                        
                        Text(AppConstants.appName)
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        
                        Text("Landlord & Property Owner Portal")
                            .font(.subheadline)
                            .foregroundColor(.white.opacity(0.8))
                    }
                    .padding(.top, 12)
                    
                    // Main Card: Sign In vs Register New Customer
                    VStack(spacing: 16) {
                        // Top Tab: Sign In vs Register
                        Picker("Account Action", selection: $activeAuthTab) {
                            Text("Sign In").tag(0)
                            Text("Register Customer").tag(1)
                        }
                        .pickerStyle(.segmented)
                        .padding(.bottom, 4)
                        
                        if activeAuthTab == 0 {
                            // ==================== SIGN IN TAB ====================
                            signInSection
                        } else {
                            // ==================== REGISTER CUSTOMER TAB ====================
                            registerCustomerSection
                        }
                    }
                    .padding(20)
                    .background(Color.white.opacity(0.08))
                    .cornerRadius(20)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color.white.opacity(0.15), lineWidth: 1)
                    )
                    .padding(.horizontal, 22)
                    
                    // Alternative Unlock Options (Face ID & QR Scanner)
                    VStack(spacing: 10) {
                        if viewModel.canUseBiometrics {
                            Button(action: {
                                viewModel.triggerBiometricAuthentication()
                            }) {
                                HStack(spacing: 8) {
                                    Image(systemName: "faceid")
                                    Text("Unlock with \(viewModel.biometryTypeDescription)")
                                        .fontWeight(.semibold)
                                }
                                .font(.subheadline)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(Color.white.opacity(0.12))
                                .foregroundColor(.white)
                                .cornerRadius(12)
                            }
                        }
                        
                        Button(action: {
                            viewModel.isQRScannerPresented = true
                        }) {
                            HStack(spacing: 8) {
                                Image(systemName: "qrcode.viewfinder")
                                Text("Scan Landlord QR Pass")
                                    .fontWeight(.semibold)
                            }
                            .font(.subheadline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(Color.white.opacity(0.12))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                        }
                    }
                    .padding(.horizontal, 22)
                    
                    Spacer(minLength: 20)
                }
            }
        }
        .sheet(isPresented: $viewModel.isQRScannerPresented) {
            QRCodeScannerView { scannedCode in
                viewModel.authenticateWithQRCode(token: scannedCode)
            }
        }
        .onAppear {
            pulseAnimation = true
            if viewModel.canUseBiometrics {
                viewModel.triggerBiometricAuthentication()
            }
        }
    }
    
    // MARK: - Sign In Subview
    private var signInSection: some View {
        VStack(spacing: 16) {
            // Mode Picker: PIN vs Email/Password
            Picker("Sign In Method", selection: $viewModel.isPinMode) {
                Text("Security PIN").tag(true)
                Text("Email / Password").tag(false)
            }
            .pickerStyle(.segmented)
            
            // Registered accounts quick switcher (if accounts exist)
            if profileService.registeredOwners.count > 1 {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Select Customer Account:")
                        .font(.caption2)
                        .foregroundColor(.white.opacity(0.7))
                    
                    ScrollView(.horizontal, showsIndicators: false) {
                        HStack(spacing: 8) {
                            ForEach(profileService.registeredOwners) { owner in
                                Button(action: {
                                    profileService.setActiveOwner(owner)
                                    viewModel.emailInput = owner.email
                                }) {
                                    HStack(spacing: 6) {
                                        Circle()
                                            .fill(profileService.currentProfile.id == owner.id ? Color.themeAccent : Color.white.opacity(0.2))
                                            .frame(width: 8, height: 8)
                                        Text(owner.name.isEmpty ? "Owner" : owner.name)
                                            .font(.caption)
                                            .fontWeight(.semibold)
                                    }
                                    .padding(.horizontal, 10)
                                    .padding(.vertical, 6)
                                    .background(
                                        profileService.currentProfile.id == owner.id
                                            ? Color.themeAccent.opacity(0.25)
                                            : Color.white.opacity(0.1)
                                    )
                                    .foregroundColor(.white)
                                    .cornerRadius(8)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(profileService.currentProfile.id == owner.id ? Color.themeAccent : Color.clear, lineWidth: 1)
                                    )
                                }
                            }
                        }
                    }
                }
            }
            
            if viewModel.isPinMode {
                // PIN Mode
                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("Master 4-Digit Security PIN")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.white.opacity(0.8))
                        Spacer()
                        Button("Hint: 1234") {
                            viewModel.pinInput = "1234"
                        }
                        .font(.caption2)
                        .foregroundColor(.themeAccent)
                    }
                    
                    HStack {
                        Image(systemName: "key.fill")
                            .foregroundColor(.themeAccent)
                        SecureField("Enter 4-digit PIN", text: $viewModel.pinInput)
                            .keyboardType(.asciiCapableNumberPad)
                            .autocorrectionDisabled(true)
                            .textContentType(.none)
                            .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                            .foregroundColor(.white)
                            .font(.title3)
                            .onChange(of: viewModel.pinInput) { newValue in
                                let clean = newValue.toEnglishPin
                                if viewModel.pinInput != clean { viewModel.pinInput = clean }
                            }
                    }
                    .padding(13)
                    .background(Color.white.opacity(0.12))
                    .cornerRadius(12)
                    .overlay(
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.white.opacity(0.2), lineWidth: 1)
                    )
                }
            } else {
                // Email / Password Mode
                VStack(spacing: 12) {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Customer Email Address")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.white.opacity(0.8))
                        
                        HStack {
                            Image(systemName: "envelope.fill")
                                .foregroundColor(.themeAccent)
                            TextField("e.g. owner@renttracker.com", text: $viewModel.emailInput)
                                .keyboardType(.asciiCapable)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled(true)
                                .textContentType(.none)
                                .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                                .foregroundColor(.white)
                        }
                        .padding(13)
                        .background(Color.white.opacity(0.12))
                        .cornerRadius(12)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.white.opacity(0.2), lineWidth: 1)
                        )
                    }
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Password")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.white.opacity(0.8))
                        
                        HStack {
                            Image(systemName: "lock.fill")
                                .foregroundColor(.themeAccent)
                            SecureField("Enter password", text: $viewModel.passwordInput)
                                .keyboardType(.asciiCapable)
                                .textInputAutocapitalization(.never)
                                .autocorrectionDisabled(true)
                                .textContentType(.none)
                                .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                                .foregroundColor(.white)
                        }
                        .padding(13)
                        .background(Color.white.opacity(0.12))
                        .cornerRadius(12)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.white.opacity(0.2), lineWidth: 1)
                        )
                    }
                }
            }
            
            // Error banner if any
            if let error = viewModel.errorMessage {
                VStack(alignment: .leading, spacing: 4) {
                    HStack(spacing: 6) {
                        Image(systemName: "exclamationmark.triangle.fill")
                            .foregroundColor(.white)
                        Text(error)
                            .font(.caption)
                            .foregroundColor(.white)
                    }
                    
                    if !viewModel.emailInput.isEmpty && !profileService.isEmailRegistered(viewModel.emailInput) {
                        Button("Create new customer account for \"\(viewModel.emailInput)\"?") {
                            regEmail = viewModel.emailInput
                            regPassword = viewModel.passwordInput
                            activeAuthTab = 1
                        }
                        .font(.caption2)
                        .fontWeight(.bold)
                        .foregroundColor(.yellow)
                        .padding(.top, 2)
                    }
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.statusLate.opacity(0.9))
                .cornerRadius(10)
            }
            
            // Sign In Action Button
            Button(action: {
                viewModel.performManualLogin()
            }) {
                HStack(spacing: 8) {
                    Text("Unlock & Sign In")
                        .fontWeight(.bold)
                    Image(systemName: "arrow.right.circle.fill")
                }
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(
                    LinearGradient(
                        colors: [Color.themePrimary, Color.themeSecondary],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .foregroundColor(.white)
                .cornerRadius(12)
                .shadow(color: Color.themeAccent.opacity(0.35), radius: 8, x: 0, y: 4)
            }
        }
    }
    
    // MARK: - Register Customer Subview
    private var registerCustomerSection: some View {
        VStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text("Register Customer / Owner Account")
                    .font(.subheadline)
                    .fontWeight(.bold)
                    .foregroundColor(.white)
                Text("Creates a private profile and isolated rent ledger for this customer.")
                    .font(.caption2)
                    .foregroundColor(.white.opacity(0.7))
            }
            .frame(maxWidth: .infinity, alignment: .leading)
            
            // Customer Name
            VStack(alignment: .leading, spacing: 4) {
                Text("Customer Full Name *")
                    .font(.caption2)
                    .fontWeight(.semibold)
                    .foregroundColor(.white.opacity(0.8))
                
                HStack {
                    Image(systemName: "person.fill")
                        .foregroundColor(.themeAccent)
                    TextField("e.g. Shane or Alexander", text: $regName)
                        .keyboardType(.asciiCapable)
                        .autocorrectionDisabled(true)
                        .textContentType(.none)
                        .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                        .foregroundColor(.white)
                        .onChange(of: regName) { newValue in
                            let clean = newValue.toEnglishDigits
                            if regName != clean { regName = clean }
                        }
                }
                .padding(11)
                .background(Color.white.opacity(0.12))
                .cornerRadius(10)
            }
            
            // Email Address
            VStack(alignment: .leading, spacing: 4) {
                Text("Email Address (Unique Login) *")
                    .font(.caption2)
                    .fontWeight(.semibold)
                    .foregroundColor(.white.opacity(0.8))
                
                HStack {
                    Image(systemName: "envelope.fill")
                        .foregroundColor(.themeAccent)
                    TextField("e.g. shane@example.com", text: $regEmail)
                        .keyboardType(.asciiCapable)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled(true)
                        .textContentType(.none)
                        .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                        .foregroundColor(.white)
                }
                .padding(11)
                .background(Color.white.opacity(0.12))
                .cornerRadius(10)
            }
            
            // Password & 4-digit PIN row
            HStack(spacing: 10) {
                VStack(alignment: .leading, spacing: 4) {
                    Text("Password (min 6) *")
                        .font(.caption2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white.opacity(0.8))
                    
                    HStack {
                        Image(systemName: "lock.fill")
                            .foregroundColor(.themeAccent)
                        SecureField("Password", text: $regPassword)
                            .keyboardType(.asciiCapable)
                            .textInputAutocapitalization(.never)
                            .autocorrectionDisabled(true)
                            .textContentType(.none)
                            .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                            .foregroundColor(.white)
                    }
                    .padding(11)
                    .background(Color.white.opacity(0.12))
                    .cornerRadius(10)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text("4-Digit PIN *")
                        .font(.caption2)
                        .fontWeight(.semibold)
                        .foregroundColor(.white.opacity(0.8))
                    
                    HStack {
                        Image(systemName: "key.fill")
                            .foregroundColor(.themeAccent)
                        SecureField("e.g. 1234", text: $regPin)
                            .keyboardType(.asciiCapableNumberPad)
                            .autocorrectionDisabled(true)
                            .textContentType(.none)
                            .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                            .foregroundColor(.white)
                            .onChange(of: regPin) { newValue in
                                let clean = newValue.toEnglishPin
                                if regPin != clean { regPin = clean }
                            }
                    }
                    .padding(11)
                    .background(Color.white.opacity(0.12))
                    .cornerRadius(10)
                }
            }
            
            // Phone Number (Strict English)
            VStack(alignment: .leading, spacing: 4) {
                Text("Contact Phone (Optional, English Numbers)")
                    .font(.caption2)
                    .fontWeight(.semibold)
                    .foregroundColor(.white.opacity(0.8))
                
                HStack {
                    Image(systemName: "phone.fill")
                        .foregroundColor(.themeAccent)
                    TextField("e.g. +1 555-0199", text: $regPhone)
                        .keyboardType(.asciiCapableNumberPad)
                        .autocorrectionDisabled(true)
                        .textContentType(.none)
                        .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                        .foregroundColor(.white)
                        .onChange(of: regPhone) { newValue in
                            let clean = newValue.toEnglishPhoneNumber
                            if regPhone != clean { regPhone = clean }
                        }
                }
                .padding(11)
                .background(Color.white.opacity(0.12))
                .cornerRadius(10)
            }
            
            // Error banner if any
            if let error = regErrorMessage {
                HStack(spacing: 6) {
                    Image(systemName: "exclamationmark.triangle.fill")
                        .foregroundColor(.white)
                    Text(error)
                        .font(.caption2)
                        .foregroundColor(.white)
                }
                .padding(8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.statusLate.opacity(0.9))
                .cornerRadius(8)
            }
            
            // Create Customer Account Button
            Button(action: {
                performCustomerRegistration()
            }) {
                HStack(spacing: 8) {
                    Image(systemName: "person.badge.plus.fill")
                    Text("Create Account & Sign In")
                        .fontWeight(.bold)
                }
                .font(.headline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(
                    LinearGradient(
                        colors: [Color.themeSecondary, Color.themeAccent],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .foregroundColor(.white)
                .cornerRadius(12)
                .shadow(color: Color.themeAccent.opacity(0.35), radius: 8, x: 0, y: 4)
            }
        }
    }
    
    private func performCustomerRegistration() {
        regErrorMessage = nil
        let trimmedName = regName.toEnglishDigits.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedEmail = regEmail.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPass = regPassword.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPin = regPin.toEnglishPin.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPhone = regPhone.toEnglishPhoneNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard !trimmedName.isEmpty else {
            regErrorMessage = "Please enter customer name."
            return
        }
        guard !trimmedEmail.isEmpty && trimmedEmail.contains("@") && trimmedEmail.contains(".") else {
            regErrorMessage = "Please enter a valid email address."
            return
        }
        guard trimmedPass.count >= 6 else {
            regErrorMessage = "Password must be at least 6 characters."
            return
        }
        guard trimmedPin.count == 4 else {
            regErrorMessage = "Security PIN must be 4 English digits."
            return
        }
        
        let result = viewModel.registerNewLandlord(
            name: trimmedName,
            company: regCompany,
            email: trimmedEmail,
            phone: trimmedPhone,
            pin: trimmedPin,
            password: trimmedPass
        )
        
        switch result {
        case .success:
            regErrorMessage = nil
        case .failure(let err):
            regErrorMessage = err.localizedDescription
        }
    }
}
