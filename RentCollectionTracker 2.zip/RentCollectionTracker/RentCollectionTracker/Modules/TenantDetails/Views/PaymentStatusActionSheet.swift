import SwiftUI

/// Modal sheet for recording rent payments or updating tenant payment status dynamically
public struct PaymentStatusActionSheet: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var viewModel: TenantDetailViewModel
    
    @State private var selectedStatus: PaymentStatus
    @State private var paymentAmountText: String
    @State private var selectedMethod: PaymentMethod = .bankTransfer
    @State private var paymentDate: Date = Date()
    @State private var paymentNotes: String = ""
    
    public init(viewModel: TenantDetailViewModel) {
        self.viewModel = viewModel
        let initialStatus = viewModel.tenant?.currentStatus ?? .paid
        _selectedStatus = State(initialValue: initialStatus)
        _paymentAmountText = State(initialValue: String(format: "%.0f", viewModel.tenant?.monthlyRent ?? 0))
    }
    
    public var body: some View {
        NavigationStack {
            Form {
                Section {
                    Picker("Payment Status", selection: $selectedStatus) {
                        ForEach(PaymentStatus.allCases) { status in
                            HStack {
                                Image(systemName: status.iconName)
                                Text(status.title)
                            }
                            .tag(status)
                        }
                    }
                    .pickerStyle(.segmented)
                    .padding(.vertical, 4)
                } header: {
                    Text("Select Status")
                } footer: {
                    Text(statusExplanation)
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                
                if selectedStatus == .paid {
                    Section("Dynamic Payment Details") {
                        HStack {
                            Text("Amount Paid ($)")
                                .fontWeight(.medium)
                            Spacer()
                            TextField("Amount", text: $paymentAmountText)
                                .keyboardType(.asciiCapableNumberPad)
                                .autocorrectionDisabled(true)
                                .textContentType(.none)
                                .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                                .multilineTextAlignment(.trailing)
                                .onChange(of: paymentAmountText) { newValue in
                                    let clean = newValue.toEnglishNumericAmount
                                    if paymentAmountText != clean {
                                        paymentAmountText = clean
                                    }
                                }
                        }
                        
                        Picker("Payment Method", selection: $selectedMethod) {
                            ForEach(PaymentMethod.allCases) { method in
                                HStack {
                                    Image(systemName: method.iconName)
                                    Text(method.rawValue)
                                }
                                .tag(method)
                            }
                        }
                        
                        DatePicker(
                            selection: $paymentDate,
                            displayedComponents: .date
                        ) {
                            Text("Payment Date")
                                .fontWeight(.medium)
                        }
                        .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                        
                        VStack(alignment: .leading, spacing: 6) {
                            Text("Receipt Note / Reference (optional)")
                                .font(.caption)
                                .foregroundColor(.secondary)
                            TextField("e.g. Transaction Ref #, check number, etc.", text: $paymentNotes)
                                .keyboardType(.asciiCapable)
                                .autocorrectionDisabled(true)
                                .textContentType(.none)
                                .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                                .onChange(of: paymentNotes) { newValue in
                                    let clean = newValue.toEnglishDigits
                                    if paymentNotes != clean {
                                        paymentNotes = clean
                                    }
                                }
                        }
                    }
                }
            }
            .navigationTitle("Update Payment Status")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        saveChanges()
                        dismiss()
                    }
                    .fontWeight(.bold)
                    .foregroundColor(.themePrimary)
                }
            }
        }
    }
    
    private var statusExplanation: String {
        switch selectedStatus {
        case .paid:
            return "Marking as Paid generates a receipt and records the transaction in tenant payment history."
        case .pending:
            return "Pending indicates the monthly rent is expected but not yet received."
        case .late:
            return "Late highlights this tenant as overdue across dashboard metrics and the tenant register."
        }
    }
    
    private func saveChanges() {
        if selectedStatus == .paid {
            let cleanAmount = paymentAmountText.toEnglishNumericAmount
            let amount = Double(cleanAmount) ?? (viewModel.tenant?.monthlyRent ?? 0.0)
            let note = paymentNotes.isEmpty ? "Payment recorded on \(paymentDate.toMediumDateString())" : paymentNotes
            viewModel.recordCustomPayment(
                amount: amount,
                method: selectedMethod,
                paymentDate: paymentDate,
                monthYear: paymentDate.toMonthYearString(),
                notes: note
            )
        } else {
            viewModel.changePaymentStatus(to: selectedStatus)
        }
    }
}
