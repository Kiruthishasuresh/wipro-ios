import SwiftUI
@main
struct RentCollectionTrackerApp: App {
    @StateObject private var repository = TenantRepository()
    @StateObject private var authViewModel = AuthViewModel()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(repository)
                .environmentObject(authViewModel)
        }
    }
}
struct ContentView: View {
    @EnvironmentObject private var repository: TenantRepository
    @EnvironmentObject private var authViewModel: AuthViewModel
    @State private var selectedTab: Int = 0
    @State private var externalFilterStatus: PaymentStatus? = nil
    var body: some View {
        Group {
            if authViewModel.isAuthenticated {
                MainTabView(
                    repository: repository,
                    selectedTab: $selectedTab,
                    externalFilterStatus: $externalFilterStatus
                )
                .transition(.opacity.combined(with: .scale(scale: 0.98)))
            } else {
                AuthenticationView(viewModel: authViewModel)
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.35), value: authViewModel.isAuthenticated)
    }
}
struct MainTabView: View {
    let repository: TenantRepository
    @EnvironmentObject private var authViewModel: AuthViewModel
    
    @Binding var selectedTab: Int
    @Binding var externalFilterStatus: PaymentStatus?
    
    @StateObject private var dashboardViewModel: DashboardViewModel
    @StateObject private var tenantListViewModel: TenantListViewModel
    
    init(repository: TenantRepository, selectedTab: Binding<Int>, externalFilterStatus: Binding<PaymentStatus?>) {
        self.repository = repository
        self._selectedTab = selectedTab
        self._externalFilterStatus = externalFilterStatus
        _dashboardViewModel = StateObject(wrappedValue: DashboardViewModel(repository: repository))
        _tenantListViewModel = StateObject(wrappedValue: TenantListViewModel(repository: repository))
    }
    
    var body: some View {
        TabView(selection: $selectedTab) {
            DashboardView(
                viewModel: dashboardViewModel,
                authViewModel: authViewModel,
                selectedTab: $selectedTab,
                externalFilterStatus: $externalFilterStatus
            )
            .tabItem {
                Label("Dashboard", systemImage: "chart.pie.fill")
            }
            .tag(0)
            
            TenantListView(viewModel: tenantListViewModel)
                .tabItem {
                    Label("Tenants", systemImage: "person.2.fill")
                }
                .tag(1)
        }
        .tint(Color.themePrimary)
        .onChange(of: externalFilterStatus) { _, newStatus in
            if let newStatus = newStatus {
                tenantListViewModel.selectedStatusFilter = newStatus
            }
        }
        .sheet(isPresented: $dashboardViewModel.isAddTenantPresented) {
            AddTenantView(repository: repository)
        }
    }
}
