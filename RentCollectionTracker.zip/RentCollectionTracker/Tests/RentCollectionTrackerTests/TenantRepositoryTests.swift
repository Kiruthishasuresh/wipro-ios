import XCTest
@testable import RentCollectionTracker

/// Mock Persistence Service for isolated unit testing
final class MockPersistenceService: PersistenceServiceProtocol {
    var storedTenants: [Tenant] = []
    
    init(initialTenants: [Tenant] = []) {
        self.storedTenants = initialTenants
    }
    
    func loadTenants() -> [Tenant] {
        return storedTenants
    }
    
    func saveTenants(_ tenants: [Tenant]) -> Bool {
        self.storedTenants = tenants
        return true
    }
    
    func clearAllData() -> Bool {
        self.storedTenants = []
        return true
    }
}

final class TenantRepositoryTests: XCTestCase {
    
    var repository: TenantRepository!
    var mockPersistence: MockPersistenceService!
    
    override func setUp() {
        super.setUp()
        mockPersistence = MockPersistenceService()
        repository = TenantRepository(persistenceService: mockPersistence)
    }
    
    override func tearDown() {
        repository = nil
        mockPersistence = nil
        super.tearDown()
    }
    
    func testAddAndFetchTenant() {
        let tenant = Tenant(
            name: "Alice Wonderland",
            phoneNumber: "555-0100",
            propertyUnit: "Unit 1A",
            monthlyRent: 1200.0,
            rentDueDay: 1,
            advanceAmount: 1200.0,
            currentStatus: .pending
        )
        
        let result = repository.addTenant(tenant)
        if case .failure(let err) = result { XCTFail("Expected success, got: \(err)") }
        XCTAssertEqual(repository.tenants.count, 1)
        XCTAssertEqual(repository.getTenant(byId: tenant.id)?.name, "Alice Wonderland")
    }
    
    func testUpdateTenant() {
        var tenant = Tenant(
            name: "Bob Builder",
            phoneNumber: "555-0200",
            propertyUnit: "Unit 2B",
            monthlyRent: 1400.0
        )
        _ = repository.addTenant(tenant)
        
        // Rent revision
        tenant.monthlyRent = 1600.0
        tenant.phoneNumber = "555-9999"
        let updateResult = repository.updateTenant(tenant)
        
        if case .failure(let err) = updateResult { XCTFail("Expected success, got: \(err)") }
        let fetched = repository.getTenant(byId: tenant.id)
        XCTAssertEqual(fetched?.monthlyRent, 1600.0)
        XCTAssertEqual(fetched?.phoneNumber, "555-9999")
    }
    
    func testDeleteTenant() {
        let tenant = Tenant(
            name: "Charlie Brown",
            phoneNumber: "555-0300",
            propertyUnit: "Unit 3C",
            monthlyRent: 1100.0
        )
        _ = repository.addTenant(tenant)
        XCTAssertEqual(repository.tenants.count, 1)
        
        let deleteResult = repository.deleteTenant(byId: tenant.id)
        if case .failure(let err) = deleteResult { XCTFail("Expected success, got: \(err)") }
        XCTAssertEqual(repository.tenants.count, 0)
        XCTAssertNil(repository.getTenant(byId: tenant.id))
    }
    
    func testUpdatePaymentStatusToPaidGeneratesRecord() {
        let tenant = Tenant(
            name: "Diana Prince",
            phoneNumber: "555-0400",
            propertyUnit: "Unit 4D",
            monthlyRent: 2000.0,
            currentStatus: .pending
        )
        _ = repository.addTenant(tenant)
        
        let updateResult = repository.updatePaymentStatus(tenantId: tenant.id, newStatus: .paid)
        if case .failure(let err) = updateResult { XCTFail("Expected success, got: \(err)") }
        
        let fetched = repository.getTenant(byId: tenant.id)
        XCTAssertEqual(fetched?.currentStatus, .paid)
        XCTAssertEqual(fetched?.paymentHistory.count, 1)
        XCTAssertEqual(fetched?.paymentHistory.first?.amount, 2000.0)
        XCTAssertEqual(fetched?.paymentHistory.first?.tenantName, "Diana Prince")
    }
}
