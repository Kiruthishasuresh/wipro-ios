import XCTest
@testable import RentCollectionTracker

@MainActor
final class DashboardViewModelTests: XCTestCase {
    
    func testDashboardMetricsCalculation() {
        let tenant1 = Tenant(
            name: "Tenant 1",
            phoneNumber: "111",
            propertyUnit: "Unit 1",
            monthlyRent: 1000.0,
            currentStatus: .paid
        )
        let tenant2 = Tenant(
            name: "Tenant 2",
            phoneNumber: "222",
            propertyUnit: "Unit 2",
            monthlyRent: 1500.0,
            currentStatus: .pending
        )
        let tenant3 = Tenant(
            name: "Tenant 3",
            phoneNumber: "333",
            propertyUnit: "Unit 3",
            monthlyRent: 2000.0,
            currentStatus: .late
        )
        
        let mockPersistence = MockPersistenceService(initialTenants: [tenant1, tenant2, tenant3])
        let repository = TenantRepository(persistenceService: mockPersistence)
        let viewModel = DashboardViewModel(repository: repository)
        
        XCTAssertEqual(viewModel.totalTenantsCount, 3)
        XCTAssertEqual(viewModel.rentCollectedThisMonth, 1000.0)
        XCTAssertEqual(viewModel.rentPendingThisMonth, 1500.0)
        XCTAssertEqual(viewModel.lateTenantsCount, 1)
        XCTAssertEqual(viewModel.lateRentAmount, 2000.0)
        XCTAssertEqual(viewModel.totalExpectedRent, 4500.0)
        XCTAssertEqual(viewModel.collectionPercentage, 1000.0 / 4500.0, accuracy: 0.001)
    }
}
