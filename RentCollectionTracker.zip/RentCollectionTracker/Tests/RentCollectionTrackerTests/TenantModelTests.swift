import XCTest
@testable import RentCollectionTracker

final class TenantModelTests: XCTestCase {
    
    func testTenantInitializationAndComputedProperties() {
        let tenant = Tenant(
            name: "John Alexander Doe",
            phoneNumber: "+1 555-1234",
            email: "john@example.com",
            propertyUnit: "Building 10 - Unit 4B",
            monthlyRent: 2150.0,
            rentDueDay: 5,
            advanceAmount: 3000.0,
            notes: "Test notes",
            currentStatus: .pending
        )
        
        XCTAssertEqual(tenant.name, "John Alexander Doe")
        XCTAssertEqual(tenant.initials, "JA")
        XCTAssertEqual(tenant.formattedRent, "$2,150.00")
        XCTAssertEqual(tenant.formattedAdvance, "$3,000.00")
        XCTAssertEqual(tenant.dueDayDescription, "5th of month")
        XCTAssertEqual(tenant.currentStatus, .pending)
    }
    
    func testPaymentStatusPriorities() {
        XCTAssertTrue(PaymentStatus.late.sortPriority < PaymentStatus.pending.sortPriority)
        XCTAssertTrue(PaymentStatus.pending.sortPriority < PaymentStatus.paid.sortPriority)
    }
    
    func testPaymentRecordCreation() {
        let tenantId = UUID()
        let record = PaymentRecord(
            tenantId: tenantId,
            tenantName: "John Doe",
            propertyUnit: "Unit 4B",
            amount: 1500.0,
            paymentMethod: .zelle,
            notes: "Zelle confirmation"
        )
        
        XCTAssertEqual(record.amount, 1500.0)
        XCTAssertEqual(record.paymentMethod, .zelle)
        XCTAssertEqual(record.tenantName, "John Doe")
        XCTAssertTrue(record.receiptNumber.hasPrefix("REC-"))
    }
}
