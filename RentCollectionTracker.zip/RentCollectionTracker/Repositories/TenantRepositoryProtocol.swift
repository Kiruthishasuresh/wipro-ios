import Foundation
import Combine

/// Protocol abstracting Tenant Data Operations for clean MVVM testability
public protocol TenantRepositoryProtocol: AnyObject {
    var tenantsPublisher: Published<[Tenant]>.Publisher { get }
    var tenants: [Tenant] { get }
    
    func getAllTenants() -> [Tenant]
    func getTenant(byId id: UUID) -> Tenant?
    func addTenant(_ tenant: Tenant) -> Result<Void, Error>
    func updateTenant(_ tenant: Tenant) -> Result<Void, Error>
    func deleteTenant(byId id: UUID) -> Result<Void, Error>
    func updatePaymentStatus(tenantId: UUID, newStatus: PaymentStatus) -> Result<Void, Error>
    func recordPayment(tenantId: UUID, record: PaymentRecord, newStatus: PaymentStatus) -> Result<Void, Error>
    func clearAllData()
    func refreshData()
}
