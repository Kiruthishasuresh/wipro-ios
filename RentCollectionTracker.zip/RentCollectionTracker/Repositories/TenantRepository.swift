import Foundation
import Combine

public enum RepositoryError: LocalizedError {
    case tenantNotFound
    case persistenceFailed
    
    public var errorDescription: String? {
        switch self {
        case .tenantNotFound:
            return "The requested tenant was not found."
        case .persistenceFailed:
            return "Failed to save changes to storage."
        }
    }
}

/// Concrete implementation of TenantRepository maintaining in-memory state and disk persistence
public final class TenantRepository: ObservableObject, TenantRepositoryProtocol {
    @Published public private(set) var tenants: [Tenant] = []
    public var tenantsPublisher: Published<[Tenant]>.Publisher { $tenants }
    
    private let persistenceService: PersistenceServiceProtocol
    
    public init(persistenceService: PersistenceServiceProtocol = PersistenceService()) {
        self.persistenceService = persistenceService
        loadInitialData()
    }
    
    private func loadInitialData() {
        self.tenants = persistenceService.loadTenants()
    }
    
    public func refreshData() {
        self.tenants = persistenceService.loadTenants()
    }
    
    public func getAllTenants() -> [Tenant] {
        return tenants
    }
    
    public func getTenant(byId id: UUID) -> Tenant? {
        return tenants.first { $0.id == id }
    }
    
    public func addTenant(_ tenant: Tenant) -> Result<Void, Error> {
        var updatedList = tenants
        updatedList.insert(tenant, at: 0)
        
        if persistenceService.saveTenants(updatedList) {
            self.tenants = updatedList
            return .success(())
        } else {
            return .failure(RepositoryError.persistenceFailed)
        }
    }
    
    public func updateTenant(_ tenant: Tenant) -> Result<Void, Error> {
        guard let index = tenants.firstIndex(where: { $0.id == tenant.id }) else {
            return .failure(RepositoryError.tenantNotFound)
        }
        
        var updatedList = tenants
        var updatedTenant = tenant
        updatedTenant.lastUpdatedDate = Date()
        updatedList[index] = updatedTenant
        
        if persistenceService.saveTenants(updatedList) {
            self.tenants = updatedList
            return .success(())
        } else {
            return .failure(RepositoryError.persistenceFailed)
        }
    }
    
    public func deleteTenant(byId id: UUID) -> Result<Void, Error> {
        guard let index = tenants.firstIndex(where: { $0.id == id }) else {
            return .failure(RepositoryError.tenantNotFound)
        }
        
        var updatedList = tenants
        updatedList.remove(at: index)
        
        if persistenceService.saveTenants(updatedList) {
            self.tenants = updatedList
            return .success(())
        } else {
            return .failure(RepositoryError.persistenceFailed)
        }
    }
    
    public func updatePaymentStatus(tenantId: UUID, newStatus: PaymentStatus) -> Result<Void, Error> {
        guard let index = tenants.firstIndex(where: { $0.id == tenantId }) else {
            return .failure(RepositoryError.tenantNotFound)
        }
        
        var updatedList = tenants
        var tenant = updatedList[index]
        tenant.currentStatus = newStatus
        tenant.lastUpdatedDate = Date()
        
        // If status changed to Paid, automatically record dynamic receipt with tenant's actual name and unit
        if newStatus == .paid {
            let record = PaymentRecord(
                tenantId: tenantId,
                tenantName: tenant.name,
                propertyUnit: tenant.propertyUnit,
                amount: tenant.monthlyRent,
                paymentDate: Date(),
                paymentMethod: .bankTransfer,
                monthYear: Date().toMonthYearString(),
                notes: "Rent recorded as Paid on \(Date().toMediumDateString())"
            )
            tenant.paymentHistory.insert(record, at: 0)
        }
        
        updatedList[index] = tenant
        
        if persistenceService.saveTenants(updatedList) {
            self.tenants = updatedList
            return .success(())
        } else {
            return .failure(RepositoryError.persistenceFailed)
        }
    }
    
    public func recordPayment(tenantId: UUID, record: PaymentRecord, newStatus: PaymentStatus) -> Result<Void, Error> {
        guard let index = tenants.firstIndex(where: { $0.id == tenantId }) else {
            return .failure(RepositoryError.tenantNotFound)
        }
        
        var updatedList = tenants
        var tenant = updatedList[index]
        tenant.currentStatus = newStatus
        tenant.lastUpdatedDate = Date()
        
        var dynamicRecord = record
        if dynamicRecord.tenantName.isEmpty {
            dynamicRecord.tenantName = tenant.name
        }
        if dynamicRecord.propertyUnit.isEmpty {
            dynamicRecord.propertyUnit = tenant.propertyUnit
        }
        
        tenant.paymentHistory.insert(dynamicRecord, at: 0)
        updatedList[index] = tenant
        
        if persistenceService.saveTenants(updatedList) {
            self.tenants = updatedList
            return .success(())
        } else {
            return .failure(RepositoryError.persistenceFailed)
        }
    }
    
    public func clearAllData() {
        _ = persistenceService.clearAllData()
        self.tenants = []
    }
}
