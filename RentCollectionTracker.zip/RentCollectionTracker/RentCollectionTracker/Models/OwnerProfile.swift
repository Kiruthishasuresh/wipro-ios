import Foundation

/// Data Model representing the Landlord / Property Owner Profile with unique identifier
public struct OwnerProfile: Codable, Equatable, Identifiable {
    public var id: String
    public var name: String
    public var companyName: String
    public var email: String
    public var phoneNumber: String
    public var officeAddress: String
    public var securityPin: String
    public var qrPassToken: String
    public var currencySymbol: String
    public var isEmailVerified: Bool
    public var password: String
    public var createdAt: Date
    
    public init(
        id: String = UUID().uuidString,
        name: String = "Property Owner",
        companyName: String = "",
        email: String = "owner@renttracker.com",
        phoneNumber: String = "",
        officeAddress: String = "",
        securityPin: String = "1234",
        qrPassToken: String = "RENT_TRACKER_AUTH:LANDLORD_MASTER_PASS_9941",
        currencySymbol: String = "$",
        isEmailVerified: Bool = false,
        password: String = "password123",
        createdAt: Date = Date()
    ) {
        self.id = id
        self.name = name
        self.companyName = companyName
        self.email = email
        self.phoneNumber = phoneNumber
        self.officeAddress = officeAddress
        self.securityPin = securityPin
        self.qrPassToken = qrPassToken
        self.currencySymbol = currencySymbol
        self.isEmailVerified = isEmailVerified
        self.password = password
        self.createdAt = createdAt
    }
    
    public enum CodingKeys: String, CodingKey {
        case id, name, companyName, email, phoneNumber, officeAddress
        case securityPin, qrPassToken, currencySymbol, isEmailVerified, password, createdAt
    }
    
    public init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decodeIfPresent(String.self, forKey: .id) ?? UUID().uuidString
        name = try container.decodeIfPresent(String.self, forKey: .name) ?? "Property Owner"
        companyName = try container.decodeIfPresent(String.self, forKey: .companyName) ?? ""
        email = try container.decodeIfPresent(String.self, forKey: .email) ?? "owner@renttracker.com"
        phoneNumber = try container.decodeIfPresent(String.self, forKey: .phoneNumber) ?? ""
        officeAddress = try container.decodeIfPresent(String.self, forKey: .officeAddress) ?? ""
        securityPin = try container.decodeIfPresent(String.self, forKey: .securityPin) ?? "1234"
        qrPassToken = try container.decodeIfPresent(String.self, forKey: .qrPassToken) ?? "RENT_TRACKER_AUTH:LANDLORD_MASTER_PASS_9941"
        currencySymbol = try container.decodeIfPresent(String.self, forKey: .currencySymbol) ?? "$"
        isEmailVerified = try container.decodeIfPresent(Bool.self, forKey: .isEmailVerified) ?? false
        password = try container.decodeIfPresent(String.self, forKey: .password) ?? "password123"
        createdAt = try container.decodeIfPresent(Date.self, forKey: .createdAt) ?? Date()
    }
    
    public var initials: String {
        let parts = name.split(separator: " ").filter { !$0.isEmpty }
        if parts.isEmpty { return "PO" }
        return parts.prefix(2).compactMap { $0.first }.map { String($0) }.joined()
    }
}
