import Foundation

public extension Double {
    /// Formats double as an English currency string, e.g. "$1,850.00"
    func toCurrencyString(locale: Locale = Locale(identifier: "en_US")) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = locale
        formatter.maximumFractionDigits = 2
        formatter.minimumFractionDigits = 0
        return formatter.string(from: NSNumber(value: self)) ?? "$\(String(format: "%.0f", self))"
    }
    
    /// Formats double as compact English currency, e.g. "$1.8K" or "$25,000"
    func toCompactCurrencyString() -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = Locale(identifier: "en_US")
        formatter.maximumFractionDigits = 0
        return formatter.string(from: NSNumber(value: self)) ?? "$\(Int(self))"
    }
}
