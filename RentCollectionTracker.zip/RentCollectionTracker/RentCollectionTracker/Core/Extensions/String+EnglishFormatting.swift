import Foundation

public extension String {
    /// Converts any localized or foreign numerals (Devanagari, Arabic-Indic, Bengali, Persian, Chinese, fullwidth, etc.)
    /// into standard English ASCII digits (0-9).
    var toEnglishDigits: String {
        var result = ""
        for char in self {
            if let val = char.wholeNumberValue {
                result.append(String(val))
            } else if char.isASCII {
                result.append(char)
            }
        }
        return result
    }
    
    /// Converts and sanitizes string strictly to English ASCII digits and at most one decimal point.
    var toEnglishNumericAmount: String {
        var hasDecimal = false
        var result = ""
        for char in self {
            if let val = char.wholeNumberValue {
                result.append(String(val))
            } else if (char == "." || char == ",") && !hasDecimal {
                result.append(".")
                hasDecimal = true
            }
        }
        return result
    }
    
    /// Converts and sanitizes string strictly to English digits and standard phone punctuation (+, -, (, ), space).
    var toEnglishPhoneNumber: String {
        var result = ""
        for char in self {
            if let val = char.wholeNumberValue {
                result.append(String(val))
            } else if char == "+" || char == "-" || char == "(" || char == ")" || char == " " {
                result.append(char)
            }
        }
        return result
    }
    
    /// Filters string to strict 4-digit English PIN
    var toEnglishPin: String {
        var result = ""
        for char in self {
            if let val = char.wholeNumberValue {
                result.append(String(val))
                if result.count == 4 { break }
            }
        }
        return result
    }
}
