import Foundation

public extension Date {
    /// Formats date to an English string like "Nov 18, 2026"
    func toMediumDateString() -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter.string(from: self)
    }
    
    /// Formats date to month and year in English, e.g. "November 2026"
    func toMonthYearString() -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.dateFormat = "MMMM yyyy"
        return formatter.string(from: self)
    }
    
    /// Returns current day of month (1...31)
    var currentDayOfMonth: Int {
        Calendar.current.component(.day, from: self)
    }
    
    /// Converts an integer day into English ordinal string like "1st", "2nd", "3rd", "5th"
    static func ordinalDayString(for day: Int) -> String {
        let formatter = NumberFormatter()
        formatter.locale = Locale(identifier: "en_US")
        formatter.numberStyle = .ordinal
        return formatter.string(from: NSNumber(value: day)) ?? "\(day)th"
    }
}
