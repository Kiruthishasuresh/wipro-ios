import Foundation
import LocalAuthentication
import AVFoundation

/// Errors related to authentication
public enum AuthError: LocalizedError, Equatable {
    case biometryNotAvailable
    case biometryNotEnrolled
    case biometryFailed(String)
    case userCancelled
    case invalidCredentials
    case emptyFields
    case invalidPin
    case invalidQRCode
    
    public var errorDescription: String? {
        switch self {
        case .biometryNotAvailable:
            return "Face ID or Touch ID is not available on this device."
        case .biometryNotEnrolled:
            return "No biometric identity is enrolled on this device. Please use QR Pass or manual login."
        case .biometryFailed(let reason):
            return "Biometric authentication failed: \(reason)"
        case .userCancelled:
            return "Authentication was cancelled."
        case .invalidCredentials:
            return "Invalid credentials. Please verify and try again."
        case .emptyFields:
            return "Please enter both your email/username and password."
        case .invalidPin:
            return "Incorrect 4-digit PIN. Please try again."
        case .invalidQRCode:
            return "Invalid Landlord QR Pass token. Please scan a valid registered pass."
        }
    }
}

/// Protocol for authentication service
public protocol BiometricAuthServiceProtocol {
    var biometryTypeDescription: String { get }
    var canUseBiometrics: Bool { get }
    var isCameraAvailable: Bool { get }
    func authenticateWithBiometrics(reason: String) async -> Result<Bool, AuthError>
    func validateManualLogin(username: String, password: String) -> Result<Bool, AuthError>
    func validatePinLogin(pin: String) -> Result<Bool, AuthError>
    func validateQRCode(token: String) -> Result<Bool, AuthError>
    func updateCustomPin(_ newPin: String)
    func updateCredentials(email: String?, password: String?, pin: String?)
}

/// Service implementing Face ID / Touch ID, QR Pass, and dynamic fallback manual validation
public final class BiometricAuthService: BiometricAuthServiceProtocol {
    private let userDefaults = UserDefaults.standard
    private let customPinKey = "user_dynamic_landlord_pin"
    private let customEmailKey = "user_dynamic_landlord_email"
    private let customPasswordKey = "user_dynamic_landlord_password"
    
    public init() {}
    
    public var isCameraAvailable: Bool {
        AVCaptureDevice.default(for: .video) != nil
    }
    
    /// Returns the biometric type available (Face ID, Touch ID, or None)
    public var biometryTypeDescription: String {
        let context = LAContext()
        var error: NSError?
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            switch context.biometryType {
            case .none:
                return "Biometrics"
            case .faceID:
                return "Face ID"
            case .touchID:
                return "Touch ID"
            case .opticID:
                return "Optic ID"
            @unknown default:
                return "Biometrics"
            }
        }
        return "Biometrics"
    }
    
    /// Checks if the device supports biometric auth
    public var canUseBiometrics: Bool {
        let context = LAContext()
        var error: NSError?
        return context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)
    }
    
    /// Authenticates using device biometrics (Face ID)
    public func authenticateWithBiometrics(reason: String = "Authenticate with Face ID to access your Rent Register") async -> Result<Bool, AuthError> {
        let context = LAContext()
        context.localizedCancelTitle = "Use QR Pass / Manual Login"
        
        var authError: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &authError) else {
            if let error = authError {
                if error.code == LAError.biometryNotEnrolled.rawValue {
                    return .failure(.biometryNotEnrolled)
                }
            }
            return .failure(.biometryNotAvailable)
        }
        
        do {
            let success = try await context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason)
            if success {
                return .success(true)
            } else {
                return .failure(.biometryFailed("Authentication could not be completed."))
            }
        } catch let laError as LAError {
            switch laError.code {
            case .userCancel, .appCancel, .systemCancel:
                return .failure(.userCancelled)
            case .biometryNotAvailable:
                return .failure(.biometryNotAvailable)
            case .biometryNotEnrolled:
                return .failure(.biometryNotEnrolled)
            default:
                return .failure(.biometryFailed(laError.localizedDescription))
            }
        } catch {
            return .failure(.biometryFailed(error.localizedDescription))
        }
    }
    
    /// Validates local credentials against registered owner accounts
    public func validateManualLogin(username: String, password: String) -> Result<Bool, AuthError> {
        let trimmedUser = username.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPass = password.trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard !trimmedUser.isEmpty && !trimmedPass.isEmpty else {
            return .failure(.emptyFields)
        }
        
        let result = OwnerProfileService.shared.authenticate(emailOrUsername: trimmedUser, password: trimmedPass)
        switch result {
        case .success:
            return .success(true)
        case .failure:
            return .failure(.invalidCredentials)
        }
    }
    
    /// Validates 4-digit PIN fallback against registered owners
    public func validatePinLogin(pin: String) -> Result<Bool, AuthError> {
        let trimmedPin = pin.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmedPin.count >= 4 else {
            return .failure(.invalidPin)
        }
        
        let result = OwnerProfileService.shared.authenticateWithPin(trimmedPin)
        switch result {
        case .success:
            return .success(true)
        case .failure:
            return .failure(.invalidPin)
        }
    }
    
    /// Validates Landlord QR Pass token against registered owners
    public func validateQRCode(token: String) -> Result<Bool, AuthError> {
        let trimmed = token.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            return .failure(.invalidQRCode)
        }
        
        let result = OwnerProfileService.shared.authenticateWithQR(token: trimmed)
        switch result {
        case .success:
            return .success(true)
        case .failure:
            return .failure(.invalidQRCode)
        }
    }
    
    public func updateCustomPin(_ newPin: String) {
        if newPin.count >= 4 {
            userDefaults.set(newPin, forKey: customPinKey)
        }
    }
    
    public func updateCredentials(email: String?, password: String?, pin: String?) {
        if let email = email, !email.isEmpty {
            userDefaults.set(email, forKey: customEmailKey)
        }
        if let password = password, !password.isEmpty {
            userDefaults.set(password, forKey: customPasswordKey)
        }
        if let pin = pin, pin.count >= 4 {
            userDefaults.set(pin, forKey: customPinKey)
        }
    }
}
