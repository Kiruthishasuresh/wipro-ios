import Foundation

/// Protocol for data persistence
public protocol PersistenceServiceProtocol {
    func loadTenants() -> [Tenant]
    func saveTenants(_ tenants: [Tenant]) -> Bool
    func clearAllData() -> Bool
}

/// Dynamic JSON File and UserDefaults-backed persistence service with per-owner data isolation
public final class PersistenceService: PersistenceServiceProtocol {
    private let fileManager = FileManager.default
    private let userDefaults = UserDefaults.standard
    
    public init() {}
    
    private var activeOwnerId: String {
        userDefaults.string(forKey: "rent_tracker_active_owner_id_v1") ?? "default_owner"
    }
    
    private var fileName: String {
        "tenants_data_\(activeOwnerId).json"
    }
    
    private var storageKey: String {
        "\(AppConstants.tenantsStorageKey)_\(activeOwnerId)"
    }
    
    private var fileURL: URL {
        let paths = fileManager.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = paths[0]
        return documentsDirectory.appendingPathComponent(fileName)
    }
    
    public func loadTenants() -> [Tenant] {
        // 1. Try loading from Document Directory JSON file for active owner
        if fileManager.fileExists(atPath: fileURL.path) {
            do {
                let data = try Data(contentsOf: fileURL)
                let tenants = try JSONDecoder().decode([Tenant].self, from: data)
                return tenants
            } catch {
                print("Failed to decode dynamic tenants from file: \(error.localizedDescription)")
            }
        }
        
        // 2. Try loading from UserDefaults backup for active owner
        if let data = userDefaults.data(forKey: storageKey) {
            do {
                let tenants = try JSONDecoder().decode([Tenant].self, from: data)
                return tenants
            } catch {
                print("Failed to decode dynamic tenants from UserDefaults: \(error.localizedDescription)")
            }
        }
        
        // Starts with completely clean dynamic data for this owner
        return []
    }
    
    public func saveTenants(_ tenants: [Tenant]) -> Bool {
        do {
            let encoder = JSONEncoder()
            encoder.outputFormatting = .prettyPrinted
            let data = try encoder.encode(tenants)
            
            // Atomic write to Documents folder for active owner
            try data.write(to: fileURL, options: [.atomicWrite, .completeFileProtection])
            
            // Mirror to UserDefaults
            userDefaults.set(data, forKey: storageKey)
            return true
        } catch {
            print("Failed to save dynamic tenants: \(error.localizedDescription)")
            return false
        }
    }
    
    public func clearAllData() -> Bool {
        do {
            if fileManager.fileExists(atPath: fileURL.path) {
                try fileManager.removeItem(at: fileURL)
            }
            userDefaults.removeObject(forKey: storageKey)
            return true
        } catch {
            print("Failed to clear data: \(error.localizedDescription)")
            return false
        }
    }
}
