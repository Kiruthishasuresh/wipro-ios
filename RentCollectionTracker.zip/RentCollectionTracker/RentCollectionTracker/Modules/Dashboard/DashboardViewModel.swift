import SwiftUI
import Combine

/// ViewModel driving Dashboard calculations and state
@MainActor
public final class DashboardViewModel: ObservableObject {
    @Published public private(set) var totalTenantsCount: Int = 0
    @Published public private(set) var rentCollectedThisMonth: Double = 0.0
    @Published public private(set) var rentPendingThisMonth: Double = 0.0
    @Published public private(set) var lateTenantsCount: Int = 0
    @Published public private(set) var lateRentAmount: Double = 0.0
    @Published public private(set) var totalExpectedRent: Double = 0.0
    @Published public private(set) var collectionPercentage: Double = 0.0
    @Published public private(set) var recentPayments: [PaymentRecord] = []
    
    // Navigation and Presentation routing states
    @Published public var selectedFilterDestination: PaymentStatus? = nil
    @Published public var isAddTenantPresented: Bool = false
    @Published public var isOwnerProfilePresented: Bool = false
    @Published public var shouldNavigateToTenantList: Bool = false
    
    private let repository: TenantRepositoryProtocol
    private var cancellables = Set<AnyCancellable>()
    
    public init(repository: TenantRepositoryProtocol) {
        self.repository = repository
        setupSubscription()
    }
    
    private func setupSubscription() {
        repository.tenantsPublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] tenants in
                self?.recalculateMetrics(from: tenants)
            }
            .store(in: &cancellables)
    }
    
    /// Recalculates all rent collection figures accurately based on actual payments and tenant statuses
    public func recalculateMetrics(from tenants: [Tenant]) {
        totalTenantsCount = tenants.count
        
        var collectedTotal: Double = 0.0
        var pendingTotal: Double = 0.0
        var lateTotal: Double = 0.0
        var lateCount: Int = 0
        var expectedTotal: Double = 0.0
        var allPayments: [PaymentRecord] = []
        
        let currentMonth = Date().toMonthYearString()
        let calendar = Calendar.current
        let today = Date()
        
        for tenant in tenants {
            expectedTotal += tenant.monthlyRent
            allPayments.append(contentsOf: tenant.paymentHistory)
            
            // Sum actual payments recorded for the current month
            let paymentsThisMonth = tenant.paymentHistory.filter { record in
                record.monthYear == currentMonth ||
                calendar.isDate(record.paymentDate, equalTo: today, toGranularity: .month)
            }
            let actualAmountPaid = paymentsThisMonth.map(\.amount).reduce(0, +)
            
            // Determine tenant collected amount
            let tenantCollected: Double
            if actualAmountPaid > 0 {
                tenantCollected = actualAmountPaid
            } else if tenant.currentStatus == .paid {
                tenantCollected = tenant.monthlyRent
            } else {
                tenantCollected = 0.0
            }
            
            collectedTotal += tenantCollected
            
            // Calculate remaining balance for this tenant
            let tenantBalance = max(0.0, tenant.monthlyRent - tenantCollected)
            
            switch tenant.currentStatus {
            case .paid:
                // No pending balance if marked paid
                break
            case .pending:
                pendingTotal += tenantBalance > 0 ? tenantBalance : tenant.monthlyRent
            case .late:
                lateTotal += tenantBalance > 0 ? tenantBalance : tenant.monthlyRent
                lateCount += 1
            }
        }
        
        rentCollectedThisMonth = collectedTotal
        rentPendingThisMonth = pendingTotal
        lateTenantsCount = lateCount
        lateRentAmount = lateTotal
        totalExpectedRent = expectedTotal
        
        if expectedTotal > 0 {
            collectionPercentage = min(1.0, max(0.0, collectedTotal / expectedTotal))
        } else {
            collectionPercentage = 0.0
        }
        
        // Sort payments descending by date for recent activity feed
        recentPayments = Array(allPayments.sorted { $0.paymentDate > $1.paymentDate }.prefix(8))
    }
    
    public func refresh() {
        repository.refreshData()
    }
    
    public func clearAllTenantData() {
        repository.clearAllData()
    }
}
