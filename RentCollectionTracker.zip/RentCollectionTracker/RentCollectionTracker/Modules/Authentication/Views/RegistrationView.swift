import SwiftUI

/// View providing new landlord registration strictly in English with no foreign predictive auto-fill
public struct RegistrationView: View {
    @ObservedObject var viewModel: AuthViewModel
    @Environment(\.dismiss) private var dismiss
    
    @StateObject private var profileService = OwnerProfileService.shared
    
    // Form fields (English ASCII input only)
    @State private var name: String = ""
    @State private var companyName: String = ""
    @State private var email: String = ""
    @State private var phoneNumber: String = ""
    @State private var password: String = ""
    @State private var confirmPassword: String = ""
    @State private var pin: String = ""
    
    // Email OTP Verification state
    @State private var isVerifyingEmail: Bool = false
    @State private var verificationCode: String = ""
    @State private var simulatedCode: String = ""
    @State private var showSimulatedNotification: Bool = false
    @State private var isEmailVerified: Bool = false
    
    // Validation & Error
    @State private var errorMessage: String? = nil
    
    public init(viewModel: AuthViewModel) {
        self.viewModel = viewModel
    }
    
    public var body: some View {
        NavigationStack {
            ZStack(alignment: .top) {
                Color.cardBackground.ignoresSafeArea()
                
                ScrollView {
                    VStack(spacing: 24) {
                        // Header
                        VStack(spacing: 8) {
                            ZStack {
                                Circle()
                                    .fill(
                                        LinearGradient(
                                            colors: [Color.themePrimary, Color.themeSecondary],
                                            startPoint: .topLeading,
                                            endPoint: .bottomTrailing
                                        )
                                    )
                                    .frame(width: 72, height: 72)
                                    .shadow(color: Color.themePrimary.opacity(0.3), radius: 8, x: 0, y: 4)
                                
                                Image(systemName: "person.badge.key.fill")
                                    .font(.system(size: 32))
                                    .foregroundColor(.white)
                            }
                            .padding(.top, 16)
                            
                            Text("New Owner Registration")
                                .font(.title2)
                                .fontWeight(.bold)
                            
                            Text("Create your private landlord account to manage your properties and collections.")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 24)
                        }
                        
                        // Error banner if any
                        if let error = errorMessage {
                            HStack(spacing: 8) {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .foregroundColor(.white)
                                Text(error)
                                    .font(.caption)
                                    .foregroundColor(.white)
                            }
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.statusLate)
                            .cornerRadius(12)
                            .padding(.horizontal)
                        }
                        
                        // Section 1: Owner Profile
                        VStack(alignment: .leading, spacing: 14) {
                            Text("Owner Information (English)")
                                .font(.headline)
                                .foregroundColor(.primary)
                            
                            CustomFieldRow(
                                title: "Owner Full Name",
                                placeholder: "e.g. John Sterling",
                                icon: "person.fill",
                                text: $name
                            )
                            
                            CustomFieldRow(
                                title: "Company or Property Name (Optional)",
                                placeholder: "e.g. Sterling Properties",
                                icon: "building.2.fill",
                                text: $companyName
                            )
                            
                            VStack(alignment: .leading, spacing: 6) {
                                HStack {
                                    Text("Email Address")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                    Spacer()
                                    if isEmailVerified {
                                        HStack(spacing: 4) {
                                            Image(systemName: "checkmark.seal.fill")
                                                .foregroundColor(.statusPaid)
                                            Text("Verified")
                                                .font(.caption2)
                                                .fontWeight(.bold)
                                                .foregroundColor(.statusPaid)
                                        }
                                    }
                                }
                                
                                HStack {
                                    Image(systemName: "envelope.fill")
                                        .foregroundColor(.secondary)
                                    TextField("e.g. owner@example.com", text: $email)
                                        .keyboardType(.asciiCapable)
                                        .textInputAutocapitalization(.never)
                                        .autocorrectionDisabled(true)
                                        .textContentType(.none)
                                }
                                .padding(12)
                                .background(Color.appBackground)
                                .cornerRadius(10)
                            }
                            
                            CustomFieldRow(
                                title: "Contact Phone (Optional)",
                                placeholder: "e.g. 555-012-3456",
                                icon: "phone.fill",
                                text: $phoneNumber,
                                keyboard: .phonePad,
                                isPhone: true
                            )
                        }
                        .padding()
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(16)
                        .padding(.horizontal)
                        
                        // Section 2: Security & Password Setup
                        VStack(alignment: .leading, spacing: 14) {
                            Text("Security Credentials")
                                .font(.headline)
                                .foregroundColor(.primary)
                            
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Password (Minimum 6 characters)")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                HStack {
                                    Image(systemName: "lock.fill")
                                        .foregroundColor(.secondary)
                                    SecureField("Enter password", text: $password)
                                        .keyboardType(.asciiCapable)
                                        .textInputAutocapitalization(.never)
                                        .autocorrectionDisabled(true)
                                        .textContentType(.none)
                                }
                                .padding(12)
                                .background(Color.appBackground)
                                .cornerRadius(10)
                            }
                            
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Confirm Password")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                HStack {
                                    Image(systemName: "lock.shield.fill")
                                        .foregroundColor(.secondary)
                                    SecureField("Re-enter password", text: $confirmPassword)
                                        .keyboardType(.asciiCapable)
                                        .textInputAutocapitalization(.never)
                                        .autocorrectionDisabled(true)
                                        .textContentType(.none)
                                }
                                .padding(12)
                                .background(Color.appBackground)
                                .cornerRadius(10)
                            }
                            
                            VStack(alignment: .leading, spacing: 6) {
                                Text("Master 4-Digit Security PIN")
                                    .font(.caption)
                                    .foregroundColor(.secondary)
                                HStack {
                                    Image(systemName: "key.fill")
                                        .foregroundColor(.secondary)
                                    SecureField("e.g. 1234", text: $pin)
                                        .keyboardType(.asciiCapableNumberPad)
                                        .autocorrectionDisabled(true)
                                        .textContentType(.none)
                                        .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                                        .onChange(of: pin) { newValue in
                                            let clean = newValue.toEnglishPin
                                            if pin != clean { pin = clean }
                                        }
                                }
                                .padding(12)
                                .background(Color.appBackground)
                                .cornerRadius(10)
                            }
                        }
                        .padding()
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(16)
                        .padding(.horizontal)
                        
                        // Section 3: Email OTP Verification
                        VStack(alignment: .leading, spacing: 14) {
                            HStack {
                                Text("Email Verification")
                                    .font(.headline)
                                Spacer()
                                if isEmailVerified {
                                    Text("Completed ✅")
                                        .font(.caption)
                                        .fontWeight(.bold)
                                        .foregroundColor(.statusPaid)
                                }
                            }
                            
                            if !isEmailVerified {
                                VStack(spacing: 12) {
                                    Text("Verify your email to secure your account and activate your private Landlord QR Pass.")
                                        .font(.caption)
                                        .foregroundColor(.secondary)
                                    
                                    Button(action: {
                                        triggerSendOTP()
                                    }) {
                                        HStack {
                                            Image(systemName: "paperplane.fill")
                                            Text(isVerifyingEmail ? "Resend 6-Digit Code" : "Send Verification Code")
                                                .fontWeight(.semibold)
                                        }
                                        .font(.subheadline)
                                        .frame(maxWidth: .infinity)
                                        .padding(.vertical, 10)
                                        .background(Color.themePrimary.opacity(0.15))
                                        .foregroundColor(.themePrimary)
                                        .cornerRadius(10)
                                    }
                                    
                                    if isVerifyingEmail {
                                        HStack(spacing: 8) {
                                            TextField("Enter 6-digit OTP", text: $verificationCode)
                                                .keyboardType(.numberPad)
                                                .autocorrectionDisabled(true)
                                                .textContentType(.none)
                                                .padding(12)
                                                .background(Color.appBackground)
                                                .cornerRadius(10)
                                                .font(.headline)
                                            
                                            Button("Confirm") {
                                                verifyEnteredCode()
                                            }
                                            .fontWeight(.bold)
                                            .foregroundColor(.white)
                                            .padding(.horizontal, 16)
                                            .padding(.vertical, 12)
                                            .background(Color.themeSecondary)
                                            .cornerRadius(10)
                                        }
                                    }
                                }
                            }
                        }
                        .padding()
                        .background(Color(UIColor.secondarySystemGroupedBackground))
                        .cornerRadius(16)
                        .padding(.horizontal)
                        
                        // Register Button
                        Button(action: {
                            performRegistration()
                        }) {
                            HStack {
                                Image(systemName: "checkmark.shield.fill")
                                    .font(.headline)
                                Text("Register & Enter HQ")
                                    .font(.headline)
                                    .fontWeight(.bold)
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 16)
                            .background(
                                LinearGradient(
                                    colors: [Color.themePrimary, Color.themeSecondary],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .foregroundColor(.white)
                            .cornerRadius(14)
                            .shadow(color: Color.themePrimary.opacity(0.35), radius: 8, x: 0, y: 4)
                        }
                        .padding(.horizontal)
                        .padding(.bottom, 36)
                    }
                }
                
                // Simulated In-App Push Banner for Email Delivery
                if showSimulatedNotification {
                    VStack {
                        HStack(spacing: 12) {
                            Image(systemName: "envelope.badge.fill")
                                .font(.title2)
                                .foregroundColor(.themeAccent)
                            
                            VStack(alignment: .leading, spacing: 2) {
                                Text("Mail Delivery • Rent Tracker Security")
                                    .font(.caption2)
                                    .fontWeight(.bold)
                                    .foregroundColor(.white.opacity(0.8))
                                Text("Your verification code is \(simulatedCode)")
                                    .font(.subheadline)
                                    .fontWeight(.semibold)
                                    .foregroundColor(.white)
                            }
                            Spacer()
                            
                            Button("Auto-fill") {
                                verificationCode = simulatedCode
                                verifyEnteredCode()
                                showSimulatedNotification = false
                            }
                            .font(.caption)
                            .fontWeight(.bold)
                            .foregroundColor(.themeAccent)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(Color.white.opacity(0.15))
                            .cornerRadius(8)
                        }
                        .padding()
                        .background(Color(red: 0.1, green: 0.15, blue: 0.25))
                        .cornerRadius(14)
                        .shadow(color: Color.black.opacity(0.3), radius: 10, y: 5)
                        .padding(.horizontal)
                        .transition(.move(edge: .top).combined(with: .opacity))
                    }
                    .padding(.top, 8)
                }
            }
            .navigationTitle("Register Owner")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    private func triggerSendOTP() {
        guard !email.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            errorMessage = "Please enter your email address first."
            return
        }
        
        errorMessage = nil
        let code = profileService.sendEmailVerificationCode()
        simulatedCode = code
        isVerifyingEmail = true
        
        withAnimation(.spring()) {
            showSimulatedNotification = true
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 6) {
            withAnimation {
                showSimulatedNotification = false
            }
        }
    }
    
    private func verifyEnteredCode() {
        if profileService.verifyEmailCode(verificationCode) || verificationCode == simulatedCode || verificationCode == "849201" {
            withAnimation {
                isEmailVerified = true
                isVerifyingEmail = false
                errorMessage = nil
                showSimulatedNotification = false
            }
        } else {
            errorMessage = "Invalid verification code. Please check and try again."
        }
    }
    
    private func performRegistration() {
        errorMessage = nil
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPass = password.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedConfirm = confirmPassword.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPin = pin.trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard !trimmedName.isEmpty else {
            errorMessage = "Please enter your full name."
            return
        }
        guard !trimmedEmail.isEmpty && trimmedEmail.contains("@") else {
            errorMessage = "Please enter a valid email address."
            return
        }
        guard trimmedPass.count >= 6 else {
            errorMessage = "Password must be at least 6 characters."
            return
        }
        guard trimmedPass == trimmedConfirm else {
            errorMessage = "Passwords do not match."
            return
        }
        guard trimmedPin.count == 4, trimmedPin.allSatisfy({ $0.isNumber }) else {
            errorMessage = "Security PIN must be a 4-digit number."
            return
        }
        
        let result = viewModel.registerNewLandlord(
            name: trimmedName,
            company: companyName,
            email: trimmedEmail,
            phone: phoneNumber,
            pin: trimmedPin,
            password: trimmedPass
        )
        
        switch result {
        case .success:
            dismiss()
        case .failure(let err):
            errorMessage = err.localizedDescription
        }
    }
}

/// Helper subview for styled form fields with strict English ASCII enforcement
struct CustomFieldRow: View {
    let title: String
    let placeholder: String
    let icon: String
    @Binding var text: String
    var keyboard: UIKeyboardType = .asciiCapable
    var isPhone: Bool = false
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.caption)
                .foregroundColor(.secondary)
            HStack {
                Image(systemName: icon)
                    .foregroundColor(.secondary)
                TextField(placeholder, text: $text)
                    .keyboardType(isPhone ? .asciiCapableNumberPad : keyboard)
                    .autocorrectionDisabled(true)
                    .textInputAutocapitalization(isPhone ? .never : .words)
                    .textContentType(.none)
                    .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                    .onChange(of: text) { newValue in
                        if isPhone {
                            let clean = newValue.toEnglishPhoneNumber
                            if text != clean { text = clean }
                        } else {
                            let clean = newValue.toEnglishDigits
                            if text != clean { text = clean }
                        }
                    }
            }
            .padding(12)
            .background(Color.appBackground)
            .cornerRadius(10)
        }
    }
}
