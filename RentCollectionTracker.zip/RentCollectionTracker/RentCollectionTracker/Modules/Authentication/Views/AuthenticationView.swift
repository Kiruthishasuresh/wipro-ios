import SwiftUI

/// Main Launch Screen Authentication & Login Page
public struct AuthenticationView: View {
    @ObservedObject var viewModel: AuthViewModel
    @State private var pulseAnimation = false
    
    public init(viewModel: AuthViewModel) {
        self.viewModel = viewModel
    }
    
    public var body: some View {
        ZStack {
            // Elegant background gradient
            LinearGradient(
                colors: [
                    Color(red: 0.06, green: 0.12, blue: 0.22),
                    Color(red: 0.08, green: 0.22, blue: 0.38)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            ScrollView {
                VStack(spacing: 24) {
                    Spacer(minLength: 20)
                    
                    // App Logo & Brand Header
                    VStack(spacing: 12) {
                        ZStack {
                            Circle()
                                .stroke(Color.themeAccent.opacity(0.3), lineWidth: 2)
                                .frame(width: 96, height: 96)
                                .scaleEffect(pulseAnimation ? 1.12 : 1.0)
                                .opacity(pulseAnimation ? 0.3 : 0.8)
                                .animation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true), value: pulseAnimation)
                            
                            Circle()
                                .fill(
                                    LinearGradient(
                                        colors: [Color.themePrimary, Color.themeSecondary],
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    )
                                )
                                .frame(width: 76, height: 76)
                                .shadow(color: Color.themeAccent.opacity(0.4), radius: 12, x: 0, y: 6)
                            
                            Image(systemName: "building.2.crop.circle.fill")
                                .font(.system(size: 38))
                                .foregroundColor(.white)
                        }
                        
                        Text(AppConstants.appName)
                            .font(.title2)
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                        
                        Text("Landlord & Property Owner Sign In")
                            .font(.subheadline)
                            .foregroundColor(.white.opacity(0.8))
                    }
                    .padding(.top, 16)
                    
                    // Main Login Card
                    VStack(spacing: 18) {
                        // Segmented Mode: PIN vs Email/Password
                        Picker("Login Mode", selection: $viewModel.isPinMode) {
                            Text("Security PIN").tag(true)
                            Text("Email / Password").tag(false)
                        }
                        .pickerStyle(.segmented)
                        
                        if viewModel.isPinMode {
                            // PIN Mode Section
                            VStack(alignment: .leading, spacing: 8) {
                                HStack {
                                    Text("Enter 4-Digit Master PIN")
                                        .font(.caption)
                                        .fontWeight(.semibold)
                                        .foregroundColor(.white.opacity(0.8))
                                    Spacer()
                                    Button("Hint: 1234") {
                                        viewModel.pinInput = "1234"
                                    }
                                    .font(.caption2)
                                    .foregroundColor(.themeAccent)
                                }
                                
                                HStack {
                                    Image(systemName: "key.fill")
                                        .foregroundColor(.themeAccent)
                                    SecureField("4-digit PIN", text: $viewModel.pinInput)
                                        .keyboardType(.asciiCapableNumberPad)
                                        .textContentType(.none)
                                        .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                                        .foregroundColor(.white)
                                        .font(.title3)
                                }
                                .padding(14)
                                .background(Color.white.opacity(0.12))
                                .cornerRadius(12)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(Color.white.opacity(0.2), lineWidth: 1)
                                )
                            }
                        } else {
                            // Email & Password Section
                            VStack(spacing: 12) {
                                VStack(alignment: .leading, spacing: 6) {
                                    Text("Email Address")
                                        .font(.caption)
                                        .fontWeight(.semibold)
                                        .foregroundColor(.white.opacity(0.8))
                                    
                                    HStack {
                                        Image(systemName: "envelope.fill")
                                            .foregroundColor(.themeAccent)
                                        TextField("e.g. owner@renttracker.com", text: $viewModel.emailInput)
                                            .keyboardType(.asciiCapable)
                                            .textInputAutocapitalization(.never)
                                            .autocorrectionDisabled(true)
                                            .textContentType(.none)
                                            .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                                            .foregroundColor(.white)
                                    }
                                    .padding(14)
                                    .background(Color.white.opacity(0.12))
                                    .cornerRadius(12)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(Color.white.opacity(0.2), lineWidth: 1)
                                    )
                                }
                                
                                VStack(alignment: .leading, spacing: 6) {
                                    Text("Password")
                                        .font(.caption)
                                        .fontWeight(.semibold)
                                        .foregroundColor(.white.opacity(0.8))
                                    
                                    HStack {
                                        Image(systemName: "lock.fill")
                                            .foregroundColor(.themeAccent)
                                        SecureField("Enter password", text: $viewModel.passwordInput)
                                            .keyboardType(.asciiCapable)
                                            .textInputAutocapitalization(.never)
                                            .autocorrectionDisabled(true)
                                            .textContentType(.none)
                                            .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                                            .foregroundColor(.white)
                                    }
                                    .padding(14)
                                    .background(Color.white.opacity(0.12))
                                    .cornerRadius(12)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 12)
                                            .stroke(Color.white.opacity(0.2), lineWidth: 1)
                                    )
                                }
                            }
                        }
                        
                        // Error banner if any
                        if let error = viewModel.errorMessage {
                            HStack(spacing: 8) {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .foregroundColor(.white)
                                Text(error)
                                    .font(.caption)
                                    .foregroundColor(.white)
                            }
                            .padding(10)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.statusLate.opacity(0.9))
                            .cornerRadius(10)
                            .transition(.opacity)
                        }
                        
                        // Main Sign In Action Button
                        Button(action: {
                            viewModel.performManualLogin()
                        }) {
                            HStack(spacing: 8) {
                                Text("Unlock & Sign In")
                                    .fontWeight(.bold)
                                Image(systemName: "arrow.right.circle.fill")
                            }
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(
                                LinearGradient(
                                    colors: [Color.themePrimary, Color.themeSecondary],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .foregroundColor(.white)
                            .cornerRadius(12)
                            .shadow(color: Color.themeAccent.opacity(0.35), radius: 8, x: 0, y: 4)
                        }
                    }
                    .padding(20)
                    .background(Color.white.opacity(0.08))
                    .cornerRadius(20)
                    .overlay(
                        RoundedRectangle(cornerRadius: 20)
                            .stroke(Color.white.opacity(0.15), lineWidth: 1)
                    )
                    .padding(.horizontal, 24)
                    
                    // Alternative Unlock Options (Biometric & QR Scanner)
                    VStack(spacing: 12) {
                        if viewModel.canUseBiometrics {
                            Button(action: {
                                viewModel.triggerBiometricAuthentication()
                            }) {
                                HStack(spacing: 8) {
                                    Image(systemName: "faceid")
                                    Text("Unlock with \(viewModel.biometryTypeDescription)")
                                        .fontWeight(.semibold)
                                }
                                .font(.subheadline)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 12)
                                .background(Color.white.opacity(0.12))
                                .foregroundColor(.white)
                                .cornerRadius(12)
                            }
                        }
                        
                        Button(action: {
                            viewModel.isQRScannerPresented = true
                        }) {
                            HStack(spacing: 8) {
                                Image(systemName: "qrcode.viewfinder")
                                Text("Scan Landlord QR Pass")
                                    .fontWeight(.semibold)
                            }
                            .font(.subheadline)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 12)
                            .background(Color.white.opacity(0.12))
                            .foregroundColor(.white)
                            .cornerRadius(12)
                        }
                    }
                    .padding(.horizontal, 24)
                    
                    // Register Account Row
                    Button(action: {
                        viewModel.isRegistrationPresented = true
                    }) {
                        HStack(spacing: 6) {
                            Image(systemName: "person.badge.plus")
                            Text("New Landlord? Register Account")
                                .fontWeight(.semibold)
                        }
                        .font(.footnote)
                        .foregroundColor(.themeAccent)
                        .padding(.vertical, 8)
                    }
                    
                    Spacer(minLength: 20)
                }
            }
        }
        .sheet(isPresented: $viewModel.isQRScannerPresented) {
            QRCodeScannerView { scannedCode in
                viewModel.authenticateWithQRCode(token: scannedCode)
            }
        }
        .sheet(isPresented: $viewModel.isRegistrationPresented) {
            RegistrationView(viewModel: viewModel)
        }
        .onAppear {
            pulseAnimation = true
            if viewModel.canUseBiometrics {
                viewModel.triggerBiometricAuthentication()
            }
        }
    }
}
