import SwiftUI

/// Manual Login View sheet shown when biometric authentication fails or is cancelled
public struct ManualLoginSheet: View {
    @ObservedObject var viewModel: AuthViewModel
    @Environment(\.dismiss) private var dismiss
    
    public init(viewModel: AuthViewModel) {
        self.viewModel = viewModel
    }
    
    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 24) {
                    // Header Icon & Title
                    VStack(spacing: 12) {
                        Image(systemName: "lock.shield.fill")
                            .font(.system(size: 54))
                            .foregroundStyle(
                                LinearGradient(
                                    colors: [Color.themePrimary, Color.themeSecondary],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .padding(.top, 16)
                        
                        Text("Landlord Authentication")
                            .font(.title2)
                            .fontWeight(.bold)
                        
                        Text("Enter your 4-digit security PIN or credentials to unlock your rent registers.")
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 24)
                    }
                    
                    // Mode Picker (PIN vs Password)
                    Picker("Login Mode", selection: $viewModel.isPinMode) {
                        Text("Security PIN").tag(true)
                        Text("Email / Password").tag(false)
                    }
                    .pickerStyle(.segmented)
                    .padding(.horizontal)
                    
                    // Form Content
                    VStack(spacing: 18) {
                        if viewModel.isPinMode {
                            pinEntrySection
                        } else {
                            emailPasswordSection
                        }
                        
                        // Error message banner
                        if let error = viewModel.errorMessage {
                            HStack(spacing: 8) {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .foregroundColor(.white)
                                Text(error)
                                    .font(.subheadline)
                                    .foregroundColor(.white)
                                    .fixedSize(horizontal: false, vertical: true)
                            }
                            .padding()
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.statusLate.opacity(0.9))
                            .cornerRadius(12)
                            .transition(.opacity.combined(with: .slide))
                        }
                        
                        // Login Action Button
                        Button(action: {
                            viewModel.performManualLogin()
                        }) {
                            HStack {
                                Text("Unlock Register")
                                    .fontWeight(.semibold)
                                Image(systemName: "arrow.right.circle.fill")
                            }
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(
                                LinearGradient(
                                    colors: [Color.themePrimary, Color.themeSecondary],
                                    startPoint: .leading,
                                    endPoint: .trailing
                                )
                            )
                            .foregroundColor(.white)
                            .cornerRadius(14)
                            .shadow(color: Color.themePrimary.opacity(0.3), radius: 6, x: 0, y: 3)
                        }
                        
                        // Register New Landlord Button
                        Button(action: {
                            dismiss()
                            viewModel.isRegistrationPresented = true
                        }) {
                            HStack(spacing: 6) {
                                Image(systemName: "person.badge.plus")
                                Text("New Landlord? Register Account")
                                    .fontWeight(.semibold)
                            }
                            .font(.subheadline)
                            .foregroundColor(.themePrimary)
                            .padding(.top, 8)
                        }
                    }
                    .padding(.horizontal)
                }
                .padding(.bottom, 32)
            }
            .background(Color.cardBackground.ignoresSafeArea())
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Close") {
                        dismiss()
                    }
                }
            }
        }
    }
    
    // PIN entry subview
    private var pinEntrySection: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Security PIN")
                .font(.caption)
                .fontWeight(.medium)
                .foregroundColor(.secondary)
            
            HStack {
                Image(systemName: "key.fill")
                    .foregroundColor(.secondary)
                SecureField("Enter 4-digit PIN", text: $viewModel.pinInput)
                    .keyboardType(.numberPad)
                    .textContentType(.oneTimeCode)
            }
            .padding()
            .background(Color.appBackground)
            .cornerRadius(12)
        }
    }
    
    // Email/Password subview
    private var emailPasswordSection: some View {
        VStack(spacing: 14) {
            VStack(alignment: .leading, spacing: 6) {
                Text("Landlord Email or Username")
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.secondary)
                
                HStack {
                    Image(systemName: "envelope.fill")
                        .foregroundColor(.secondary)
                    TextField("Enter email or username", text: $viewModel.emailInput)
                        .autocapitalization(.none)
                        .keyboardType(.asciiCapable)
                        .disableAutocorrection(true)
                        .textContentType(.none)
                }
                .padding()
                .background(Color.appBackground)
                .cornerRadius(12)
            }
            
            VStack(alignment: .leading, spacing: 6) {
                Text("Password")
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.secondary)
                
                HStack {
                    Image(systemName: "lock.fill")
                        .foregroundColor(.secondary)
                    SecureField("Enter password", text: $viewModel.passwordInput)
                        .keyboardType(.asciiCapable)
                        .textContentType(.none)
                }
                .padding()
                .background(Color.appBackground)
                .cornerRadius(12)
            }
        }
    }
}
