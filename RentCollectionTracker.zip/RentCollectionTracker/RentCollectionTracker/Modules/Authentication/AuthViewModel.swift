import SwiftUI
import Combine

/// ViewModel managing Face ID Biometric Authentication, QR Scanner, and Fallback Manual Login
@MainActor
public final class AuthViewModel: ObservableObject {
    @Published public var isAuthenticated: Bool = false
    @Published public var isAuthenticating: Bool = false
    @Published public var errorMessage: String? = nil
    @Published public var showErrorAlert: Bool = false
    @Published public var isManualLoginPresented: Bool = false
    @Published public var isQRScannerPresented: Bool = false
    @Published public var isRegistrationPresented: Bool = false
    
    // Manual login form fields
    @Published public var emailInput: String = ""
    @Published public var passwordInput: String = ""
    @Published public var pinInput: String = "" {
        didSet {
            let sanitized = pinInput.toEnglishPin
            if pinInput != sanitized {
                pinInput = sanitized
            }
        }
    }
    @Published public var isPinMode: Bool = true
    
    private let authService: BiometricAuthServiceProtocol
    
    public init(authService: BiometricAuthServiceProtocol = BiometricAuthService()) {
        self.authService = authService
    }
    
    public var biometryTypeDescription: String {
        authService.biometryTypeDescription
    }
    
    public var canUseBiometrics: Bool {
        authService.canUseBiometrics
    }
    
    public var isCameraAvailable: Bool {
        authService.isCameraAvailable
    }
    
    /// Trigger Face ID / Touch ID biometric challenge on launch or user request
    public func triggerBiometricAuthentication() {
        guard !isAuthenticating else { return }
        
        // If device has Face ID / biometrics available, use Face ID
        if canUseBiometrics {
            isAuthenticating = true
            errorMessage = nil
            
            Task {
                let result = await authService.authenticateWithBiometrics(reason: "Authenticate with Face ID to access your Rent Register")
                self.isAuthenticating = false
                
                switch result {
                case .success:
                    withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                        self.isAuthenticated = true
                        self.errorMessage = nil
                        self.showErrorAlert = false
                        self.isManualLoginPresented = false
                        self.isQRScannerPresented = false
                    }
                case .failure(let error):
                    withAnimation {
                        self.errorMessage = error.localizedDescription
                        // Never auto-pop QR Scanner modal; the user is on the main login screen
                        if error != .biometryNotAvailable && error != .biometryNotEnrolled {
                            self.showErrorAlert = true
                        }
                    }
                }
            }
        }
        // If biometrics is not available, do not pop up any modal; the user is directly on the login page!
    }
    
    /// Authenticates with Landlord QR Pass token
    public func authenticateWithQRCode(token: String) {
        let result = authService.validateQRCode(token: token)
        switch result {
        case .success:
            withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                self.isAuthenticated = true
                self.errorMessage = nil
                self.showErrorAlert = false
                self.isQRScannerPresented = false
                self.isManualLoginPresented = false
            }
        case .failure(let error):
            withAnimation {
                self.errorMessage = error.localizedDescription
                self.showErrorAlert = true
            }
        }
    }
    
    /// Manual credential validation
    public func performManualLogin() {
        errorMessage = nil
        let result: Result<Bool, AuthError>
        
        if isPinMode {
            let cleanPin = pinInput.toEnglishPin
            result = authService.validatePinLogin(pin: cleanPin)
        } else {
            let cleanEmail = emailInput.trimmingCharacters(in: .whitespacesAndNewlines)
            let cleanPass = passwordInput.trimmingCharacters(in: .whitespacesAndNewlines)
            result = authService.validateManualLogin(username: cleanEmail, password: cleanPass)
        }
        
        switch result {
        case .success:
            withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                self.isAuthenticated = true
                self.isManualLoginPresented = false
                self.errorMessage = nil
                self.clearInputs()
            }
        case .failure(let error):
            withAnimation {
                self.errorMessage = error.localizedDescription
            }
        }
    }
    
    /// Completes registration of a new landlord account and authenticates
    @discardableResult
    public func registerNewLandlord(name: String, company: String, email: String, phone: String, pin: String, password: String) -> Result<Void, UserAccountError> {
        let result = OwnerProfileService.shared.registerNewLandlord(
            name: name,
            companyName: company,
            email: email,
            phone: phone,
            pin: pin,
            password: password
        )
        
        switch result {
        case .success(let newProfile):
            authService.updateCredentials(email: newProfile.email, password: newProfile.password, pin: newProfile.securityPin)
            
            withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                self.isAuthenticated = true
                self.isRegistrationPresented = false
                self.isManualLoginPresented = false
                self.isQRScannerPresented = false
                self.errorMessage = nil
                self.clearInputs()
            }
            return .success(())
        case .failure(let err):
            withAnimation {
                self.errorMessage = err.localizedDescription
            }
            return .failure(err)
        }
    }
    
    /// Reset authentication state (Log Out / Lock App)
    public func lockApp() {
        withAnimation {
            self.isAuthenticated = false
            self.clearInputs()
            self.errorMessage = nil
            self.isQRScannerPresented = false
            self.isManualLoginPresented = false
            self.isRegistrationPresented = false
        }
    }
    
    private func clearInputs() {
        self.emailInput = ""
        self.passwordInput = ""
        self.pinInput = ""
    }
}
