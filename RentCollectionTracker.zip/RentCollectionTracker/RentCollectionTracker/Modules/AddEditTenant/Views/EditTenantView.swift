import SwiftUI

/// Screen to edit and revise tenant details dynamically
public struct EditTenantView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel: AddEditTenantViewModel
    
    public init(tenant: Tenant, repository: TenantRepositoryProtocol) {
        _viewModel = StateObject(wrappedValue: AddEditTenantViewModel(repository: repository, tenantToEdit: tenant))
    }
    
    public var body: some View {
        NavigationStack {
            Form {
                // Section 1: Contact Info
                Section {
                    CustomInputField(
                        label: "Full Name *",
                        placeholder: "Enter full name",
                        text: $viewModel.name,
                        iconName: "person.fill",
                        errorMessage: viewModel.nameError
                    )
                    
                    CustomInputField(
                        label: "Phone Number *",
                        placeholder: "e.g. +1 555-0199",
                        text: $viewModel.phoneNumber,
                        iconName: "phone.fill",
                        keyboardType: .phonePad,
                        errorMessage: viewModel.phoneError,
                        isPhoneNumber: true
                    )
                    
                    CustomInputField(
                        label: "Email Address (Optional)",
                        placeholder: "e.g. tenant@domain.com",
                        text: $viewModel.email,
                        iconName: "envelope.fill",
                        keyboardType: .emailAddress
                    )
                } header: {
                    Label("Contact Details", systemImage: "person.crop.circle")
                }
                
                // Section 2: Property & Rent Terms
                Section {
                    CustomInputField(
                        label: "Property or Unit *",
                        placeholder: "e.g. Unit 302, Green Valley Apartments",
                        text: $viewModel.propertyUnit,
                        iconName: "building.2.fill",
                        errorMessage: viewModel.propertyError
                    )
                    
                    CustomInputField(
                        label: "Monthly Rent ($) * (Rent Revision)",
                        placeholder: "Enter new rent (e.g. 1500)",
                        text: $viewModel.monthlyRentText,
                        iconName: "dollarsign.circle.fill",
                        keyboardType: .decimalPad,
                        errorMessage: viewModel.rentError,
                        isNumericAmount: true
                    )
                    
                    // Rent Due Day Stepper
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Rent Due Day")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        
                        Stepper(value: $viewModel.rentDueDay, in: 1...31) {
                            HStack {
                                Image(systemName: "calendar")
                                    .foregroundColor(.themePrimary)
                                Text("\(Date.ordinalDayString(for: viewModel.rentDueDay)) of each month")
                                    .fontWeight(.medium)
                            }
                        }
                    }
                    .padding(.vertical, 4)
                    
                    CustomInputField(
                        label: "Advance / Security Deposit ($)",
                        placeholder: "Enter deposit amount (e.g. 1500)",
                        text: $viewModel.advanceAmountText,
                        iconName: "shield.fill",
                        keyboardType: .decimalPad,
                        isNumericAmount: true
                    )
                    
                    // Dynamic Lease Start Date
                    DatePicker(
                        selection: $viewModel.leaseStartDate,
                        displayedComponents: .date
                    ) {
                        HStack {
                            Image(systemName: "calendar.badge.clock")
                                .foregroundColor(.themePrimary)
                            Text("Lease Start Date")
                                .font(.subheadline)
                                .fontWeight(.medium)
                        }
                    }
                    .padding(.vertical, 2)
                } header: {
                    Label("Lease Terms & Rent Revision", systemImage: "dollarsign.arrow.circlepath")
                }
                
                // Section 3: Status & Notes
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Current Payment Status")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        
                        Picker("Status", selection: $viewModel.currentStatus) {
                            ForEach(PaymentStatus.allCases) { status in
                                HStack {
                                    Image(systemName: status.iconName)
                                    Text(status.title)
                                }
                                .tag(status)
                            }
                        }
                        .pickerStyle(.segmented)
                    }
                    .padding(.vertical, 4)
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Notes & Remarks")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        
                        TextEditor(text: $viewModel.notes)
                            .frame(minHeight: 90)
                            .padding(4)
                            .background(Color.cardBackground)
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.secondary.opacity(0.18), lineWidth: 1)
                            )
                    }
                } header: {
                    Label("Status & Notes", systemImage: "note.text")
                }
                
                if let generalError = viewModel.generalError {
                    Section {
                        Text(generalError)
                            .foregroundColor(.statusLate)
                            .font(.subheadline)
                    }
                }
            }
            .navigationTitle("Edit Tenant")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Update") {
                        if viewModel.save() {
                            dismiss()
                        }
                    }
                    .fontWeight(.bold)
                    .foregroundColor(.themePrimary)
                }
            }
        }
    }
}
