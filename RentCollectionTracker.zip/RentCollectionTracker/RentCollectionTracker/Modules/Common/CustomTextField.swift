import SwiftUI

/// Styled input field with iconography and validation hint
public struct CustomInputField: View {
    public let label: String
    public let placeholder: String
    @Binding public var text: String
    public var iconName: String
    public var keyboardType: UIKeyboardType = .default
    public var errorMessage: String? = nil
    public var isNumericAmount: Bool = false
    public var isPhoneNumber: Bool = false
    public var isPin: Bool = false
    
    public init(
        label: String,
        placeholder: String,
        text: Binding<String>,
        iconName: String,
        keyboardType: UIKeyboardType = .default,
        errorMessage: String? = nil,
        isNumericAmount: Bool = false,
        isPhoneNumber: Bool = false,
        isPin: Bool = false
    ) {
        self.label = label
        self.placeholder = placeholder
        self._text = text
        self.iconName = iconName
        self.keyboardType = keyboardType
        self.errorMessage = errorMessage
        self.isNumericAmount = isNumericAmount
        self.isPhoneNumber = isPhoneNumber
        self.isPin = isPin
    }
    
    private var resolvedKeyboardType: UIKeyboardType {
        if isPin || keyboardType == .numberPad {
            return .asciiCapableNumberPad
        } else if isNumericAmount || keyboardType == .decimalPad {
            return .asciiCapableNumberPad
        } else if isPhoneNumber || keyboardType == .phonePad {
            return .asciiCapableNumberPad
        } else if keyboardType == .default {
            return .asciiCapable
        } else {
            return keyboardType
        }
    }
    
    public var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label)
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(.secondary)
            
            HStack(spacing: 10) {
                Image(systemName: iconName)
                    .font(.subheadline)
                    .foregroundColor(errorMessage != nil ? .statusLate : .secondary)
                    .frame(width: 20)
                
                TextField(placeholder, text: $text)
                    .keyboardType(resolvedKeyboardType)
                    .autocorrectionDisabled(true)
                    .textContentType(.none)
                    .environment(\.locale, Locale(identifier: "en_US_POSIX"))
                    .font(.body)
                    .onChange(of: text) { newValue in
                        sanitizeInput(newValue)
                    }
            }
            .padding()
            .background(Color.cardBackground)
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(
                        errorMessage != nil ? Color.statusLate : Color.secondary.opacity(0.18),
                        lineWidth: errorMessage != nil ? 1.5 : 1
                    )
            )
            
            if let error = errorMessage {
                Text(error)
                    .font(.caption2)
                    .foregroundColor(.statusLate)
                    .padding(.leading, 4)
            }
        }
    }
    
    private func sanitizeInput(_ val: String) {
        let isDecimalOrNumber = isNumericAmount || keyboardType == .decimalPad || keyboardType == .numberPad
        if isPin {
            let sanitized = val.toEnglishPin
            if text != sanitized { text = sanitized }
        } else if isDecimalOrNumber {
            let sanitized = val.toEnglishNumericAmount
            if text != sanitized { text = sanitized }
        } else if isPhoneNumber || keyboardType == .phonePad {
            let sanitized = val.toEnglishPhoneNumber
            if text != sanitized { text = sanitized }
        } else {
            let sanitized = val.toEnglishDigits
            if text != sanitized { text = sanitized }
        }
    }
}
