import Foundation

public extension Date {
    /// Formats date to a user-readable string like "Nov 18, 2026"
    func toMediumDateString() -> String {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter.string(from: self)
    }
    
    /// Formats date to month and year, e.g. "November 2026"
    func toMonthYearString() -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "MMMM yyyy"
        return formatter.string(from: self)
    }
    
    /// Returns current day of month (1...31)
    var currentDayOfMonth: Int {
        Calendar.current.component(.day, from: self)
    }
    
    /// Converts an integer day into ordinal string like "1st", "2nd", "3rd", "5th"
    static func ordinalDayString(for day: Int) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .ordinal
        return formatter.string(from: NSNumber(value: day)) ?? "\(day)th"
    }
}
