import SwiftUI

public extension Color {
    /// Semantic theme colors for Rent Collection Tracker
    static let themePrimary = Color(red: 0.08, green: 0.45, blue: 0.65)
    static let themeSecondary = Color(red: 0.12, green: 0.60, blue: 0.55)
    static let themeAccent = Color(red: 0.18, green: 0.80, blue: 0.68)
    
    // Status Colors
    static let statusPaid = Color(red: 0.15, green: 0.68, blue: 0.38)
    static let statusPaidLight = Color(red: 0.88, green: 0.96, blue: 0.91)
    
    static let statusPending = Color(red: 0.92, green: 0.60, blue: 0.15)
    static let statusPendingLight = Color(red: 0.99, green: 0.95, blue: 0.88)
    
    static let statusLate = Color(red: 0.89, green: 0.28, blue: 0.28)
    static let statusLateLight = Color(red: 0.98, green: 0.91, blue: 0.91)
    
    // Background and Cards
    static let appBackground = Color(UIColor.systemGroupedBackground)
    static let cardBackground = Color(UIColor.secondarySystemGroupedBackground)
    static let elevatedCardBackground = Color(UIColor.tertiarySystemGroupedBackground)
}
