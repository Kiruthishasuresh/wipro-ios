import Foundation

public extension Double {
    /// Formats double as a localized currency string, e.g. "$1,850.00"
    func toCurrencyString(locale: Locale = .current) -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.locale = locale
        formatter.maximumFractionDigits = 2
        formatter.minimumFractionDigits = 0
        return formatter.string(from: NSNumber(value: self)) ?? "$\(String(format: "%.0f", self))"
    }
    
    /// Formats double as compact currency, e.g. "$1.8K" or "$25,000"
    func toCompactCurrencyString() -> String {
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.maximumFractionDigits = 0
        return formatter.string(from: NSNumber(value: self)) ?? "$\(Int(self))"
    }
}
