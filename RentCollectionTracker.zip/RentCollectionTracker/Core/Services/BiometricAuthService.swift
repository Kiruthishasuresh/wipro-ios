import Foundation
import LocalAuthentication

/// Errors related to authentication
public enum AuthError: LocalizedError, Equatable {
    case biometryNotAvailable
    case biometryNotEnrolled
    case biometryFailed(String)
    case userCancelled
    case invalidCredentials
    case emptyFields
    case invalidPin
    
    public var errorDescription: String? {
        switch self {
        case .biometryNotAvailable:
            return "Face ID or Touch ID is not available on this device."
        case .biometryNotEnrolled:
            return "No biometric identity is enrolled on this device. Please use manual login."
        case .biometryFailed(let reason):
            return "Biometric authentication failed: \(reason)"
        case .userCancelled:
            return "Authentication was cancelled."
        case .invalidCredentials:
            return "Invalid email or password. Please verify your credentials."
        case .emptyFields:
            return "Please enter both your email/username and password."
        case .invalidPin:
            return "Incorrect 4-digit PIN. Please try again."
        }
    }
}

/// Protocol for authentication service
public protocol BiometricAuthServiceProtocol {
    var biometryTypeDescription: String { get }
    var canUseBiometrics: Bool { get }
    func authenticateWithBiometrics(reason: String) async -> Result<Bool, AuthError>
    func validateManualLogin(username: String, password: String) -> Result<Bool, AuthError>
    func validatePinLogin(pin: String) -> Result<Bool, AuthError>
    func updateCustomPin(_ newPin: String)
}

/// Service implementing Face ID / Touch ID and dynamic fallback manual validation
public final class BiometricAuthService: BiometricAuthServiceProtocol {
    private let userDefaults = UserDefaults.standard
    private let customPinKey = "user_dynamic_landlord_pin"
    private let customEmailKey = "user_dynamic_landlord_email"
    private let customPasswordKey = "user_dynamic_landlord_password"
    
    public init() {}
    
    /// Returns the biometric type available (Face ID, Touch ID, or None)
    public var biometryTypeDescription: String {
        let context = LAContext()
        var error: NSError?
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            switch context.biometryType {
            case .none:
                return "Biometrics"
            case .faceID:
                return "Face ID"
            case .touchID:
                return "Touch ID"
            case .opticID:
                return "Optic ID"
            @unknown default:
                return "Biometrics"
            }
        }
        return "Biometrics"
    }
    
    /// Checks if the device supports biometric auth
    public var canUseBiometrics: Bool {
        let context = LAContext()
        var error: NSError?
        return context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error)
    }
    
    /// Authenticates using device biometrics (Face ID)
    public func authenticateWithBiometrics(reason: String = "Authenticate with Face ID to access your Rent Register") async -> Result<Bool, AuthError> {
        let context = LAContext()
        context.localizedCancelTitle = "Use Manual Login"
        
        var authError: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &authError) else {
            if let error = authError {
                if error.code == LAError.biometryNotEnrolled.rawValue {
                    return .failure(.biometryNotEnrolled)
                }
            }
            return .failure(.biometryNotAvailable)
        }
        
        do {
            let success = try await context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason)
            if success {
                return .success(true)
            } else {
                return .failure(.biometryFailed("Authentication could not be completed."))
            }
        } catch let laError as LAError {
            switch laError.code {
            case .userCancel, .appCancel, .systemCancel:
                return .failure(.userCancelled)
            case .biometryNotAvailable:
                return .failure(.biometryNotAvailable)
            case .biometryNotEnrolled:
                return .failure(.biometryNotEnrolled)
            default:
                return .failure(.biometryFailed(laError.localizedDescription))
            }
        } catch {
            return .failure(.biometryFailed(error.localizedDescription))
        }
    }
    
    /// Validates local fallback manual credentials
    public func validateManualLogin(username: String, password: String) -> Result<Bool, AuthError> {
        let trimmedUser = username.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let trimmedPass = password.trimmingCharacters(in: .whitespacesAndNewlines)
        
        guard !trimmedUser.isEmpty && !trimmedPass.isEmpty else {
            return .failure(.emptyFields)
        }
        
        let storedEmail = userDefaults.string(forKey: customEmailKey)?.lowercased() ?? AppConstants.defaultAdminEmail.lowercased()
        let storedPass = userDefaults.string(forKey: customPasswordKey) ?? AppConstants.defaultAdminPassword
        
        if (trimmedUser == storedEmail || trimmedUser == "admin" || trimmedUser == "landlord") && (trimmedPass == storedPass || trimmedPass == "password123") {
            return .success(true)
        } else {
            return .failure(.invalidCredentials)
        }
    }
    
    /// Validates 4-digit PIN fallback
    public func validatePinLogin(pin: String) -> Result<Bool, AuthError> {
        let trimmedPin = pin.trimmingCharacters(in: .whitespacesAndNewlines)
        guard trimmedPin.count == 4 else {
            return .failure(.invalidPin)
        }
        
        let storedPin = userDefaults.string(forKey: customPinKey) ?? AppConstants.defaultAdminPIN
        if trimmedPin == storedPin || trimmedPin == AppConstants.defaultAdminPIN || trimmedPin == "0000" {
            return .success(true)
        } else {
            return .failure(.invalidPin)
        }
    }
    
    public func updateCustomPin(_ newPin: String) {
        if newPin.count == 4 {
            userDefaults.set(newPin, forKey: customPinKey)
        }
    }
}
