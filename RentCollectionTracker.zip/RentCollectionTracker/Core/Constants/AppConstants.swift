import Foundation

/// Application-wide constants for Rent Collection Tracker
public enum AppConstants {
    public static let appName = "Rent Collection Tracker"
    public static let appVersion = "1.0.0"
    
    // Default Master Credentials for Fallback Manual Login
    public static let defaultAdminEmail = "admin@renttracker.com"
    public static let defaultAdminPassword = "password123"
    public static let defaultAdminPIN = "1234"
    
    // Persistence Keys
    public static let tenantsStorageKey = "rent_collection_tracker_tenants_v1"
    public static let hasSeededInitialDataKey = "has_seeded_initial_tenants_data_v1"
    
    // UI Layout Constants
    public static let defaultCornerRadius: CGFloat = 16
    public static let cardCornerRadius: CGFloat = 14
    public static let badgeCornerRadius: CGFloat = 8
    public static let defaultPadding: CGFloat = 16
}
