import Foundation

/// Core Model representing a Tenant in the rent register
public struct Tenant: Identifiable, Codable, Equatable {
    public let id: UUID
    public var name: String
    public var phoneNumber: String
    public var email: String
    public var propertyUnit: String
    public var monthlyRent: Double
    public var rentDueDay: Int // Day of the month, 1...31
    public var advanceAmount: Double
    public var notes: String
    public var currentStatus: PaymentStatus
    public var paymentHistory: [PaymentRecord]
    public var leaseStartDate: Date
    public var lastUpdatedDate: Date
    
    public init(
        id: UUID = UUID(),
        name: String,
        phoneNumber: String,
        email: String = "",
        propertyUnit: String,
        monthlyRent: Double,
        rentDueDay: Int = 1,
        advanceAmount: Double = 0.0,
        notes: String = "",
        currentStatus: PaymentStatus = .pending,
        paymentHistory: [PaymentRecord] = [],
        leaseStartDate: Date = Date(),
        lastUpdatedDate: Date = Date()
    ) {
        self.id = id
        self.name = name
        self.phoneNumber = phoneNumber
        self.email = email
        self.propertyUnit = propertyUnit
        self.monthlyRent = monthlyRent
        self.rentDueDay = max(1, min(31, rentDueDay))
        self.advanceAmount = advanceAmount
        self.notes = notes
        self.currentStatus = currentStatus
        self.paymentHistory = paymentHistory
        self.leaseStartDate = leaseStartDate
        self.lastUpdatedDate = lastUpdatedDate
    }
    
    // Computed Helpers
    public var initials: String {
        let components = name.split(separator: " ").prefix(2)
        if components.isEmpty { return "T" }
        return components.compactMap { $0.first }.map { String($0) }.joined()
    }
    
    public var formattedRent: String {
        monthlyRent.toCurrencyString()
    }
    
    public var formattedAdvance: String {
        advanceAmount.toCurrencyString()
    }
    
    public var dueDayDescription: String {
        "\(Date.ordinalDayString(for: rentDueDay)) of month"
    }
    
    public var isOverdue: Bool {
        if currentStatus == .paid { return false }
        let currentDay = Date().currentDayOfMonth
        return currentDay > rentDueDay
    }
}
