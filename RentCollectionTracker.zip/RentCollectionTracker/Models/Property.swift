import Foundation

/// Summary model for grouping tenants by building or property complex
public struct PropertySummary: Identifiable, Hashable {
    public var id: String { name }
    public let name: String
    public let tenantCount: Int
    public let totalMonthlyRent: Double
    
    public init(name: String, tenantCount: Int, totalMonthlyRent: Double) {
        self.name = name
        self.tenantCount = tenantCount
        self.totalMonthlyRent = totalMonthlyRent
    }
}
