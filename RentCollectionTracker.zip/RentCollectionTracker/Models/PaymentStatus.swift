import SwiftUI

/// Payment status for a tenant's current monthly rent cycle
public enum PaymentStatus: String, CaseIterable, Identifiable, Codable {
    case paid = "Paid"
    case pending = "Pending"
    case late = "Late"
    
    public var id: String { rawValue }
    
    public var title: String { rawValue }
    
    public var iconName: String {
        switch self {
        case .paid:
            return "checkmark.circle.fill"
        case .pending:
            return "clock.fill"
        case .late:
            return "exclamationmark.triangle.fill"
        }
    }
    
    public var color: Color {
        switch self {
        case .paid:
            return Color.statusPaid
        case .pending:
            return Color.statusPending
        case .late:
            return Color.statusLate
        }
    }
    
    public var lightColor: Color {
        switch self {
        case .paid:
            return Color.statusPaidLight
        case .pending:
            return Color.statusPendingLight
        case .late:
            return Color.statusLateLight
        }
    }
    
    public var sortPriority: Int {
        switch self {
        case .late: return 0
        case .pending: return 1
        case .paid: return 2
        }
    }
}
