import Foundation

/// Method used by tenant to pay rent
public enum PaymentMethod: String, CaseIterable, Identifiable, Codable {
    case bankTransfer = "Bank Transfer"
    case cash = "Cash"
    case check = "Check"
    case zelle = "Zelle / Venmo"
    case creditDebit = "Card"
    case other = "Other"
    
    public var id: String { rawValue }
    
    public var iconName: String {
        switch self {
        case .bankTransfer: return "building.columns.fill"
        case .cash: return "banknote.fill"
        case .check: return "doc.plaintext.fill"
        case .zelle: return "arrow.left.arrow.right.circle.fill"
        case .creditDebit: return "creditcard.fill"
        case .other: return "ellipsis.circle.fill"
        }
    }
}

/// An individual rent transaction or payment record dynamically attached to a tenant
public struct PaymentRecord: Identifiable, Codable, Equatable {
    public let id: UUID
    public let tenantId: UUID
    public var tenantName: String
    public var propertyUnit: String
    public var amount: Double
    public var paymentDate: Date
    public var paymentMethod: PaymentMethod
    public var monthYear: String
    public var receiptNumber: String
    public var notes: String
    
    public init(
        id: UUID = UUID(),
        tenantId: UUID,
        tenantName: String = "",
        propertyUnit: String = "",
        amount: Double,
        paymentDate: Date = Date(),
        paymentMethod: PaymentMethod = .bankTransfer,
        monthYear: String = Date().toMonthYearString(),
        receiptNumber: String? = nil,
        notes: String = ""
    ) {
        self.id = id
        self.tenantId = tenantId
        self.tenantName = tenantName
        self.propertyUnit = propertyUnit
        self.amount = amount
        self.paymentDate = paymentDate
        self.paymentMethod = paymentMethod
        self.monthYear = monthYear
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyMMdd"
        let datePart = formatter.string(from: paymentDate)
        self.receiptNumber = receiptNumber ?? "REC-\(datePart)-\(Int.random(in: 1000...9999))"
        self.notes = notes
    }
}
