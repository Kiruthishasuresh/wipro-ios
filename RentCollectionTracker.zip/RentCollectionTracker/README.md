# Project 34: Rent Collection Tracker

A full-featured iOS application for landlords and property managers to streamline tenant rent collection, track payment statuses (Paid, Pending, Late), monitor cash flow, and maintain complete tenant financial records with biometric security.

---

## 📱 Project Specifications & Compliance

- **Platform**: iOS (iPhone Mobile only, Portrait orientation locked)
- **Architecture**: **MVVM** (Model-View-ViewModel) with clean separation of concerns
- **Security**: **Face ID** / Biometric Authentication via `LocalAuthentication` with manual login & PIN fallback
- **UI Framework**: **SwiftUI** with intuitive card layouts, interactive badges, and responsive state management
- **Persistence**: Single-source-of-truth Repository pattern backed by atomic JSON storage and UserDefaults with pre-seeded realistic mock data
- **Asset Catalog**: Full 1024x1024 application icon (`AppIcon`), Accent colors, and SF Symbols
- **Build Status**: **Zero Errors, Zero Warnings** (Clean compilation on Xcode 15 / 16 / 27+)

---

## 🏗️ Architecture & Modular Project Structure

The project strictly follows the **MVVM** pattern with each feature segregated into its own module containing dedicated files for UI, Data Models, and Business Logic:

```
RentCollectionTracker/
├── RentCollectionTracker.xcodeproj/
│   └── project.pbxproj                      # Configured for iPhone, Portrait lock & zero warnings
├── RentCollectionTracker/
│   ├── App/
│   │   ├── RentCollectionTrackerApp.swift   # Main entry point & root state coordinator
│   │   └── Info.plist                       # Permissions (Face ID) & Portrait orientation settings
│   │
│   ├── Assets.xcassets/
│   │   ├── AppIcon.appiconset/              # 1024x1024 Application icon & Contents.json
│   │   │   ├── app_icon_1024.png
│   │   │   └── Contents.json
│   │   ├── AccentColor.colorset/            # Brand accent colors (Light/Dark mode)
│   │   └── Contents.json
│   │
│   ├── Core/
│   │   ├── Constants/
│   │   │   └── AppConstants.swift           # Default credentials, storage keys & layout constants
│   │   ├── Extensions/
│   │   │   ├── Color+Theme.swift            # Semantic theme & status colors (Paid/Pending/Late)
│   │   │   ├── Date+Extensions.swift        # Ordinal formatting ("5th of month") & date utilities
│   │   │   └── Double+Currency.swift        # Currency formatting ($1,850.00 / compact $1.8K)
│   │   └── Services/
│   │       ├── BiometricAuthService.swift   # LocalAuthentication (Face ID) & manual validator
│   │       └── PersistenceService.swift     # Atomic file persistence & initial dataset seed
│   │
│   ├── Models/
│   │   ├── PaymentStatus.swift              # Status enum (.paid, .pending, .late) with color/icons
│   │   ├── PaymentRecord.swift              # Transaction records, receipt numbers & payment methods
│   │   ├── Tenant.swift                     # Core Tenant model with computed properties & helpers
│   │   └── Property.swift                   # Complex/Building group summary model
│   │
│   ├── Repositories/
│   │   ├── TenantRepositoryProtocol.swift   # Abstract protocol for reactive data operations
│   │   └── TenantRepository.swift           # Observable repository with Combine publishers
│   │
│   ├── Modules/
│   │   ├── Authentication/
│   │   │   ├── AuthViewModel.swift          # Biometric lifecycle, state & error handling
│   │   │   └── Views/
│   │   │       ├── AuthenticationView.swift # Launch screen Face ID prompt with pulse animation
│   │   │       └── ManualLoginSheet.swift   # Fallback manual login (4-digit PIN / Admin Email)
│   │   │
│   │   ├── Dashboard/
│   │   │   ├── DashboardViewModel.swift     # Aggregates totals, collected %, pending & late amounts
│   │   │   └── Views/
│   │   │       ├── DashboardView.swift      # Home overview screen & navigation entry point
│   │   │       ├── MetricCardView.swift     # 2x2 financial metric cards with deep-linking
│   │   │       └── QuickActionView.swift    # Shortcut buttons (Add Tenant, Late dues, Directory)
│   │   │
│   │   ├── TenantList/
│   │   │   ├── TenantListViewModel.swift    # Search, multi-filtering, and 5-way sorting logic
│   │   │   └── Views/
│   │   │       ├── TenantListView.swift     # Searchable directory with swipe actions & filter chips
│   │   │       ├── TenantCardView.swift     # Custom card displaying tenant, unit, rent & badge
│   │   │       ├── StatusBadgeView.swift    # Distinct pill badge for Paid/Pending/Late
│   │   │       └── FilterChipView.swift     # Interactive filter chips with counter badges
│   │   │
│   │   ├── TenantDetails/
│   │   │   ├── TenantDetailViewModel.swift  # Profile management, phone/SMS URLs & payment logging
│   │   │   └── Views/
│   │   │       ├── TenantDetailView.swift   # Detailed tenant dossier with financial terms & actions
│   │   │       ├── PaymentStatusActionSheet.swift # Dialog to update status or record receipts
│   │   │       └── PaymentHistoryListView.swift  # Chronological timeline of payment transactions
│   │   │
│   │   ├── AddEditTenant/
│   │   │   ├── AddEditTenantViewModel.swift # Form validation engine for tenant attributes
│   │   │   └── Views/
│   │   │       ├── AddTenantView.swift      # Form to register new tenant with live validation
│   │   │       └── EditTenantView.swift     # Form for rent revisions, phone updates & notes
│   │   │
│   │   └── Common/
│   │       ├── CustomTextField.swift        # Input field with iconography & error messaging
│   │       └── EmptyStateView.swift         # Visual placeholder for empty lists & search misses
│   │
│   └── Preview Content/
│       └── PreviewAssets.xcassets
│
└── Tests/
    └── RentCollectionTrackerTests/
        ├── TenantModelTests.swift           # Model property & status sorting tests
        ├── TenantRepositoryTests.swift      # Repository CRUD & payment auto-record tests
        └── DashboardViewModelTests.swift    # Metrics calculation & collection % tests
```

---

## ✨ Features Implemented

### 1. Biometric Authentication (Face ID)
- Automatically evaluates `LAContext` on launch using `.deviceOwnerAuthenticationWithBiometrics`.
- Uses `NSFaceIDUsageDescription` configured in `Info.plist`.
- **Fallback Manual Login**: If Face ID fails, is canceled, or is unavailable, the user can authenticate manually with clear validation error messages:
  - **Master PIN Mode**: `1234`
  - **Admin Email Mode**: `admin@renttracker.com` / `password123`
- Supports lock/logout anytime from the Dashboard header.

### 2. Dashboard
- Acts as the primary home screen and navigation hub.
- Displays key metrics:
  - **Total Tenants** count
  - **Rent Collected this Month** (with % collection progress bar)
  - **Rent Pending** this cycle
  - **Tenants with Late Payments** (with overdue amounts)
- Tap any metric card to deep-link directly into the pre-filtered Tenant List.
- Quick Actions row for instant access to "Add Tenant", "Tenant List", and "Late Dues".
- Recent Activity Feed showing the latest transaction receipts with payment method icons.

### 3. Tenant List
- Scrollable list styled with modern SwiftUI cards.
- Each item highlights:
  - Tenant name and initials avatar
  - Property or Unit name
  - Monthly rent formatted as currency
  - Rent due day indicator (with overdue warning highlight)
  - Color-coded payment status badge (Paid, Pending, Late)
- Swipe actions: Quick mark as Paid / Pending from the left; Delete or Mark Late from the right.

### 4. Add Tenant
- Dedicated form with live validation:
  - Tenant Full Name (minimum 2 characters)
  - Phone Number (valid formatting)
  - Email Address (optional)
  - Property / Unit designation
  - Monthly Rent ($)
  - Rent Due Day of month (stepper from 1st to 31st)
  - Advance / Security Deposit ($)
  - Initial payment status
  - Notes / lease terms
- Newly added tenants immediately update across the list, dashboard stats, and persistent storage.

### 5. Tenant Details
- Comprehensive profile view:
  - Profile header with initials, lease start date, and property unit
  - **Quick Contact Bar**: Direct "Call Tenant" (`tel://`) and "Send SMS" (`sms://`) action buttons
  - **Financial Highlights**: Monthly rent, advance deposit, and due day
  - **Current Month Status Card**: Highlighting status with "Update Status / Record Payment" button
  - **Payment History**: Chronological log of past receipts with method, amount, and notes
  - **Notes & Remarks**: Complete agreement details
  - **Vacate & Delete Action**: Prompts confirmation before removing a tenant

### 6. Edit Tenant
- Form to modify tenant details:
  - Perform rent revisions
  - Update contact numbers or email
  - Change property/unit
  - Revise rent due day and advance amount
  - Update notes and remarks

### 7. Delete Tenant
- Clean removal of vacated tenants from the register.
- Protected by a destructive confirmation alert dialog preventing accidental deletion.

### 8. Search & Filter
- Real-time search by tenant name, unit/property, or phone number.
- Horizontal filter chips with item counters: `All`, `Paid`, `Pending`, `Late`.
- Building / Property filter menu to isolate specific complexes.
- 5 sorting options:
  - Status (Late first)
  - Due Date (1st - 31st)
  - Name (A-Z)
  - Rent (High to Low)
  - Rent (Low to High)

### 9. Payment Status Tracking
- Explicit statuses:
  - 🟢 **Paid**: Payment recorded with receipt number and date.
  - 🟡 **Pending**: Awaiting payment for the current cycle.
  - 🔴 **Late**: Overdue rent highlighted across the dashboard and lists.
- Modal sheet allowing landlords to record payments with custom payment methods:
  - Bank Transfer (ACH), Cash, Check, Zelle / Venmo, Credit/Debit Card.

---

## 🚀 How to Run the Project

1. Open `RentCollectionTracker.xcodeproj` in Xcode (Xcode 15 or later).
2. Select any iPhone simulator (e.g. **iPhone 15 Pro**, **iPhone 16**, or iOS 17+ device).
3. Press **Cmd + R** to run.
4. On launch:
   - In simulator: Face ID simulation can be toggled via `Features > Face ID > Enrolled / Matching Face`, or use the manual login with PIN `1234` or `admin@renttracker.com` / `password123`.
5. Run unit tests via **Cmd + U** to verify test suite passes.
