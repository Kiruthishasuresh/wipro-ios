import SwiftUI

/// Styled input field with iconography and validation hint
public struct CustomInputField: View {
    public let label: String
    public let placeholder: String
    @Binding public var text: String
    public var iconName: String
    public var keyboardType: UIKeyboardType = .default
    public var errorMessage: String? = nil
    
    public init(
        label: String,
        placeholder: String,
        text: Binding<String>,
        iconName: String,
        keyboardType: UIKeyboardType = .default,
        errorMessage: String? = nil
    ) {
        self.label = label
        self.placeholder = placeholder
        self._text = text
        self.iconName = iconName
        self.keyboardType = keyboardType
        self.errorMessage = errorMessage
    }
    
    public var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(label)
                .font(.caption)
                .fontWeight(.semibold)
                .foregroundColor(.secondary)
            
            HStack(spacing: 10) {
                Image(systemName: iconName)
                    .font(.subheadline)
                    .foregroundColor(errorMessage != nil ? .statusLate : .secondary)
                    .frame(width: 20)
                
                TextField(placeholder, text: $text)
                    .keyboardType(keyboardType)
                    .font(.body)
            }
            .padding()
            .background(Color.cardBackground)
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .stroke(
                        errorMessage != nil ? Color.statusLate : Color.secondary.opacity(0.18),
                        lineWidth: errorMessage != nil ? 1.5 : 1
                    )
            )
            
            if let error = errorMessage {
                Text(error)
                    .font(.caption2)
                    .foregroundColor(.statusLate)
                    .padding(.leading, 4)
            }
        }
    }
}
