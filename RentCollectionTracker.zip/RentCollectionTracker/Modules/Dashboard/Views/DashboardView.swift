import SwiftUI

/// Main Home Dashboard Screen for Rent Collection Tracker
public struct DashboardView: View {
    @ObservedObject var viewModel: DashboardViewModel
    @ObservedObject var authViewModel: AuthViewModel
    @Binding var selectedTab: Int
    @Binding var externalFilterStatus: PaymentStatus?
    
    public init(
        viewModel: DashboardViewModel,
        authViewModel: AuthViewModel,
        selectedTab: Binding<Int>,
        externalFilterStatus: Binding<PaymentStatus?>
    ) {
        self.viewModel = viewModel
        self.authViewModel = authViewModel
        self._selectedTab = selectedTab
        self._externalFilterStatus = externalFilterStatus
    }
    
    public var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 20) {
                    // Header Banner with greeting and current date
                    headerSection
                    
                    // Monthly Collection Progress Bar
                    collectionProgressCard
                    
                    // 2x2 Grid of Key Metrics
                    metricsGrid
                    
                    // Quick Action Shortcuts
                    quickActionsSection
                    
                    // Recent Payment Transactions Section
                    recentActivitySection
                }
                .padding(.horizontal)
                .padding(.bottom, 24)
            }
            .background(Color.appBackground.ignoresSafeArea())
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    HStack(spacing: 6) {
                        Image(systemName: "building.2.crop.circle")
                            .foregroundColor(.themePrimary)
                        Text("Rent Tracker")
                            .font(.headline)
                            .fontWeight(.bold)
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button(action: {
                        authViewModel.lockApp()
                    }) {
                        HStack(spacing: 4) {
                            Image(systemName: "lock.fill")
                            Text("Lock")
                                .font(.caption)
                                .fontWeight(.medium)
                        }
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.themePrimary.opacity(0.1))
                        .foregroundColor(.themePrimary)
                        .cornerRadius(20)
                    }
                }
            }
            .refreshable {
                viewModel.refresh()
            }
        }
    }
    
    // Header Greeting
    private var headerSection: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text("Overview • \(Date().toMonthYearString())")
                .font(.subheadline)
                .fontWeight(.medium)
                .foregroundColor(.secondary)
            
            Text("Landlord Dashboard")
                .font(.title)
                .fontWeight(.bold)
                .foregroundColor(.primary)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.top, 4)
    }
    
    // Monthly Progress Card
    private var collectionProgressCard: some View {
        VStack(spacing: 12) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Monthly Collection Progress")
                        .font(.subheadline)
                        .fontWeight(.semibold)
                    Text("\(Int(viewModel.collectionPercentage * 100))% of expected \(viewModel.totalExpectedRent.toCurrencyString()) collected")
                        .font(.caption)
                        .foregroundColor(.secondary)
                }
                Spacer()
                Text("\(Int(viewModel.collectionPercentage * 100))%")
                    .font(.title3)
                    .fontWeight(.bold)
                    .foregroundColor(.themePrimary)
            }
            
            GeometryReader { geometry in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 8)
                        .fill(Color.secondary.opacity(0.15))
                        .frame(height: 12)
                    
                    RoundedRectangle(cornerRadius: 8)
                        .fill(
                            LinearGradient(
                                colors: [Color.statusPaid, Color.themeAccent],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .frame(width: max(0, min(geometry.size.width, geometry.size.width * CGFloat(viewModel.collectionPercentage))), height: 12)
                        .animation(.spring(response: 0.6, dampingFraction: 0.8), value: viewModel.collectionPercentage)
                }
            }
            .frame(height: 12)
        }
        .padding()
        .background(Color.cardBackground)
        .cornerRadius(AppConstants.cardCornerRadius)
        .shadow(color: Color.black.opacity(0.03), radius: 5, x: 0, y: 2)
    }
    
    // 2x2 Grid of Cards
    private var metricsGrid: some View {
        VStack(spacing: 12) {
            HStack(spacing: 12) {
                // Total Tenants Card
                MetricCardView(
                    title: "Total Tenants",
                    value: "\(viewModel.totalTenantsCount)",
                    subtitle: "Registered units",
                    iconName: "person.2.fill",
                    accentColor: .themePrimary,
                    lightColor: Color.themePrimary.opacity(0.12)
                ) {
                    externalFilterStatus = nil
                    selectedTab = 1 // Switch to Tenants tab
                }
                
                // Rent Collected Card
                MetricCardView(
                    title: "Collected",
                    value: viewModel.rentCollectedThisMonth.toCompactCurrencyString(),
                    subtitle: "Paid this month",
                    iconName: "checkmark.circle.fill",
                    accentColor: .statusPaid,
                    lightColor: .statusPaidLight
                ) {
                    externalFilterStatus = .paid
                    selectedTab = 1
                }
            }
            
            HStack(spacing: 12) {
                // Rent Pending Card
                MetricCardView(
                    title: "Pending",
                    value: viewModel.rentPendingThisMonth.toCompactCurrencyString(),
                    subtitle: "Due this cycle",
                    iconName: "clock.fill",
                    accentColor: .statusPending,
                    lightColor: .statusPendingLight
                ) {
                    externalFilterStatus = .pending
                    selectedTab = 1
                }
                
                // Late Payments Card
                MetricCardView(
                    title: "Late Payments",
                    value: "\(viewModel.lateTenantsCount)",
                    subtitle: "\(viewModel.lateRentAmount.toCompactCurrencyString()) overdue",
                    iconName: "exclamationmark.triangle.fill",
                    accentColor: .statusLate,
                    lightColor: .statusLateLight
                ) {
                    externalFilterStatus = .late
                    selectedTab = 1
                }
            }
        }
    }
    
    // Quick Actions Row
    private var quickActionsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Quick Actions")
                .font(.headline)
                .foregroundColor(.primary)
            
            HStack(spacing: 12) {
                QuickActionButton(
                    title: "Add Tenant",
                    iconName: "person.badge.plus",
                    tintColor: .themePrimary
                ) {
                    viewModel.isAddTenantPresented = true
                }
                
                QuickActionButton(
                    title: "Tenant List",
                    iconName: "list.bullet.rectangle.portrait",
                    tintColor: .themeSecondary
                ) {
                    externalFilterStatus = nil
                    selectedTab = 1
                }
                
                QuickActionButton(
                    title: "Late Dues",
                    iconName: "bell.badge.fill",
                    tintColor: .statusLate
                ) {
                    externalFilterStatus = .late
                    selectedTab = 1
                }
            }
            .padding()
            .background(Color.cardBackground)
            .cornerRadius(AppConstants.cardCornerRadius)
            .shadow(color: Color.black.opacity(0.03), radius: 5, x: 0, y: 2)
        }
    }
    
    // Recent Activity Section
    private var recentActivitySection: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Recent Payments")
                    .font(.headline)
                    .foregroundColor(.primary)
                Spacer()
                Button("View All Tenants") {
                    externalFilterStatus = nil
                    selectedTab = 1
                }
                .font(.caption)
                .foregroundColor(.themePrimary)
            }
            
            if viewModel.recentPayments.isEmpty {
                HStack {
                    Spacer()
                    VStack(spacing: 8) {
                        Image(systemName: "tray.fill")
                            .font(.title2)
                            .foregroundColor(.secondary)
                        Text("No payment activity recorded yet.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 20)
                    Spacer()
                }
                .background(Color.cardBackground)
                .cornerRadius(AppConstants.cardCornerRadius)
            } else {
                VStack(spacing: 10) {
                    ForEach(viewModel.recentPayments) { payment in
                        HStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(Color.statusPaidLight)
                                    .frame(width: 38, height: 38)
                                Image(systemName: payment.paymentMethod.iconName)
                                    .font(.system(size: 16))
                                    .foregroundColor(.statusPaid)
                            }
                            
                            VStack(alignment: .leading, spacing: 2) {
                                Text(payment.tenantName.isEmpty ? payment.receiptNumber : payment.tenantName)
                                    .font(.subheadline)
                                    .fontWeight(.medium)
                                Text("\(payment.propertyUnit.isEmpty ? "" : "\(payment.propertyUnit) • ")\(payment.paymentMethod.rawValue) • \(payment.paymentDate.toMediumDateString())")
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                            
                            Spacer()
                            
                            VStack(alignment: .trailing, spacing: 2) {
                                Text("+\(payment.amount.toCurrencyString())")
                                    .font(.subheadline)
                                    .fontWeight(.bold)
                                    .foregroundColor(.statusPaid)
                                Text(payment.receiptNumber)
                                    .font(.caption2)
                                    .foregroundColor(.secondary)
                            }
                        }
                        .padding(.vertical, 4)
                        
                        if payment.id != viewModel.recentPayments.last?.id {
                            Divider()
                        }
                    }
                }
                .padding()
                .background(Color.cardBackground)
                .cornerRadius(AppConstants.cardCornerRadius)
                .shadow(color: Color.black.opacity(0.03), radius: 5, x: 0, y: 2)
            }
        }
    }
}
