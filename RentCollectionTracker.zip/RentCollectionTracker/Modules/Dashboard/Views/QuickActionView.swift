import SwiftUI

/// Quick Action button for Dashboard shortcuts
public struct QuickActionButton: View {
    public let title: String
    public let iconName: String
    public let tintColor: Color
    public let action: () -> Void
    
    public init(title: String, iconName: String, tintColor: Color, action: @escaping () -> Void) {
        self.title = title
        self.iconName = iconName
        self.tintColor = tintColor
        self.action = action
    }
    
    public var body: some View {
        Button(action: action) {
            VStack(spacing: 8) {
                ZStack {
                    RoundedRectangle(cornerRadius: 14)
                        .fill(tintColor.opacity(0.12))
                        .frame(width: 50, height: 50)
                    
                    Image(systemName: iconName)
                        .font(.system(size: 20, weight: .semibold))
                        .foregroundColor(tintColor)
                }
                
                Text(title)
                    .font(.caption)
                    .fontWeight(.medium)
                    .foregroundColor(.primary)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
        }
        .buttonStyle(PlainButtonStyle())
    }
}
