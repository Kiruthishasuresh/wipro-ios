import SwiftUI
import Combine

/// ViewModel driving Dashboard calculations and state
@MainActor
public final class DashboardViewModel: ObservableObject {
    @Published public private(set) var totalTenantsCount: Int = 0
    @Published public private(set) var rentCollectedThisMonth: Double = 0.0
    @Published public private(set) var rentPendingThisMonth: Double = 0.0
    @Published public private(set) var lateTenantsCount: Int = 0
    @Published public private(set) var lateRentAmount: Double = 0.0
    @Published public private(set) var totalExpectedRent: Double = 0.0
    @Published public private(set) var collectionPercentage: Double = 0.0
    @Published public private(set) var recentPayments: [PaymentRecord] = []
    
    // Navigation routing states
    @Published public var selectedFilterDestination: PaymentStatus? = nil
    @Published public var isAddTenantPresented: Bool = false
    @Published public var shouldNavigateToTenantList: Bool = false
    
    private let repository: TenantRepositoryProtocol
    private var cancellables = Set<AnyCancellable>()
    
    public init(repository: TenantRepositoryProtocol) {
        self.repository = repository
        setupSubscription()
    }
    
    private func setupSubscription() {
        repository.tenantsPublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] tenants in
                self?.recalculateMetrics(from: tenants)
            }
            .store(in: &cancellables)
    }
    
    /// Recalculates all rent collection figures based on the current tenant list
    public func recalculateMetrics(from tenants: [Tenant]) {
        totalTenantsCount = tenants.count
        
        var collected: Double = 0.0
        var pending: Double = 0.0
        var late: Double = 0.0
        var lateCount: Int = 0
        var expected: Double = 0.0
        var allPayments: [PaymentRecord] = []
        
        for tenant in tenants {
            expected += tenant.monthlyRent
            allPayments.append(contentsOf: tenant.paymentHistory)
            
            switch tenant.currentStatus {
            case .paid:
                collected += tenant.monthlyRent
            case .pending:
                pending += tenant.monthlyRent
            case .late:
                late += tenant.monthlyRent
                lateCount += 1
            }
        }
        
        rentCollectedThisMonth = collected
        rentPendingThisMonth = pending
        lateTenantsCount = lateCount
        lateRentAmount = late
        totalExpectedRent = expected
        
        if expected > 0 {
            collectionPercentage = min(1.0, max(0.0, collected / expected))
        } else {
            collectionPercentage = 0.0
        }
        
        // Sort payments descending by date
        recentPayments = Array(allPayments.sorted { $0.paymentDate > $1.paymentDate }.prefix(5))
    }
    
    public func refresh() {
        repository.refreshData()
    }
}
