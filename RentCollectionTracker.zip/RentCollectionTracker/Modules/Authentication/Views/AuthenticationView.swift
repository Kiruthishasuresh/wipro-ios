import SwiftUI

/// Main Launch Screen Authentication View enforcing Face ID biometric access
public struct AuthenticationView: View {
    @ObservedObject var viewModel: AuthViewModel
    @State private var pulseAnimation = false
    
    public init(viewModel: AuthViewModel) {
        self.viewModel = viewModel
    }
    
    public var body: some View {
        ZStack {
            // Elegant background gradient
            LinearGradient(
                colors: [
                    Color(red: 0.06, green: 0.12, blue: 0.22),
                    Color(red: 0.08, green: 0.25, blue: 0.45)
                ],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            VStack(spacing: 36) {
                Spacer()
                
                // App Logo / Symbol
                VStack(spacing: 16) {
                    ZStack {
                        Circle()
                            .stroke(Color.themeAccent.opacity(0.3), lineWidth: 2)
                            .frame(width: 130, height: 130)
                            .scaleEffect(pulseAnimation ? 1.15 : 1.0)
                            .opacity(pulseAnimation ? 0.3 : 0.8)
                            .animation(.easeInOut(duration: 1.6).repeatForever(autoreverses: true), value: pulseAnimation)
                        
                        Circle()
                            .fill(
                                LinearGradient(
                                    colors: [Color.themePrimary, Color.themeSecondary],
                                    startPoint: .topLeading,
                                    endPoint: .bottomTrailing
                                )
                            )
                            .frame(width: 100, height: 100)
                            .shadow(color: Color.themeAccent.opacity(0.4), radius: 16, x: 0, y: 8)
                        
                        Image(systemName: "building.2.crop.circle.fill")
                            .font(.system(size: 48))
                            .foregroundColor(.white)
                    }
                    
                    Text(AppConstants.appName)
                        .font(.title)
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                    
                    Text("Secure Landlord Rent Management")
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.75))
                }
                
                Spacer()
                
                // Authentication Controls
                VStack(spacing: 18) {
                    // Biometric Button
                    Button(action: {
                        viewModel.triggerBiometricAuthentication()
                    }) {
                        HStack(spacing: 12) {
                            if viewModel.isAuthenticating {
                                ProgressView()
                                    .progressViewStyle(CircularProgressViewStyle(tint: .white))
                            } else {
                                Image(systemName: "faceid")
                                    .font(.title2)
                            }
                            
                            Text(viewModel.isAuthenticating ? "Verifying..." : "Unlock with \(viewModel.biometryTypeDescription)")
                                .font(.headline)
                                .fontWeight(.semibold)
                        }
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 16)
                        .background(
                            LinearGradient(
                                colors: [Color.themeSecondary, Color.themeAccent],
                                startPoint: .leading,
                                endPoint: .trailing
                            )
                        )
                        .foregroundColor(.white)
                        .cornerRadius(AppConstants.defaultCornerRadius)
                        .shadow(color: Color.themeAccent.opacity(0.35), radius: 10, x: 0, y: 5)
                    }
                    .disabled(viewModel.isAuthenticating)
                    
                    // Fallback Manual Login Button
                    Button(action: {
                        viewModel.isManualLoginPresented = true
                    }) {
                        HStack(spacing: 8) {
                            Image(systemName: "key.fill")
                            Text("Use Manual Login / PIN")
                                .fontWeight(.medium)
                        }
                        .font(.subheadline)
                        .foregroundColor(.white.opacity(0.85))
                        .padding(.vertical, 10)
                    }
                }
                .padding(.horizontal, 28)
                .padding(.bottom, 48)
            }
        }
        .sheet(isPresented: $viewModel.isManualLoginPresented) {
            ManualLoginSheet(viewModel: viewModel)
        }
        .alert("Authentication Failed", isPresented: $viewModel.showErrorAlert) {
            Button("Try Face ID Again") {
                viewModel.triggerBiometricAuthentication()
            }
            Button("Use Manual Login") {
                viewModel.isManualLoginPresented = true
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text(viewModel.errorMessage ?? "Face ID authentication could not verify your identity. You can proceed with manual login.")
        }
        .onAppear {
            pulseAnimation = true
            // Automatically prompt Face ID upon screen appear
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                viewModel.triggerBiometricAuthentication()
            }
        }
    }
}
