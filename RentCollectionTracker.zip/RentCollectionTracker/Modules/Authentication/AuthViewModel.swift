import SwiftUI
import Combine

/// ViewModel managing Face ID Biometric Authentication and Fallback Manual Login
@MainActor
public final class AuthViewModel: ObservableObject {
    @Published public var isAuthenticated: Bool = false
    @Published public var isAuthenticating: Bool = false
    @Published public var errorMessage: String? = nil
    @Published public var showErrorAlert: Bool = false
    @Published public var isManualLoginPresented: Bool = false
    
    // Manual login form fields
    @Published public var emailInput: String = ""
    @Published public var passwordInput: String = ""
    @Published public var pinInput: String = ""
    @Published public var isPinMode: Bool = true
    
    private let authService: BiometricAuthServiceProtocol
    
    public init(authService: BiometricAuthServiceProtocol = BiometricAuthService()) {
        self.authService = authService
    }
    
    public var biometryTypeDescription: String {
        authService.biometryTypeDescription
    }
    
    public var canUseBiometrics: Bool {
        authService.canUseBiometrics
    }
    
    /// Trigger Face ID / Touch ID biometric challenge on launch
    public func triggerBiometricAuthentication() {
        guard !isAuthenticating else { return }
        
        isAuthenticating = true
        errorMessage = nil
        
        Task {
            let result = await authService.authenticateWithBiometrics(reason: "Authenticate with Face ID to access your Rent Register")
            self.isAuthenticating = false
            
            switch result {
            case .success:
                withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                    self.isAuthenticated = true
                    self.errorMessage = nil
                    self.showErrorAlert = false
                    self.isManualLoginPresented = false
                }
            case .failure(let error):
                withAnimation {
                    self.errorMessage = error.localizedDescription
                    // On user cancellation or lack of biometrics, open manual login
                    if error == .biometryNotAvailable || error == .biometryNotEnrolled || error == .userCancelled {
                        self.isManualLoginPresented = true
                    } else {
                        self.showErrorAlert = true
                    }
                }
            }
        }
    }
    
    /// Manual credential validation
    public func performManualLogin() {
        errorMessage = nil
        let result: Result<Bool, AuthError>
        
        if isPinMode {
            result = authService.validatePinLogin(pin: pinInput)
        } else {
            result = authService.validateManualLogin(username: emailInput, password: passwordInput)
        }
        
        switch result {
        case .success:
            withAnimation(.spring(response: 0.4, dampingFraction: 0.8)) {
                self.isAuthenticated = true
                self.isManualLoginPresented = false
                self.errorMessage = nil
                self.clearInputs()
            }
        case .failure(let error):
            withAnimation {
                self.errorMessage = error.localizedDescription
            }
        }
    }
    
    /// Reset authentication state (Lock App)
    public func lockApp() {
        withAnimation {
            self.isAuthenticated = false
            self.clearInputs()
            self.errorMessage = nil
        }
    }
    
    private func clearInputs() {
        self.emailInput = ""
        self.passwordInput = ""
        self.pinInput = ""
    }
}
