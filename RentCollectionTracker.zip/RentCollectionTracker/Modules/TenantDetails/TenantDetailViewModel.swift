import SwiftUI
import Combine

/// ViewModel managing details, status transitions, and payments for a selected tenant
@MainActor
public final class TenantDetailViewModel: ObservableObject {
    @Published public private(set) var tenant: Tenant?
    @Published public var isEditSheetPresented: Bool = false
    @Published public var isPaymentActionSheetPresented: Bool = false
    @Published public var showDeleteConfirmation: Bool = false
    @Published public var didDeleteSuccessfully: Bool = false
    
    public let tenantId: UUID
    public let repository: TenantRepositoryProtocol
    private var cancellables = Set<AnyCancellable>()
    
    public init(tenantId: UUID, repository: TenantRepositoryProtocol) {
        self.tenantId = tenantId
        self.repository = repository
        
        // Initial load
        self.tenant = repository.getTenant(byId: tenantId)
        
        // Subscribe to repository updates
        repository.tenantsPublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] tenants in
                guard let self = self else { return }
                self.tenant = tenants.first { $0.id == self.tenantId }
            }
            .store(in: &cancellables)
    }
    
    public func changePaymentStatus(to newStatus: PaymentStatus) {
        guard let tenant = tenant else { return }
        _ = repository.updatePaymentStatus(tenantId: tenant.id, newStatus: newStatus)
    }
    
    public func recordCustomPayment(
        amount: Double,
        method: PaymentMethod,
        paymentDate: Date = Date(),
        monthYear: String,
        notes: String
    ) {
        guard let tenant = tenant else { return }
        
        let record = PaymentRecord(
            tenantId: tenant.id,
            tenantName: tenant.name,
            propertyUnit: tenant.propertyUnit,
            amount: amount,
            paymentDate: paymentDate,
            paymentMethod: method,
            monthYear: monthYear,
            notes: notes
        )
        
        _ = repository.recordPayment(tenantId: tenant.id, record: record, newStatus: .paid)
    }
    
    public func deleteTenant() -> Bool {
        guard let tenant = tenant else { return false }
        let result = repository.deleteTenant(byId: tenant.id)
        switch result {
        case .success:
            self.didDeleteSuccessfully = true
            return true
        case .failure:
            return false
        }
    }
    
    public func callTenant() {
        guard let phone = tenant?.phoneNumber.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "tel://\(phone)") else { return }
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url)
        }
    }
    
    public func messageTenant() {
        guard let phone = tenant?.phoneNumber.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "sms://\(phone)") else { return }
        if UIApplication.shared.canOpenURL(url) {
            UIApplication.shared.open(url)
        }
    }
}
