import SwiftUI

/// Section displaying chronological payment receipts for the tenant
public struct PaymentHistoryListView: View {
    public let history: [PaymentRecord]
    
    public init(history: [PaymentRecord]) {
        self.history = history
    }
    
    public var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Label("Payment History & Receipts", systemImage: "clock.arrow.circlepath")
                    .font(.headline)
                    .foregroundColor(.primary)
                Spacer()
                Text("\(history.count) records")
                    .font(.caption)
                    .foregroundColor(.secondary)
            }
            
            if history.isEmpty {
                HStack {
                    Spacer()
                    VStack(spacing: 6) {
                        Image(systemName: "doc.text.magnifyingglass")
                            .font(.title3)
                            .foregroundColor(.secondary)
                        Text("No payment transactions recorded yet.")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 16)
                    Spacer()
                }
                .background(Color.cardBackground)
                .cornerRadius(AppConstants.cardCornerRadius)
            } else {
                VStack(spacing: 8) {
                    ForEach(history) { record in
                        HStack(spacing: 12) {
                            ZStack {
                                Circle()
                                    .fill(Color.statusPaidLight)
                                    .frame(width: 38, height: 38)
                                Image(systemName: record.paymentMethod.iconName)
                                    .font(.system(size: 15))
                                    .foregroundColor(.statusPaid)
                            }
                            
                            VStack(alignment: .leading, spacing: 2) {
                                HStack {
                                    Text(record.monthYear)
                                        .font(.subheadline)
                                        .fontWeight(.semibold)
                                    Spacer()
                                    Text("+\(record.amount.toCurrencyString())")
                                        .font(.subheadline)
                                        .fontWeight(.bold)
                                        .foregroundColor(.statusPaid)
                                }
                                
                                HStack {
                                    Text("\(record.paymentMethod.rawValue) • \(record.paymentDate.toMediumDateString())")
                                        .font(.caption2)
                                        .foregroundColor(.secondary)
                                    Spacer()
                                    Text(record.receiptNumber)
                                        .font(.caption2)
                                        .foregroundColor(.secondary)
                                }
                                
                                if !record.notes.isEmpty {
                                    Text(record.notes)
                                        .font(.caption2)
                                        .foregroundColor(.secondary.opacity(0.85))
                                        .padding(.top, 2)
                                }
                            }
                        }
                        .padding()
                        .background(Color.cardBackground)
                        .cornerRadius(AppConstants.cardCornerRadius)
                        .shadow(color: Color.black.opacity(0.02), radius: 3, x: 0, y: 1)
                    }
                }
            }
        }
    }
}
