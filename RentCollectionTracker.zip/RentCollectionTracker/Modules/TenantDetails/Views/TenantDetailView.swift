import SwiftUI

/// Detailed view for a specific tenant with full records, contact actions, status controls, and edit/delete capabilities
public struct TenantDetailView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel: TenantDetailViewModel
    
    public init(tenantId: UUID, repository: TenantRepositoryProtocol) {
        _viewModel = StateObject(wrappedValue: TenantDetailViewModel(tenantId: tenantId, repository: repository))
    }
    
    public var body: some View {
        Group {
            if let tenant = viewModel.tenant {
                ScrollView {
                    VStack(spacing: 20) {
                        // Tenant Profile Header Card
                        profileHeaderCard(tenant: tenant)
                        
                        // Contact Quick Action Buttons (Call / SMS)
                        contactActionsBar
                        
                        // Financial Highlights Grid
                        financialMetricsSection(tenant: tenant)
                        
                        // Current Month Status & Quick Payment Control
                        currentMonthStatusCard(tenant: tenant)
                        
                        // Notes & Remarks Section
                        notesSection(tenant: tenant)
                        
                        // Payment History Timeline
                        PaymentHistoryListView(history: tenant.paymentHistory)
                        
                        // Delete Tenant Vacate Button
                        deleteButton
                    }
                    .padding()
                }
                .background(Color.appBackground.ignoresSafeArea())
                .navigationTitle(tenant.name)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button {
                            viewModel.isEditSheetPresented = true
                        } label: {
                            Text("Edit")
                                .fontWeight(.semibold)
                                .foregroundColor(.themePrimary)
                        }
                    }
                }
                .sheet(isPresented: $viewModel.isEditSheetPresented) {
                    EditTenantView(tenant: tenant, repository: viewModel.repository)
                }
                .sheet(isPresented: $viewModel.isPaymentActionSheetPresented) {
                    PaymentStatusActionSheet(viewModel: viewModel)
                }
                .alert("Vacate & Delete Tenant", isPresented: $viewModel.showDeleteConfirmation) {
                    Button("Delete Tenant", role: .destructive) {
                        if viewModel.deleteTenant() {
                            dismiss()
                        }
                    }
                    Button("Cancel", role: .cancel) {}
                } message: {
                    Text("Are you sure you want to remove \(tenant.name)? This will vacate the unit and remove their records from the rent register.")
                }
            } else {
                EmptyStateView(
                    iconName: "person.crop.circle.badge.xmark",
                    title: "Tenant Not Found",
                    message: "This tenant record may have been removed."
                )
            }
        }
    }
    
    // Header Profile Card
    private func profileHeaderCard(tenant: Tenant) -> some View {
        VStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [Color.themePrimary, Color.themeSecondary],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 76, height: 76)
                    .shadow(color: Color.themePrimary.opacity(0.3), radius: 8, x: 0, y: 4)
                
                Text(tenant.initials)
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(.white)
            }
            
            VStack(spacing: 4) {
                Text(tenant.name)
                    .font(.title2)
                    .fontWeight(.bold)
                    .foregroundColor(.primary)
                
                HStack(spacing: 4) {
                    Image(systemName: "building.2.fill")
                        .foregroundColor(.secondary)
                        .font(.caption)
                    Text(tenant.propertyUnit)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                
                Text("Lease Started: \(tenant.leaseStartDate.toMediumDateString())")
                    .font(.caption)
                    .foregroundColor(.secondary.opacity(0.8))
            }
        }
        .padding()
        .frame(maxWidth: .infinity)
        .background(Color.cardBackground)
        .cornerRadius(AppConstants.defaultCornerRadius)
        .shadow(color: Color.black.opacity(0.03), radius: 6, x: 0, y: 2)
    }
    
    // Quick Contact Bar (Call & SMS)
    private var contactActionsBar: some View {
        HStack(spacing: 12) {
            Button(action: {
                viewModel.callTenant()
            }) {
                HStack {
                    Image(systemName: "phone.fill")
                    Text("Call Tenant")
                        .fontWeight(.semibold)
                }
                .font(.subheadline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(Color.themePrimary.opacity(0.12))
                .foregroundColor(.themePrimary)
                .cornerRadius(12)
            }
            
            Button(action: {
                viewModel.messageTenant()
            }) {
                HStack {
                    Image(systemName: "message.fill")
                    Text("Send SMS")
                        .fontWeight(.semibold)
                }
                .font(.subheadline)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(Color.themeSecondary.opacity(0.12))
                .foregroundColor(.themeSecondary)
                .cornerRadius(12)
            }
        }
    }
    
    // Financial Key Metrics Grid
    private func financialMetricsSection(tenant: Tenant) -> some View {
        VStack(spacing: 10) {
            HStack(spacing: 10) {
                // Monthly Rent
                VStack(alignment: .leading, spacing: 4) {
                    Text("Monthly Rent")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text(tenant.formattedRent)
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                }
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.cardBackground)
                .cornerRadius(AppConstants.cardCornerRadius)
                
                // Advance / Security Deposit
                VStack(alignment: .leading, spacing: 4) {
                    Text("Advance Deposit")
                        .font(.caption)
                        .foregroundColor(.secondary)
                    Text(tenant.formattedAdvance)
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                }
                .padding()
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.cardBackground)
                .cornerRadius(AppConstants.cardCornerRadius)
            }
            
            // Rent Due Day Banner
            HStack {
                Image(systemName: "calendar.badge.clock")
                    .foregroundColor(.themePrimary)
                Text("Rent Due Day:")
                    .font(.subheadline)
                    .foregroundColor(.secondary)
                Spacer()
                Text(tenant.dueDayDescription)
                    .font(.subheadline)
                    .fontWeight(.semibold)
                    .foregroundColor(tenant.isOverdue ? .statusLate : .primary)
            }
            .padding()
            .background(Color.cardBackground)
            .cornerRadius(AppConstants.cardCornerRadius)
        }
    }
    
    // Current Month Status & Action Card
    private func currentMonthStatusCard(tenant: Tenant) -> some View {
        VStack(spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Current Month Status")
                        .font(.caption)
                        .fontWeight(.semibold)
                        .foregroundColor(.secondary)
                    Text(Date().toMonthYearString())
                        .font(.headline)
                        .fontWeight(.bold)
                }
                Spacer()
                StatusBadgeView(status: tenant.currentStatus)
            }
            
            Divider()
            
            Button(action: {
                viewModel.isPaymentActionSheetPresented = true
            }) {
                HStack {
                    Image(systemName: "creditcard.and.123")
                    Text("Update Status / Record Payment")
                        .fontWeight(.semibold)
                }
                .frame(maxWidth: .infinity)
                .padding(.vertical, 12)
                .background(
                    LinearGradient(
                        colors: [Color.themePrimary, Color.themeSecondary],
                        startPoint: .leading,
                        endPoint: .trailing
                    )
                )
                .foregroundColor(.white)
                .cornerRadius(12)
                .shadow(color: Color.themePrimary.opacity(0.3), radius: 5, x: 0, y: 2)
            }
        }
        .padding()
        .background(Color.cardBackground)
        .cornerRadius(AppConstants.cardCornerRadius)
        .shadow(color: Color.black.opacity(0.03), radius: 5, x: 0, y: 2)
    }
    
    // Notes Card
    private func notesSection(tenant: Tenant) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Notes & Remarks", systemImage: "note.text")
                .font(.headline)
                .foregroundColor(.primary)
            
            Text(tenant.notes.isEmpty ? "No notes recorded for this tenant." : tenant.notes)
                .font(.subheadline)
                .foregroundColor(tenant.notes.isEmpty ? .secondary : .primary)
                .frame(maxWidth: .infinity, alignment: .leading)
                .padding()
                .background(Color.cardBackground)
                .cornerRadius(AppConstants.cardCornerRadius)
        }
    }
    
    // Delete Button
    private var deleteButton: some View {
        Button(role: .destructive, action: {
            viewModel.showDeleteConfirmation = true
        }) {
            HStack {
                Image(systemName: "trash.fill")
                Text("Remove / Vacate Tenant")
                    .fontWeight(.semibold)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(Color.statusLate.opacity(0.12))
            .foregroundColor(.statusLate)
            .cornerRadius(AppConstants.cardCornerRadius)
        }
        .padding(.top, 8)
    }
}
