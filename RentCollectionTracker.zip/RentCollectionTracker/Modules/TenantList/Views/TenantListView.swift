import SwiftUI

/// Main Tenant Directory Screen with Search, Multi-Filter and Sorting
public struct TenantListView: View {
    @ObservedObject var viewModel: TenantListViewModel
    @State private var selectedTenantForDetail: Tenant? = nil
    
    public init(viewModel: TenantListViewModel) {
        self.viewModel = viewModel
    }
    
    public var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                // Horizontal Status Filter Chips Bar
                statusFilterBar
                    .padding(.vertical, 8)
                    .background(Color.appBackground)
                
                // Property selector and active count bar
                filterInfoBar
                
                // Main List or Empty State
                if viewModel.filteredTenants.isEmpty {
                    ScrollView {
                        EmptyStateView(
                            iconName: viewModel.searchQuery.isEmpty ? "person.crop.circle.badge.questionmark" : "magnifyingglass",
                            title: viewModel.searchQuery.isEmpty ? "No Tenants Found" : "No Matching Results",
                            message: viewModel.searchQuery.isEmpty
                                ? "There are no tenants matching the selected filter."
                                : "No tenant names or units match \"\(viewModel.searchQuery)\".",
                            actionTitle: "Add New Tenant"
                        ) {
                            viewModel.isAddTenantPresented = true
                        }
                    }
                } else {
                    List {
                        ForEach(viewModel.filteredTenants) { tenant in
                            NavigationLink(destination: TenantDetailView(tenantId: tenant.id, repository: viewModel.repository)) {
                                TenantCardView(tenant: tenant)
                            }
                            .listRowInsets(EdgeInsets(top: 6, leading: 16, bottom: 6, trailing: 16))
                            .listRowSeparator(.hidden)
                            .listRowBackground(Color.clear)
                            .swipeActions(edge: .leading, allowsFullSwipe: true) {
                                if tenant.currentStatus != .paid {
                                    Button {
                                        viewModel.quickUpdateStatus(tenantId: tenant.id, newStatus: .paid)
                                    } label: {
                                        Label("Mark Paid", systemImage: "checkmark.circle.fill")
                                    }
                                    .tint(.statusPaid)
                                } else {
                                    Button {
                                        viewModel.quickUpdateStatus(tenantId: tenant.id, newStatus: .pending)
                                    } label: {
                                        Label("Mark Pending", systemImage: "clock.fill")
                                    }
                                    .tint(.statusPending)
                                }
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                Button(role: .destructive) {
                                    viewModel.confirmDelete(tenant: tenant)
                                } label: {
                                    Label("Delete", systemImage: "trash.fill")
                                }
                                
                                if tenant.currentStatus != .late {
                                    Button {
                                        viewModel.quickUpdateStatus(tenantId: tenant.id, newStatus: .late)
                                    } label: {
                                        Label("Mark Late", systemImage: "exclamationmark.triangle.fill")
                                    }
                                    .tint(.statusLate)
                                }
                            }
                        }
                    }
                    .listStyle(.plain)
                    .background(Color.appBackground)
                }
            }
            .background(Color.appBackground.ignoresSafeArea())
            .searchable(text: $viewModel.searchQuery, prompt: "Search tenant name, unit, phone...")
            .navigationTitle("Tenants")
            .toolbar {
                // Sort Menu
                ToolbarItem(placement: .navigationBarLeading) {
                    Menu {
                        Section("Sort By") {
                            ForEach(TenantSortOption.allCases) { option in
                                Button {
                                    viewModel.sortOption = option
                                } label: {
                                    HStack {
                                        Text(option.rawValue)
                                        if viewModel.sortOption == option {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }
                            }
                        }
                        
                        Section("Filter Property") {
                            ForEach(viewModel.availableProperties, id: \.self) { property in
                                Button {
                                    viewModel.selectedPropertyFilter = property
                                } label: {
                                    HStack {
                                        Text(property)
                                        if viewModel.selectedPropertyFilter == property {
                                            Image(systemName: "checkmark")
                                        }
                                    }
                                }
                            }
                        }
                    } label: {
                        Image(systemName: "arrow.up.arrow.down.circle")
                            .font(.system(size: 16))
                            .foregroundColor(.themePrimary)
                    }
                }
                
                // Add Tenant Button
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button {
                        viewModel.isAddTenantPresented = true
                    } label: {
                        Image(systemName: "plus.circle.fill")
                            .font(.system(size: 20))
                            .foregroundColor(.themePrimary)
                    }
                }
            }
            .sheet(isPresented: $viewModel.isAddTenantPresented) {
                AddTenantView(repository: viewModel.repository)
            }
            .alert("Delete Tenant", isPresented: $viewModel.showDeleteAlert) {
                Button("Delete", role: .destructive) {
                    viewModel.performDelete()
                }
                Button("Cancel", role: .cancel) {
                    viewModel.tenantToDelete = nil
                }
            } message: {
                Text("Are you sure you want to remove \(viewModel.tenantToDelete?.name ?? "this tenant")? This action removes their rent record and cannot be undone.")
            }
        }
    }
    
    // Horizontal Status Filter Chips Bar
    private var statusFilterBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                FilterChipView(
                    title: "All",
                    isSelected: viewModel.selectedStatusFilter == nil,
                    count: viewModel.allTenants.count
                ) {
                    withAnimation {
                        viewModel.selectedStatusFilter = nil
                    }
                }
                
                FilterChipView(
                    title: "Paid",
                    isSelected: viewModel.selectedStatusFilter == .paid,
                    count: viewModel.allTenants.filter { $0.currentStatus == .paid }.count,
                    badgeColor: .statusPaid
                ) {
                    withAnimation {
                        viewModel.selectedStatusFilter = .paid
                    }
                }
                
                FilterChipView(
                    title: "Pending",
                    isSelected: viewModel.selectedStatusFilter == .pending,
                    count: viewModel.allTenants.filter { $0.currentStatus == .pending }.count,
                    badgeColor: .statusPending
                ) {
                    withAnimation {
                        viewModel.selectedStatusFilter = .pending
                    }
                }
                
                FilterChipView(
                    title: "Late",
                    isSelected: viewModel.selectedStatusFilter == .late,
                    count: viewModel.allTenants.filter { $0.currentStatus == .late }.count,
                    badgeColor: .statusLate
                ) {
                    withAnimation {
                        viewModel.selectedStatusFilter = .late
                    }
                }
            }
            .padding(.horizontal)
        }
    }
    
    // Property and count active indicator
    private var filterInfoBar: some View {
        HStack {
            if viewModel.selectedPropertyFilter != "All Properties" {
                HStack(spacing: 4) {
                    Text("Building: \(viewModel.selectedPropertyFilter)")
                        .font(.caption)
                        .fontWeight(.medium)
                        .foregroundColor(.themePrimary)
                    
                    Button {
                        viewModel.selectedPropertyFilter = "All Properties"
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.caption2)
                            .foregroundColor(.themePrimary)
                    }
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 3)
                .background(Color.themePrimary.opacity(0.12))
                .cornerRadius(12)
            }
            
            Spacer()
            
            Text("Showing \(viewModel.filteredTenants.count) of \(viewModel.allTenants.count)")
                .font(.caption2)
                .foregroundColor(.secondary)
        }
        .padding(.horizontal)
        .padding(.vertical, 4)
    }
}
