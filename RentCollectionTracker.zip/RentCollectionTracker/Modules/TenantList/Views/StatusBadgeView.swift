import SwiftUI

/// Distinct Status Badge Component with semantic color coding
public struct StatusBadgeView: View {
    public let status: PaymentStatus
    public var compact: Bool = false
    
    public init(status: PaymentStatus, compact: Bool = false) {
        self.status = status
        self.compact = compact
    }
    
    public var body: some View {
        HStack(spacing: compact ? 3 : 5) {
            Image(systemName: status.iconName)
                .font(.system(size: compact ? 10 : 12, weight: .bold))
            
            Text(status.title)
                .font(compact ? .caption2 : .caption)
                .fontWeight(.bold)
        }
        .padding(.horizontal, compact ? 7 : 10)
        .padding(.vertical, compact ? 3 : 5)
        .background(status.color.opacity(0.14))
        .foregroundColor(status.color)
        .cornerRadius(AppConstants.badgeCornerRadius)
        .overlay(
            RoundedRectangle(cornerRadius: AppConstants.badgeCornerRadius)
                .stroke(status.color.opacity(0.35), lineWidth: 1)
        )
    }
}
