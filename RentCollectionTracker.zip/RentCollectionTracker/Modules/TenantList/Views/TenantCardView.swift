import SwiftUI

/// Custom SwiftUI Card component displaying a single tenant's summary
public struct TenantCardView: View {
    public let tenant: Tenant
    public var onQuickStatusChange: ((PaymentStatus) -> Void)? = nil
    
    public init(tenant: Tenant, onQuickStatusChange: ((PaymentStatus) -> Void)? = nil) {
        self.tenant = tenant
        self.onQuickStatusChange = onQuickStatusChange
    }
    
    public var body: some View {
        VStack(spacing: 12) {
            HStack(alignment: .top, spacing: 14) {
                // Tenant Initials Avatar
                ZStack {
                    Circle()
                        .fill(
                            LinearGradient(
                                colors: [Color.themePrimary.opacity(0.85), Color.themeSecondary],
                                startPoint: .topLeading,
                                endPoint: .bottomTrailing
                            )
                        )
                        .frame(width: 48, height: 48)
                    
                    Text(tenant.initials)
                        .font(.system(size: 17, weight: .bold))
                        .foregroundColor(.white)
                }
                
                // Tenant Info
                VStack(alignment: .leading, spacing: 4) {
                    Text(tenant.name)
                        .font(.headline)
                        .fontWeight(.semibold)
                        .foregroundColor(.primary)
                        .lineLimit(1)
                    
                    HStack(spacing: 4) {
                        Image(systemName: "mappin.circle.fill")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        Text(tenant.propertyUnit)
                            .font(.subheadline)
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                    }
                    
                    HStack(spacing: 6) {
                        Image(systemName: "calendar")
                            .font(.caption2)
                            .foregroundColor(.secondary)
                        Text("Due: \(tenant.dueDayDescription)")
                            .font(.caption)
                            .foregroundColor(tenant.isOverdue ? .statusLate : .secondary)
                            .fontWeight(tenant.isOverdue ? .semibold : .regular)
                    }
                }
                
                Spacer()
                
                // Right side: Monthly Rent and Status Badge
                VStack(alignment: .trailing, spacing: 6) {
                    Text(tenant.formattedRent)
                        .font(.headline)
                        .fontWeight(.bold)
                        .foregroundColor(.primary)
                    
                    Text("/ month")
                        .font(.caption2)
                        .foregroundColor(.secondary)
                    
                    StatusBadgeView(status: tenant.currentStatus)
                }
            }
        }
        .padding()
        .background(Color.cardBackground)
        .cornerRadius(AppConstants.cardCornerRadius)
        .shadow(color: Color.black.opacity(0.03), radius: 5, x: 0, y: 2)
        .overlay(
            RoundedRectangle(cornerRadius: AppConstants.cardCornerRadius)
                .stroke(tenant.currentStatus == .late ? Color.statusLate.opacity(0.35) : Color.clear, lineWidth: 1.5)
        )
    }
}
