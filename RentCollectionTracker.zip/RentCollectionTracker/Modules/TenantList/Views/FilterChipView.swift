import SwiftUI

/// Modern horizontal Filter Chip for filtering by Payment Status
public struct FilterChipView: View {
    public let title: String
    public let isSelected: Bool
    public var count: Int? = nil
    public var badgeColor: Color? = nil
    public let action: () -> Void
    
    public init(
        title: String,
        isSelected: Bool,
        count: Int? = nil,
        badgeColor: Color? = nil,
        action: @escaping () -> Void
    ) {
        self.title = title
        self.isSelected = isSelected
        self.count = count
        self.badgeColor = badgeColor
        self.action = action
    }
    
    public var body: some View {
        Button(action: action) {
            HStack(spacing: 6) {
                if let badgeColor = badgeColor {
                    Circle()
                        .fill(badgeColor)
                        .frame(width: 8, height: 8)
                }
                
                Text(title)
                    .font(.subheadline)
                    .fontWeight(isSelected ? .semibold : .regular)
                
                if let count = count {
                    Text("\(count)")
                        .font(.caption2)
                        .fontWeight(.bold)
                        .padding(.horizontal, 6)
                        .padding(.vertical, 2)
                        .background(isSelected ? Color.white.opacity(0.25) : Color.secondary.opacity(0.18))
                        .clipShape(Capsule())
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
            .background(
                isSelected ? Color.themePrimary : Color.cardBackground
            )
            .foregroundColor(isSelected ? .white : .primary)
            .cornerRadius(20)
            .shadow(color: isSelected ? Color.themePrimary.opacity(0.3) : Color.black.opacity(0.03), radius: 4, x: 0, y: 2)
            .overlay(
                RoundedRectangle(cornerRadius: 20)
                    .stroke(isSelected ? Color.clear : Color.secondary.opacity(0.15), lineWidth: 1)
            )
        }
        .buttonStyle(PlainButtonStyle())
    }
}
