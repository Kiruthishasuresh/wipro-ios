import SwiftUI
import Combine

/// Sorting options for the Tenant List
public enum TenantSortOption: String, CaseIterable, Identifiable {
    case nameAscending = "Name (A-Z)"
    case dueDay = "Due Date (1st - 31st)"
    case rentDescending = "Rent (High to Low)"
    case rentAscending = "Rent (Low to High)"
    case statusPriority = "Status (Late First)"
    
    public var id: String { rawValue }
}

/// ViewModel managing Tenant List, Search query, and filtering logic
@MainActor
public final class TenantListViewModel: ObservableObject {
    @Published public var searchQuery: String = ""
    @Published public var selectedStatusFilter: PaymentStatus? = nil
    @Published public var selectedPropertyFilter: String = "All Properties"
    @Published public var sortOption: TenantSortOption = .statusPriority
    
    @Published public private(set) var allTenants: [Tenant] = []
    @Published public private(set) var filteredTenants: [Tenant] = []
    @Published public private(set) var availableProperties: [String] = ["All Properties"]
    
    @Published public var isAddTenantPresented: Bool = false
    @Published public var tenantToDelete: Tenant? = nil
    @Published public var showDeleteAlert: Bool = false
    
    public let repository: TenantRepositoryProtocol
    private var cancellables = Set<AnyCancellable>()
    
    public init(repository: TenantRepositoryProtocol) {
        self.repository = repository
        setupBindings()
    }
    
    private func setupBindings() {
        // Subscribe to repository tenants
        repository.tenantsPublisher
            .receive(on: DispatchQueue.main)
            .sink { [weak self] tenants in
                self?.allTenants = tenants
                self?.updatePropertiesList(from: tenants)
                self?.applyFiltersAndSort()
            }
            .store(in: &cancellables)
        
        // React to query / filter / sort changes
        Publishers.CombineLatest4($searchQuery, $selectedStatusFilter, $selectedPropertyFilter, $sortOption)
            .receive(on: DispatchQueue.main)
            .sink { [weak self] _ in
                self?.applyFiltersAndSort()
            }
            .store(in: &cancellables)
    }
    
    private func updatePropertiesList(from tenants: [Tenant]) {
        let uniqueProps = Set(tenants.map { tenant -> String in
            // Extract building/property name before hyphen if exists
            let parts = tenant.propertyUnit.components(separatedBy: "-")
            return parts.first?.trimmingCharacters(in: .whitespaces) ?? tenant.propertyUnit
        }).sorted()
        
        self.availableProperties = ["All Properties"] + uniqueProps
    }
    
    public func applyFiltersAndSort() {
        var results = allTenants
        
        // 1. Search Query Filter (name, unit, phone)
        let query = searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if !query.isEmpty {
            results = results.filter { tenant in
                tenant.name.lowercased().contains(query) ||
                tenant.propertyUnit.lowercased().contains(query) ||
                tenant.phoneNumber.contains(query) ||
                tenant.notes.lowercased().contains(query)
            }
        }
        
        // 2. Status Filter
        if let status = selectedStatusFilter {
            results = results.filter { $0.currentStatus == status }
        }
        
        // 3. Property Filter
        if selectedPropertyFilter != "All Properties" {
            results = results.filter { tenant in
                tenant.propertyUnit.lowercased().contains(selectedPropertyFilter.lowercased())
            }
        }
        
        // 4. Sorting
        switch sortOption {
        case .nameAscending:
            results.sort { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        case .dueDay:
            results.sort { $0.rentDueDay < $1.rentDueDay }
        case .rentDescending:
            results.sort { $0.monthlyRent > $1.monthlyRent }
        case .rentAscending:
            results.sort { $0.monthlyRent < $1.monthlyRent }
        case .statusPriority:
            results.sort {
                if $0.currentStatus.sortPriority != $1.currentStatus.sortPriority {
                    return $0.currentStatus.sortPriority < $1.currentStatus.sortPriority
                }
                return $0.name < $1.name
            }
        }
        
        self.filteredTenants = results
    }
    
    public func confirmDelete(tenant: Tenant) {
        self.tenantToDelete = tenant
        self.showDeleteAlert = true
    }
    
    public func performDelete() {
        guard let tenant = tenantToDelete else { return }
        _ = repository.deleteTenant(byId: tenant.id)
        self.tenantToDelete = nil
    }
    
    public func quickUpdateStatus(tenantId: UUID, newStatus: PaymentStatus) {
        _ = repository.updatePaymentStatus(tenantId: tenantId, newStatus: newStatus)
    }
}
