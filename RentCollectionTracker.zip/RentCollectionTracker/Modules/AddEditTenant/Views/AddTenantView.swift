import SwiftUI

/// Add New Tenant Screen with fully dynamic fields
public struct AddTenantView: View {
    @Environment(\.dismiss) private var dismiss
    @StateObject private var viewModel: AddEditTenantViewModel
    
    public init(repository: TenantRepositoryProtocol) {
        _viewModel = StateObject(wrappedValue: AddEditTenantViewModel(repository: repository))
    }
    
    public var body: some View {
        NavigationStack {
            Form {
                // Section 1: Personal & Contact Details
                Section {
                    CustomInputField(
                        label: "Full Name *",
                        placeholder: "Enter tenant full name",
                        text: $viewModel.name,
                        iconName: "person.fill",
                        errorMessage: viewModel.nameError
                    )
                    
                    CustomInputField(
                        label: "Phone Number *",
                        placeholder: "e.g. +1 555-0199",
                        text: $viewModel.phoneNumber,
                        iconName: "phone.fill",
                        keyboardType: .phonePad,
                        errorMessage: viewModel.phoneError
                    )
                    
                    CustomInputField(
                        label: "Email Address (Optional)",
                        placeholder: "e.g. tenant@domain.com",
                        text: $viewModel.email,
                        iconName: "envelope.fill",
                        keyboardType: .emailAddress
                    )
                } header: {
                    Label("Tenant Contact Information", systemImage: "person.crop.circle")
                }
                
                // Section 2: Property & Lease Details
                Section {
                    CustomInputField(
                        label: "Property or Unit *",
                        placeholder: "e.g. Unit 302, Green Valley Apartments",
                        text: $viewModel.propertyUnit,
                        iconName: "building.2.fill",
                        errorMessage: viewModel.propertyError
                    )
                    
                    CustomInputField(
                        label: "Monthly Rent Amount ($) *",
                        placeholder: "Enter monthly rent",
                        text: $viewModel.monthlyRentText,
                        iconName: "dollarsign.circle.fill",
                        keyboardType: .decimalPad,
                        errorMessage: viewModel.rentError
                    )
                    
                    // Rent Due Day Stepper
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Rent Due Day")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        
                        Stepper(value: $viewModel.rentDueDay, in: 1...31) {
                            HStack {
                                Image(systemName: "calendar")
                                    .foregroundColor(.themePrimary)
                                Text("\(Date.ordinalDayString(for: viewModel.rentDueDay)) of each month")
                                    .fontWeight(.medium)
                            }
                        }
                    }
                    .padding(.vertical, 4)
                    
                    CustomInputField(
                        label: "Advance / Security Deposit ($)",
                        placeholder: "Enter security deposit",
                        text: $viewModel.advanceAmountText,
                        iconName: "shield.fill",
                        keyboardType: .decimalPad
                    )
                    
                    // Dynamic Lease Start Date Picker
                    DatePicker(
                        selection: $viewModel.leaseStartDate,
                        displayedComponents: .date
                    ) {
                        HStack {
                            Image(systemName: "calendar.badge.clock")
                                .foregroundColor(.themePrimary)
                            Text("Lease Start Date")
                                .font(.subheadline)
                                .fontWeight(.medium)
                        }
                    }
                    .padding(.vertical, 2)
                } header: {
                    Label("Property & Lease Terms", systemImage: "doc.text.fill")
                }
                
                // Section 3: Initial Status & Dynamic Payment Options
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Initial Payment Status")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        
                        Picker("Status", selection: $viewModel.currentStatus) {
                            ForEach(PaymentStatus.allCases) { status in
                                HStack {
                                    Image(systemName: status.iconName)
                                    Text(status.title)
                                }
                                .tag(status)
                            }
                        }
                        .pickerStyle(.segmented)
                    }
                    .padding(.vertical, 4)
                    
                    // If initial status is Paid, capture dynamic payment details
                    if viewModel.currentStatus == .paid {
                        Picker("Payment Method", selection: $viewModel.initialPaymentMethod) {
                            ForEach(PaymentMethod.allCases) { method in
                                HStack {
                                    Image(systemName: method.iconName)
                                    Text(method.rawValue)
                                }
                                .tag(method)
                            }
                        }
                        
                        TextField("Payment Note (optional)", text: $viewModel.initialPaymentNote)
                            .font(.subheadline)
                    }
                    
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Notes / Agreement Details")
                            .font(.caption)
                            .fontWeight(.semibold)
                            .foregroundColor(.secondary)
                        
                        TextEditor(text: $viewModel.notes)
                            .frame(minHeight: 80)
                            .padding(4)
                            .background(Color.cardBackground)
                            .cornerRadius(8)
                            .overlay(
                                RoundedRectangle(cornerRadius: 8)
                                    .stroke(Color.secondary.opacity(0.18), lineWidth: 1)
                            )
                    }
                } header: {
                    Label("Payment Status & Notes", systemImage: "note.text")
                }
                
                if let generalError = viewModel.generalError {
                    Section {
                        Text(generalError)
                            .foregroundColor(.statusLate)
                            .font(.subheadline)
                    }
                }
            }
            .navigationTitle("Add Tenant")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Save") {
                        if viewModel.save() {
                            dismiss()
                        }
                    }
                    .fontWeight(.bold)
                    .foregroundColor(.themePrimary)
                }
            }
        }
    }
}
