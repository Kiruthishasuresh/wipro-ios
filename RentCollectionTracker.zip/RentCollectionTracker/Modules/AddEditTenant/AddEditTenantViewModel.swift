import SwiftUI
import Combine

/// ViewModel managing Form State and Validations for Adding and Editing Tenants
@MainActor
public final class AddEditTenantViewModel: ObservableObject {
    @Published public var name: String = ""
    @Published public var phoneNumber: String = ""
    @Published public var email: String = ""
    @Published public var propertyUnit: String = ""
    @Published public var monthlyRentText: String = ""
    @Published public var rentDueDay: Int = 1
    @Published public var advanceAmountText: String = ""
    @Published public var notes: String = ""
    @Published public var currentStatus: PaymentStatus = .pending
    @Published public var leaseStartDate: Date = Date()
    
    // Dynamic fields when initial status is Paid
    @Published public var initialPaymentMethod: PaymentMethod = .bankTransfer
    @Published public var initialPaymentNote: String = ""
    
    // Field validation error states
    @Published public var nameError: String? = nil
    @Published public var phoneError: String? = nil
    @Published public var propertyError: String? = nil
    @Published public var rentError: String? = nil
    @Published public var generalError: String? = nil
    
    public let editingTenant: Tenant?
    private let repository: TenantRepositoryProtocol
    
    public var isEditing: Bool {
        editingTenant != nil
    }
    
    public init(repository: TenantRepositoryProtocol, tenantToEdit: Tenant? = nil) {
        self.repository = repository
        self.editingTenant = tenantToEdit
        
        if let tenant = tenantToEdit {
            self.name = tenant.name
            self.phoneNumber = tenant.phoneNumber
            self.email = tenant.email
            self.propertyUnit = tenant.propertyUnit
            self.monthlyRentText = String(format: "%.0f", tenant.monthlyRent)
            self.rentDueDay = tenant.rentDueDay
            self.advanceAmountText = tenant.advanceAmount > 0 ? String(format: "%.0f", tenant.advanceAmount) : ""
            self.notes = tenant.notes
            self.currentStatus = tenant.currentStatus
            self.leaseStartDate = tenant.leaseStartDate
        }
    }
    
    /// Validates all input fields
    public func validate() -> Bool {
        var isValid = true
        nameError = nil
        phoneError = nil
        propertyError = nil
        rentError = nil
        generalError = nil
        
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmedName.isEmpty {
            nameError = "Tenant name is required."
            isValid = false
        } else if trimmedName.count < 2 {
            nameError = "Name must be at least 2 characters."
            isValid = false
        }
        
        let trimmedPhone = phoneNumber.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmedPhone.isEmpty {
            phoneError = "Phone number is required."
            isValid = false
        } else if trimmedPhone.count < 7 {
            phoneError = "Please enter a valid phone number."
            isValid = false
        }
        
        let trimmedProperty = propertyUnit.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmedProperty.isEmpty {
            propertyError = "Property or Unit name is required."
            isValid = false
        }
        
        guard let rent = Double(monthlyRentText.replacingOccurrences(of: ",", with: "")), rent > 0 else {
            rentError = "Please enter a valid monthly rent amount (greater than 0)."
            isValid = false
            return isValid
        }
        
        return isValid
    }
    
    /// Saves the tenant (either new insert or update)
    public func save() -> Bool {
        guard validate() else { return false }
        
        let rent = Double(monthlyRentText.replacingOccurrences(of: ",", with: "")) ?? 0.0
        let advance = Double(advanceAmountText.replacingOccurrences(of: ",", with: "")) ?? 0.0
        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedProperty = propertyUnit.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if let existing = editingTenant {
            // Update existing tenant
            var updated = existing
            updated.name = trimmedName
            updated.phoneNumber = phoneNumber.trimmingCharacters(in: .whitespacesAndNewlines)
            updated.email = email.trimmingCharacters(in: .whitespacesAndNewlines)
            updated.propertyUnit = trimmedProperty
            updated.monthlyRent = rent
            updated.rentDueDay = rentDueDay
            updated.advanceAmount = advance
            updated.notes = notes.trimmingCharacters(in: .whitespacesAndNewlines)
            updated.currentStatus = currentStatus
            updated.leaseStartDate = leaseStartDate
            
            let result = repository.updateTenant(updated)
            switch result {
            case .success:
                return true
            case .failure(let error):
                generalError = error.localizedDescription
                return false
            }
        } else {
            // Add new tenant
            let tenantId = UUID()
            var history: [PaymentRecord] = []
            
            if currentStatus == .paid {
                let note = initialPaymentNote.isEmpty ? "First month rent received." : initialPaymentNote
                let payment = PaymentRecord(
                    tenantId: tenantId,
                    tenantName: trimmedName,
                    propertyUnit: trimmedProperty,
                    amount: rent,
                    paymentDate: Date(),
                    paymentMethod: initialPaymentMethod,
                    monthYear: Date().toMonthYearString(),
                    notes: note
                )
                history.append(payment)
            }
            
            let newTenant = Tenant(
                id: tenantId,
                name: trimmedName,
                phoneNumber: phoneNumber.trimmingCharacters(in: .whitespacesAndNewlines),
                email: email.trimmingCharacters(in: .whitespacesAndNewlines),
                propertyUnit: trimmedProperty,
                monthlyRent: rent,
                rentDueDay: rentDueDay,
                advanceAmount: advance,
                notes: notes.trimmingCharacters(in: .whitespacesAndNewlines),
                currentStatus: currentStatus,
                paymentHistory: history,
                leaseStartDate: leaseStartDate
            )
            
            let result = repository.addTenant(newTenant)
            switch result {
            case .success:
                return true
            case .failure(let error):
                generalError = error.localizedDescription
                return false
            }
        }
    }
}
